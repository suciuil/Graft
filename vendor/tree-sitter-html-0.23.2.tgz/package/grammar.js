/**
 * @file HTML grammar for tree-sitter
 * @author Max Brunsfeld <maxbrunsfeld@gmail.com>
 * @author Amaan Qureshi <amaanq12@gmail.com>
 * @license MIT
 */

/// <reference types="tree-sitter-cli/dsl" />
// @ts-check

module.exports = grammar({
  name: 'html',

  extras: $ => [
    $.comment,
    /\s+/,
  ],

  externals: $ => [
    $._start_tag_name,
    $._script_start_tag_name,
    $._style_start_tag_name,
    $._end_tag_name,
    $.erroneous_end_tag_name,
    '/>',
    $._implicit_end_tag,
    $.raw_text,
    $.comment,
    $._end_tag_eof,
  ],

  rules: {
    document: $ => repeat($._node),

    doctype: $ => seq(
      '<!',
      alias($._doctype, 'doctype'),
      /[^>]+/,
      '>',
    ),

    _doctype: _ => /[Dd][Oo][Cc][Tt][Yy][Pp][Ee]/,

    _node: $ => choice(
      $.doctype,
      $.entity,
      $.text,
      $.element,
      $.script_element,
      $.style_element,
      $.erroneous_end_tag,
    ),

    element: $ => choice(
      seq(
        $.start_tag,
        repeat($._node),
        choice($.end_tag, $._implicit_end_tag),
      ),
      $.self_closing_tag,
    ),

    script_element: $ => seq(
      alias($.script_start_tag, $.start_tag),
      optional($.raw_text),
      $.end_tag,
    ),

    style_element: $ => seq(
      alias($.style_start_tag, $.start_tag),
      optional($.raw_text),
      $.end_tag,
    ),

    // A start tag cut off by the end of the file (no `>` before it) ends there
    // too, with the zero-width `_end_tag_eof` described at `end_tag`. Browsers
    // drop such a tag; it is kept here so its name and attributes stay
    // visible.
    start_tag: $ => seq(
      '<',
      alias($._start_tag_name, $.tag_name),
      repeat($._attribute_or_slash),
      choice('>', $._end_tag_eof),
    ),

    script_start_tag: $ => seq(
      '<',
      alias($._script_start_tag_name, $.tag_name),
      repeat($._attribute_or_slash),
      '>',
    ),

    style_start_tag: $ => seq(
      '<',
      alias($._style_start_tag_name, $.tag_name),
      repeat($._attribute_or_slash),
      '>',
    ),

    self_closing_tag: $ => seq(
      '<',
      alias($._start_tag_name, $.tag_name),
      repeat($._attribute_or_slash),
      '/>',
    ),

    // A `/` inside a tag that is not part of the closing `/>` (`<a b/c>`,
    // `<p / >`) is dropped by the HTML tokenizer (self-closing start tag
    // state: anything but `>` is reconsumed before an attribute name), so it
    // is skipped here too instead of starting an ERROR node.
    _attribute_or_slash: $ => choice($.attribute, '/'),

    // An end tag cut off by the end of the file (`</html` with no `>`, as some
    // log generators write) is closed by the zero-width `_end_tag_eof`, which
    // the scanner only produces at the end of the input. Browsers read such a
    // document the same way: the unfinished tag is dropped and every open
    // element ends at the end of the file.
    end_tag: $ => seq(
      '</',
      alias($._end_tag_name, $.tag_name),
      choice('>', $._end_tag_eof),
    ),

    erroneous_end_tag: $ => seq(
      '</',
      $.erroneous_end_tag_name,
      choice('>', $._end_tag_eof),
    ),

    // The value after `=` may be missing (`<a b=>`): the HTML tokenizer's
    // before attribute value state then ends the tag with an empty value.
    attribute: $ => seq(
      choice($.attribute_name, alias($._quoted_attribute_name, $.attribute_name)),
      optional(seq(
        '=',
        optional(choice(
          $.attribute_value,
          $.quoted_attribute_value,
        )),
      )),
    ),

    // As in the HTML tokenizer's attribute name state, a name runs up to
    // whitespace, `/`, `>` or `=`; `<` and, after the first character, `"`
    // and `'` are (erroneous but) part of the name, e.g. `<a b"c>` or the `<`
    // of `x <=> y` read inside a tag. A name does not start with a quote, so
    // that after `=` and a space a quote still opens a quoted value.
    attribute_name: _ => /[^\s\/>="'][^\s\/>=]*/,

    // Where no value can start, a quote does start a name, as in the attribute
    // name state: the stray `"` of `<p class="a"">`, or `<a b "c">`. The low
    // precedence keeps a quote after `=` (and a space) opening a quoted value.
    _quoted_attribute_name: _ => token(prec(-1, /["'][^\s\/>=]*/)),

    // From fork mantou132/tree-sitter-html@0e827da (mantou132): loose unquoted
    // values. Per the HTML tokenizer's unquoted attribute value state, only
    // whitespace and `>` end the value; `"`, `'`, `=` and `<` inside it are
    // (erroneous but) part of the value, e.g. `id=a=b` or `href=foo"bar`.
    // The before attribute value state starts one with anything but
    // whitespace, a quote or `>`, so `a==b` and `a=<b` have the values `=b`
    // and `<b`. The precedence keeps `a= b` one attribute with the value `b`,
    // as browsers read it, now that the value itself is optional.
    attribute_value: _ => token(prec(1, /[^\s"'>][^>\s]*/)),

    // An entity can be named, numeric (decimal), or numeric (hexacecimal). The
    // longest entity name is 29 characters long, and the HTML spec says that
    // no more will ever be added.
    entity: _ => /&(#([xX][0-9a-fA-F]{1,6}|[0-9]{1,5})|[A-Za-z]{1,30});?/,

    quoted_attribute_value: $ => choice(
      seq('\'', optional(alias(/[^']+/, $.attribute_value)), '\''),
      seq('"', optional(alias(/[^"]+/, $.attribute_value)), '"'),
    ),

    // From fork tau-engineering/tree-sitter-html@8207e9f (Kunall Banerjee):
    // allow `>` in text. In the tokenizer's data state only `<` and `&` are
    // special; a bare `>` (e.g. `a > b`, `=>`) is ordinary character data and
    // used to start an ERROR node.
    //
    // A `&` that cannot start a character reference (`a & b`, `a && b`,
    // `x&&y`: not followed by `#` or a letter) and a `<` that cannot start a
    // tag (`a < b`, `x <= y`, `<3`: not followed by a letter, `/`, `!` or `?`)
    // are also ordinary character data in the HTML tokenizer (character
    // reference state and tag open state, "anything else"), so they are part
    // of the text too. Each is matched together with the character after it,
    // which decides whether it is text. A `&` followed by another `&` takes
    // it along, so `&&amp;` reads as text and `amp;`.
    text: _ => {
      const char = /[^<&\s]|&[^#A-Za-z<]|<+[^A-Za-z!\/?<&]/.source;
      return new RegExp(`(${char})(([^<&]|${char})*(${char}))?`);
    },
  },
});
