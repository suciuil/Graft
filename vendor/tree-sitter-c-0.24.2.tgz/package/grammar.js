/**
 * @file C grammar for tree-sitter
 * @author Max Brunsfeld <maxbrunsfeld@gmail.com>
 * @author Amaan Qureshi <amaanq12@gmail.com>
 * @license MIT
 */

/// <reference types="tree-sitter-cli/dsl" />
// @ts-check

const PREC = {
  // Readings that guess at a macro the parser cannot expand. Far below any plain C
  // reading (a parenthesized declarator costs -10), so they only win where plain C
  // fails; a bare macro statement loses to a macro modifier.
  // A macro call after a function's parameters only wins where no reading built
  // from the macro guesses below exists, even one that chains several of them.
  TRAILING_MACRO_CALL: -1000,
  MACRO_STATEMENT: -101,
  MACRO: -100,
  PAREN_DECLARATOR: -10,
  // Above a macro type followed by a parenthesized declarator (-11), which is how
  // `typedef P2FUNC(void, CODE, Cbk)(void);` read before, and below any plain C
  // reading, so `a(b, c, d)(e);` in a function stays a call.
  MACRO_DECLARATOR: -5,
  ASSIGNMENT: -2,
  CONDITIONAL: -1,
  DEFAULT: 0,
  LOGICAL_OR: 1,
  LOGICAL_AND: 2,
  INCLUSIVE_OR: 3,
  EXCLUSIVE_OR: 4,
  BITWISE_AND: 5,
  EQUAL: 6,
  RELATIONAL: 7,
  OFFSETOF: 8,
  SHIFT: 9,
  ADD: 10,
  MULTIPLY: 11,
  CAST: 12,
  SIZEOF: 13,
  VA_ARG: 13,
  UNARY: 14,
  CALL: 15,
  FIELD: 16,
  SUBSCRIPT: 17,
};

module.exports = grammar({
  name: 'c',

  conflicts: $ => [
    [$._macro_loop_header, $.expression],
    [$._fragment_number, $.expression],
    [$._fragment_number, $._top_level_expression_statement],
    [$.type_specifier, $._declarator],
    [$.type_specifier, $._declarator, $.macro_type_specifier],
    [$.type_specifier, $.expression],
    [$.type_specifier, $.expression, $.macro_type_specifier],
    [$.type_specifier, $.macro_type_specifier],
    [$.type_specifier, $.sized_type_specifier],
    [$.sized_type_specifier],
    [$.attributed_statement],
    [$._declaration_modifiers, $.attributed_statement],
    [$.enum_specifier],
    [$.type_specifier, $._old_style_parameter_list],
    [$.parameter_list, $._old_style_parameter_list],
    [$.function_declarator, $._function_declaration_declarator],
    [$._block_item, $.statement],
    [$._top_level_item, $._top_level_statement],
    [$.type_qualifier, $.extension_expression],
    [$.sized_type_specifier, $._enum_underlying_type],
    [$._initialized_condition_declaration, $._declaration_declarators],
    [$.storage_class_specifier, $.type_specifier],
    [$._declaration_modifiers, $.labeled_statement],
    [$._declarator, $._non_function_declarator],
    [$.macro_statement, $.macro_modifier, $.type_specifier],
    [$.macro_statement, $.macro_function_definition, $.macro_modifier, $.type_specifier, $.expression, $.macro_type_specifier],
    [$.macro_statement, $.expression],
    [$.macro_statement, $.type_specifier, $.expression],
    [$.macro_statement, $.type_specifier, $._top_level_expression_statement],
    [$.macro_statement, $.type_specifier],
    [$.macro_statement, $.macro_modifier, $.sized_type_specifier],
    [$.macro_statement, $.macro_modifier],
    [$.macro_statement, $.concatenated_string],
    [$._old_style_function_definition, $._macro_declaration_specifiers],
    [$.macro_modifier, $.type_specifier],
    [$.macro_modifier, $.type_specifier, $.macro_type_specifier],
    [$.macro_modifier, $.sized_type_specifier],
    [$.macro_modifier, $.type_specifier, $.expression, $.macro_type_specifier],
    [$._macro_argument_list, $.argument_list],
    [$._macro_argument_list, $.macro_type_specifier],
    [$._macro_nested_call, $.type_specifier, $.expression, $.macro_type_specifier],
    [$.macro_statement, $.macro_function_definition, $.macro_modifier, $.macro_declarator, $.type_specifier, $.expression, $.macro_type_specifier],
    [$._macro_declaration_specifiers],
    [$._macro_declaration, $._macro_function_declaration, $._declaration_specifiers, $._macro_declaration_specifiers],
    [$.macro_type_declarator, $.type_specifier, $.macro_type_specifier],
    [$.compound_statement, $.initializer_list],
    [$._block_item, $.initializer_list],
    [$.macro_modifier, $._macro_declaration_call, $.type_specifier, $.macro_type_specifier],
    [$.macro_field_declarator, $.type_specifier, $.macro_type_specifier],
    [$.comma_expression, $.initializer_pair],
    [$.macro_declarator, $.type_specifier, $.macro_type_specifier],
    [$.initializer_fragment, $.comma_expression],
    [$._macro_argument_list, $.macro_declarator],
    [$._macro_argument_list, $.macro_declarator, $.macro_type_specifier],
    [$.macro_type_declarator, $.macro_type_specifier],
    [$._type_declarator, $.sized_type_specifier],
    [$._type_declarator, $.type_specifier],
    [$._type_declarator, $.type_specifier, $.macro_type_specifier],
    [$.macro_declarator, $._declarator, $.type_specifier, $.macro_type_specifier],
    [$._field_declarator, $.type_specifier, $.macro_type_specifier],
    [$._field_declarator, $.type_specifier],
    [$.initializer_fragment, $.initializer_list],
    [$.macro_modifier, $._macro_declaration_call, $.macro_declarator, $.type_specifier, $.macro_type_specifier],
    [$.initializer_fragment, $._initializer_list_run],
    [$.initializer_list],
    [$.type_specifier, $._macro_prefixed_argument],
    [$.type_specifier, $._macro_prefixed_parameter_declaration],
    [$._declarator, $.type_specifier, $._macro_prefixed_parameter_declaration],
    [$.macro_call_modifier, $.type_specifier, $._macro_prefixed_parameter_declaration],
    // macro conflicts
    [$.expression, $._initializer_macro_element],
    [$.macro_modifier, $._initializer_macro_element],
    [$.macro_function_definition, $._initializer_macro_element],
    [$.macro_statement, $.macro_function_definition, $.macro_modifier, $.type_specifier, $.expression, $._initializer_macro_element, $.macro_type_specifier],
    [$.function_declarator, $._bare_attributed_function_declarator],
    [$.function_declarator, $._function_declaration_declarator, $._bare_attributed_function_declarator],
    [$._declaration_declarators],
    [$.macro_call_modifier, $._declarator, $.type_specifier],
    [$.macro_declarator, $.macro_call_modifier, $._declarator, $.type_specifier, $.macro_type_specifier],
    [$.macro_call_modifier, $._field_declarator],
    [$.macro_call_modifier, $._type_declarator],
    [$.macro_call_modifier, $.type_specifier],
    [$.macro_declarator, $.macro_call_modifier, $.type_specifier, $.macro_type_specifier],
    [$.macro_modifier, $.macro_field_declarator, $.type_specifier, $.macro_type_specifier],
    [$.macro_call_modifier, $._declarator],
    // Diab asm macros: `asm volatile int f(…)` against `asm volatile ("…")`.
    [$.storage_class_specifier, $.gnu_asm_qualifier],
    [$.type_qualifier, $.gnu_asm_qualifier],
    // Section macros after a declarator: `Lock[] OS_SECTION_POST(.bss.x);`.
    [$.macro_call_modifier, $._declarator, $._non_function_declarator],
    [$.macro_modifier, $.macro_field_declarator, $.type_specifier, $._field_macro_statement, $.macro_type_specifier],
    [$.macro_statement, $.macro_modifier, $.type_specifier, $.expression, $.macro_type_specifier],
    [$._declaration_modifiers, $.type_descriptor],
    [$._macro_argument_list, $.macro_field_declarator],
    [$._macro_argument_list, $.macro_field_declarator, $.macro_type_specifier],
    [$._macro_attribute_call, $._declarator],
    [$.macro_call_modifier, $._declaration_declarator, $.init_declarator],
    [$.macro_statement, $.macro_modifier, $.type_specifier, $._macro_gnu_asm_expression],
    [$.macro_statement, $._macro_gnu_asm_expression],
    [$.type_specifier, $._macro_gnu_asm_expression],
    [$.macro_modifier, $.type_specifier, $._macro_gnu_asm_expression],
    [$._declarator_macro_qualifiers, $.type_specifier],
    [$._declarator_macro_qualifiers, $.sized_type_specifier],
    [$._declarator_macro_qualifiers, $.type_specifier, $._macro_gnu_asm_expression],
    [$._declarator_macro_qualifier, $.macro_call_modifier],
    [$._declarator_macro_qualifiers],
    [$.type_descriptor, $._macro_type_descriptor],
    [$.concatenated_string, $._string_macro_call],
    [$._initializer_list_run, $._initializer_macro_terminated],
    [$._declarator_macro_qualifiers, $.type_specifier, $.sized_type_specifier],
    [$.type_specifier, $.expression, $._macro_pointer_type_argument],
    [$.expression, $._macro_pointer_type_argument],
    [$._field_macro_statement],
    [$.cast_expression, $.type_descriptor, $._macro_type_descriptor],
    [$._macro_prefixed_argument, $.concatenated_string],
    [$.concatenated_string],
    // @auto-conflicts-end
  ],

  extras: $ => [
    /\s|\\\r?\n/,
    $.comment,
    $.preproc_conditional_line,
    $.preproc_line_marker,
  ],

  inline: $ => [
    $._type_identifier,
    $._field_identifier,
    $._statement_identifier,
    $._non_case_statement,
    $._assignment_left_expression,
    $._expression_not_binary,
  ],

  supertypes: $ => [
    $.expression,
    $.statement,
    $.type_specifier,
    $._declarator,
    $._field_declarator,
    $._type_declarator,
    $._abstract_declarator,
  ],

  word: $ => $.identifier,

  rules: {
    translation_unit: $ => repeat($._top_level_item),

    // Top level items are block items with the exception of the expression statement
    _top_level_item: $ => choice(
      $.function_definition,
      alias($._old_style_function_definition, $.function_definition),
      alias($._asm_function_definition, $.function_definition),
      $.linkage_specification,
      $.declaration,
      $._top_level_statement,
      $.attributed_statement,
      $.type_definition,
      $._empty_declaration,
      $.macro_function_definition,
      $.macro_statement,
      alias($._macro_assignment_statement, $.expression_statement),
      alias($._macro_function_type_definition, $.type_definition),
      alias($._macro_function_declaration, $.declaration),
      alias($._macro_declaration, $.declaration),
      $.initializer_fragment,
      alias($._preproc_function_definition, $.function_definition),
      $.preproc_if,
      $.preproc_ifdef,
      alias($._preproc_if_linkage, $.preproc_if),
      alias($._preproc_ifdef_linkage, $.preproc_ifdef),
      $.preproc_include,
      $.preproc_embed,
      $.preproc_def,
      $.preproc_function_def,
      $.preproc_call,
      $.preproc_null,
    ),

    _block_item: $ => choice(
      $.function_definition,
      alias($._old_style_function_definition, $.function_definition),
      alias($._asm_function_definition, $.function_definition),
      $.linkage_specification,
      $.declaration,
      $.statement,
      $.else_clause,
      $.attributed_statement,
      $.type_definition,
      $._empty_declaration,
      $.macro_function_definition,
      $.macro_statement,
      alias($._macro_assignment_statement, $.expression_statement),
      alias($._macro_function_type_definition, $.type_definition),
      alias($._macro_function_declaration, $.declaration),
      alias($._macro_declaration, $.declaration),
      $.initializer_fragment,
      alias($._preproc_function_definition, $.function_definition),
      $.preproc_if,
      $.preproc_ifdef,
      alias($._preproc_if_linkage, $.preproc_if),
      alias($._preproc_ifdef_linkage, $.preproc_ifdef),
      $.preproc_include,
      $.preproc_embed,
      $.preproc_def,
      $.preproc_function_def,
      $.preproc_call,
      $.preproc_null,
    ),

    // Macros the preprocessor would expand, which a parser without it cannot see
    // through. Each form has a negative dynamic precedence, so it is only chosen
    // when no plain C reading of the same code exists.

    // A macro that stands for a whole declaration or statement, written without
    // a semicolon: `OS_PARAMETERACCESS_DECL`, `TEST_ACTIONS`,
    // `TS_PREVENTEMPTYTRANSLATIONUNIT`, `E2EPW_DEFVAR1(In, Type, Port)`,
    // `DefStubFunc(void, X_INIT, void)`. Arguments are those of a call
    // (argument_list), or types.
    macro_statement: $ => prec.dynamic(PREC.MACRO_STATEMENT, seq(
      field('name', $.identifier),
      optional(field('arguments', alias($._macro_argument_list, $.argument_list))),
    )),

    // An assignment from a macro whose expansion ends in the semicolon:
    // `n = Get_counter(m, c)` under `#define Get_counter(m, c) (...);`.
    _macro_assignment_statement: $ => prec.dynamic(PREC.MACRO_STATEMENT, alias($._macro_assignment, $.assignment_expression)),
    _macro_assignment: $ => seq(
      field('left', $._assignment_left_expression),
      field('operator', '='),
      field('right', alias($._macro_loop_header, $.call_expression)),
    ),

    _macro_argument_list: $ => seq(
      '(',
      optional(seq(
      // A first argument left empty: `COU_CALL(, "t+1")`.
      optional(','),
      commaSep1(choice(
        $.expression,
        $.compound_statement,
        $.initializer_pair,
        prec.dynamic(-1, $.type_descriptor),
        // A declaration the macro wraps: `VAR_ALIGN(uint8 buf[4], 32)`,
        // `OS_Cfg_app_decl(const os_appcontext_t *app)`.
        alias($._macro_parameter_argument, $.parameter_declaration),
        alias($._operator_argument, $.operator),
        alias($._section_name, $.section_name),
        // A statement the macro runs: `COU_CALL(State = 2;, "set State")`.
        alias($._macro_statement_argument, $.expression_statement),
        alias($._macro_statements_argument, $.compound_statement),
        // A macro call inside one that takes statements in turn:
        // `COU_FOR(200, COU_CALL(Step(); MAIN(), "run"))`.
        prec.dynamic(-1, alias($._macro_nested_call, $.call_expression)),
      )),
      )),
      optional(','),
      ')',
    ),

    _macro_nested_call: $ => seq(
      field('function', $.identifier),
      field('arguments', alias($._macro_argument_list, $.argument_list)),
    ),

    _macro_statement_argument: $ => seq($.expression, ';'),

    // Several statements, or a loop, the macro runs: `COU_SET_BY_CALL(for (i = 0;
    // i < 9; i++) q[i] = 0; n = 2;, "init")`; the last one may go without its
    // semicolon: `COU_CALL_FOR(4, CLOCK = 5; MAIN(), "run")`.
    // (A comma after the last expression ends the argument, rather than making
    // it the start of a comma expression; and no comma expression statements,
    // which would keep that second reading open at every argument.)
    _macro_statements_argument: $ => choice(
      prec(1, seq($._macro_statement_item, repeat1($._macro_statement_item), optional($.expression))),
      prec(1, seq($._macro_statement_item, $.expression)),
      $._macro_loop_statement,
    ),
    _macro_statement_item: $ => choice(
      alias($._macro_statement_argument, $.expression_statement),
      $._macro_loop_statement,
    ),
    _macro_loop_statement: $ => choice(
      $.for_statement,
      $.while_statement,
      $.do_statement,
      $.if_statement,
    ),

    // (Below an expression, so `M(a * b)` stays a product.)
    _macro_parameter_argument: $ => prec.dynamic(-2, seq(
      $._declaration_specifiers,
      field('declarator', $._declarator),
    )),

    // An operator a macro pastes into its body: `ADJUST(a, b, FALSE, ++)`.
    _operator_argument: _ => choice(
      '++', '--', '+', '-', '*', '/', '%', '&', '|', '^', '<<', '>>', '!', '~',
      '==', '!=', '<', '>', '<=', '>=', '&&', '||',
      '=', '+=', '-=', '*=', '/=', '%=', '&=', '|=', '^=', '<<=', '>>=',
    ),

    // A linker section a macro turns into an attribute or pragma:
    // `OS_SECTION_ATTRIB_PRE(.bss.shared.os.OS_syncArray)`. At least two
    // parts, so a designator in an argument (`INIT(.a = 1)`) stays one.
    _section_name: _ => /\.[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)+/,

    // A macro that opens a function body, as unit-test frameworks use:
    // `COU_TEST(TestCase_001, "Init") { … }`.
    macro_function_definition: $ => prec.dynamic(PREC.MACRO, seq(
      field('name', $.identifier),
      field('arguments', $.argument_list),
      field('body', $.compound_statement),
    )),

    // A storage class, memory section or inline macro in front of the type:
    // `STATIC FUNC(void, X_CODE) f(void)`, `Global_static void f(void);`,
    // `Local_ram(Comp) uint8 counter;`.
    macro_modifier: $ => prec.dynamic(PREC.MACRO, seq(
      field('name', $.identifier),
      optional(field('arguments', $.argument_list)),
    )),

    // A macro that stands for a whole declaration, after a storage class:
    // `static TS_DefMaxAlignedByteArray(PduR_Mem, PDUR, VAR_NOINIT, SIZE);`.
    // Also C89 implicit int, a storage class and a name without a type:
    // `extern HsmDrvExtsn_LifecycleStateUpdateFlag;`, `extern suites[];`. (Here
    // rather than in `declaration`, so the parser does not keep a second
    // reading open after every storage class followed by a name.) And a storage
    // class in front of a struct, union or enum declared without a variable:
    // `extern struct PduInfoType_s;`.
    _macro_declaration: $ => prec.dynamic(PREC.MACRO, seq(
      repeat1($._declaration_modifiers),
      choice(
        field('declarator', choice(
          alias($._macro_declaration_call, $.macro_statement),
          $.identifier,
          alias($._implicit_int_array_declarator, $.array_declarator),
        )),
        field('type', choice($.struct_specifier, $.union_specifier, $.enum_specifier)),
      ),
      ';',
    )),
    _implicit_int_array_declarator: $ => seq(
      field('declarator', $.identifier),
      '[',
      optional(field('size', $.expression)),
      ']',
    ),

    // (Spelled out rather than reusing macro_statement, whose precedence would
    // count twice.)
    _macro_declaration_call: $ => seq(
      field('name', $.identifier),
      field('arguments', alias($._macro_argument_list, $.argument_list)),
    ),

    // AUTOSAR function pointers, where one macro wraps the return type, the
    // memory class and the name, and the parameters follow it:
    // `P2FUNC(void, CODE, Cbk)(uint8 x)` stands for `void (*Cbk)(uint8 x)`;
    // `CONSTP2FUNC(void, CODE, Tbl[4])(void)` and
    // `VSECPRIM_P2FUNC(NONE, void, watchdog)(void)` likewise. The declarator is
    // the last argument, and no type comes before the macro, so typedefs,
    // declarations, fields and parameters each get a form of their own.
    macro_declarator: $ => prec.dynamic(PREC.MACRO_DECLARATOR, seq(
      field('name', $.identifier),
      '(',
      repeat1(seq(field('argument', choice($.type_descriptor, $.type_qualifier)), ',')),
      field('declarator', $._declarator),
      ')',
    )),
    macro_field_declarator: $ => prec.dynamic(PREC.MACRO_DECLARATOR, seq(
      field('name', $.identifier),
      '(',
      repeat1(seq(field('argument', choice($.type_descriptor, $.type_qualifier)), ',')),
      field('declarator', $._field_declarator),
      ')',
    )),
    macro_type_declarator: $ => prec.dynamic(PREC.MACRO_DECLARATOR, seq(
      field('name', $.identifier),
      '(',
      repeat1(seq(field('argument', choice($.type_descriptor, $.type_qualifier)), ',')),
      field('declarator', $._type_declarator),
      ')',
    )),

    _macro_function_declarator: $ => seq(
      field('declarator', $.macro_declarator),
      field('parameters', $.parameter_list),
      repeat($.attribute_specifier),
    ),
    _macro_function_field_declarator: $ => seq(
      field('declarator', alias($.macro_field_declarator, $.macro_declarator)),
      field('parameters', $.parameter_list),
    ),
    _macro_function_type_declarator: $ => seq(
      field('declarator', alias($.macro_type_declarator, $.macro_declarator)),
      field('parameters', $.parameter_list),
    ),

    _macro_function_type_definition: $ => seq(
      optional('__extension__'),
      'typedef',
      repeat($.type_qualifier),
      field('declarator', alias($._macro_function_type_declarator, $.function_declarator)),
      repeat($.attribute_specifier),
      ';',
    ),

    // Only after a storage class or qualifier (`extern`, `static`, `const`):
    // without one, `OS_DECL  g(1);` would have one more reading to keep at `g(`,
    // enough for the parser to drop the right one. Bare, the plain C reading of
    // a function returning a function has no error either.
    _macro_function_declaration: $ => seq(
      repeat1($._declaration_modifiers),
      field('declarator', choice(
        alias($._macro_function_declarator, $.function_declarator),
        alias($._macro_function_init_declarator, $.init_declarator),
      )),
      ';',
    ),

    _macro_function_init_declarator: $ => seq(
      field('declarator', alias($._macro_function_declarator, $.function_declarator)),
      '=',
      field('value', choice($.initializer_list, $.expression)),
    ),

    _macro_function_field_declaration: $ => seq(
      repeat($._declaration_modifiers),
      field('declarator', alias($._macro_function_field_declarator, $.function_declarator)),
      ';',
    ),

    _macro_function_parameter_declaration: $ => seq(
      repeat($._declaration_modifiers),
      field('declarator', alias($._macro_function_declarator, $.function_declarator)),
    ),

    // A file that holds only the elements of an initializer, to be included
    // inside one: `Dil_failure_a,` or `{0 | (Mask_a), 0}` lines, often each under
    // its own `#if`. The last braced element may go without its comma, and so
    // may a last number (`0/*closing element*/`).
    initializer_fragment: $ => prec.dynamic(PREC.MACRO, choice(
      seq(choice($.expression, $.initializer_pair), ','),
      seq($.initializer_list, optional(',')),
      $._fragment_number,
    )),
    _fragment_number: $ => prec.dynamic(-1, $.number_literal),

    // A function whose head differs per configuration, with the body after the
    // `#endif`, one head per branch:
    // `#if (X)  void f(uint8 a)  #else  void f(void)  #endif  { … }` or
    // `#if (CAT1)  IFX_INTERRUPT(Isr, 0, Prio)  #elif (CAT2)  ISR(Isr)  #endif  { … }`.
    // The first branch with a declarator names the function.
    _preproc_function_definition: $ => seq(
      choice(
        seq(preprocessor('if'), $._preproc_expression, '\n'),
        seq(choice(preprocessor('ifdef'), preprocessor('ifndef')), $.identifier),
      ),
      $._function_head,
      optional($._preproc_function_head_alternative),
      preprocessor('endif'),
      field('body', $.compound_statement),
    ),

    _preproc_function_head_alternative: $ => choice(
      seq(preprocessor('else'), $._function_head),
      seq(
        preprocessor('elif'),
        $._preproc_expression,
        '\n',
        $._function_head,
        optional($._preproc_function_head_alternative),
      ),
    ),

    _function_head: $ => choice(
      seq(
        optional($.ms_call_modifier),
        $._macro_declaration_specifiers,
        $._call_modified_declarator,
      ),
      $.macro_modifier,
    ),

    // The braces of `extern "C"` split over two conditional blocks, as C headers
    // write it for C++ compilers:
    // `#ifdef __cplusplus  extern "C" {  #endif` … `#ifdef __cplusplus  }  #endif`.
    _preproc_ifdef_linkage: $ => seq(
      choice(preprocessor('ifdef'), preprocessor('ifndef')),
      field('name', $.identifier),
      choice(alias($._linkage_open, $.linkage_specification), '}'),
      preprocessor('endif'),
    ),

    _preproc_if_linkage: $ => seq(
      preprocessor('if'),
      field('condition', $._preproc_expression),
      '\n',
      choice(alias($._linkage_open, $.linkage_specification), '}'),
      preprocessor('endif'),
    ),

    _linkage_open: $ => seq('extern', field('value', $.string_literal), '{'),

    // Preprocesser

    preproc_include: $ => seq(
      preprocessor('include'),
      choice(
        // Compilers only warn about extra tokens after a quoted or bracketed
        // path (`#include <pstunit.h>/`), so the line still ends the include.
        // A comment after the path stays a comment.
        seq(
          field('path', choice($.string_literal, $.system_lib_string)),
          token.immediate(/[ \t]*([^\s\/][^\r\n]*|\/([^\/*\r\n][^\r\n]*)?)?\r?\n/),
        ),
        seq(
          field('path', choice(
            $.identifier,
            alias($.preproc_call_expression, $.call_expression),
          )),
          token.immediate(/[ \t]*\r?\n/),
        ),
      ),
    ),

    // C23 #embed. Parameters are limit/prefix/suffix/if_empty, each (balanced tokens).
    preproc_embed: $ => seq(
      preprocessor('embed'),
      field('path', choice(
        $.string_literal,
        $.system_lib_string,
        $.identifier,
        alias($.preproc_call_expression, $.call_expression),
      )),
      repeat($.preproc_embed_parameter),
      token.immediate(/[ \t]*\r?\n/),
    ),

    preproc_embed_parameter: $ => seq(
      field('name', $.identifier),
      '(',
      repeat($._embed_parameter_token),
      ')',
    ),

    _embed_parameter_token: $ => choice(
      alias(token(prec(-1, /[^()\n]+/)), $.preproc_arg),
      seq('(', repeat($._embed_parameter_token), ')'),
    ),

    preproc_def: $ => seq(
      preprocessor('define'),
      field('name', $.identifier),
      field('value', optional($.preproc_arg)),
      token.immediate(/[ \t]*\r?\n/),
    ),

    preproc_function_def: $ => seq(
      preprocessor('define'),
      field('name', $.identifier),
      field('parameters', $.preproc_params),
      field('value', optional($.preproc_arg)),
      token.immediate(/[ \t]*\r?\n/),
    ),

    preproc_params: $ => seq(
      token.immediate('('), commaSep(choice($.identifier, '...')), ')',
    ),

    preproc_call: $ => seq(
      field('directive', $.preproc_directive),
      field('argument', optional($.preproc_arg)),
      token.immediate(/[ \t]*\r?\n/),
    ),

    ...preprocIf('', $ => $._block_item),
    ...preprocIf('_in_field_declaration_list', $ => $._field_declaration_list_item),
    ...preprocIf('_in_enumerator_list', $ => seq($.enumerator, ',')),
    ...preprocIf('_in_enumerator_list_no_comma', $ => $.enumerator, -1),

    // A conditional directive where it cannot open or close a preproc_if block:
    // in the middle of an expression, an argument or parameter list, or an
    // initializer, e.g. `if ( #if X (a) #else (b) #endif && c )`. Without the
    // preprocessor that code is incomplete, so the line is skipped like a
    // comment. Its lexical precedence is below the `#if`/`#else`/`#endif`
    // tokens, so wherever those are valid they still build a preproc_if.
    // A block comment that starts on the line belongs to it to its end, also
    // over several lines: `#endif /* X */ /* PRQA S 2053\n * reason: … */`.
    preproc_conditional_line: _ => token(prec(-2, seq(
      /#[ \t]*(if|elif|else|endif)/,
      /(\\\r?\n|\\[^\r\n]|\/\*([^*]|\*+[^*\/])*\*+\/|[^\\\r\n])*/,
    ))),

    // A comment inside the value stays in it when more value or a line
    // continuation follows, also after several comments in a row:
    // `#define M(x) do /* a *//* b */\` (the comment after the last code
    // stays out, so the line still ends the directive).
    preproc_arg: _ => token(prec(-1, /\S([^/\n]|(\/\*[^*]*\*+([^/*][^*]*\*+)*\/)+(\\\r?\n|[^\n/]|\/[^*\n])|\/[^*]|\\\r?\n)*/)),
    preproc_directive: _ => /#[ \t]*[a-zA-Z0-9]\w*/,

    // A line marker of preprocessed output (`# 139 "math_lib.he"`) in the
    // middle of a declaration or statement, where no directive can start:
    // `extern T f(T x)` `# 139 "m.he"` `;`. (Where a directive can start it
    // stays a preproc_call, like a conditional line.)
    preproc_line_marker: _ => token(prec(-2, seq(
      /#[ \t]*(line[ \t]+)?[0-9]+/,
      /[^\r\n]*/,
    ))),

    // The null directive: a `#` with no directive name, alone on its line or
    // before a comment (`#/** @file … */`). The preprocessor ignores it.
    preproc_null: _ => token(prec(-3, /#[ \t]*/)),

    _preproc_expression: $ => choice(
      $.identifier,
      alias($.preproc_call_expression, $.call_expression),
      $.number_literal,
      $.char_literal,
      $.preproc_defined,
      alias($.preproc_unary_expression, $.unary_expression),
      alias($.preproc_binary_expression, $.binary_expression),
      alias($.preproc_parenthesized_expression, $.parenthesized_expression),
    ),

    preproc_parenthesized_expression: $ => seq(
      '(',
      $._preproc_expression,
      ')',
    ),

    preproc_defined: $ => choice(
      prec(PREC.CALL, seq('defined', '(', $.identifier, ')')),
      seq('defined', $.identifier),
    ),

    preproc_unary_expression: $ => prec.left(PREC.UNARY, seq(
      field('operator', choice('!', '~', '-', '+')),
      field('argument', $._preproc_expression),
    )),

    preproc_call_expression: $ => prec(PREC.CALL, seq(
      field('function', $.identifier),
      field('arguments', alias($.preproc_argument_list, $.argument_list)),
    )),

    preproc_argument_list: $ => seq(
      '(',
      commaSep(choice(
        $._preproc_expression,
        $.string_literal,
        $.system_lib_string,
        alias($._section_name, $.section_name),
      )),
      ')',
    ),

    preproc_binary_expression: $ => {
      const table = [
        ['+', PREC.ADD],
        ['-', PREC.ADD],
        ['*', PREC.MULTIPLY],
        ['/', PREC.MULTIPLY],
        ['%', PREC.MULTIPLY],
        ['||', PREC.LOGICAL_OR],
        ['&&', PREC.LOGICAL_AND],
        ['|', PREC.INCLUSIVE_OR],
        ['^', PREC.EXCLUSIVE_OR],
        ['&', PREC.BITWISE_AND],
        ['==', PREC.EQUAL],
        ['!=', PREC.EQUAL],
        ['>', PREC.RELATIONAL],
        ['>=', PREC.RELATIONAL],
        ['<=', PREC.RELATIONAL],
        ['<', PREC.RELATIONAL],
        ['<<', PREC.SHIFT],
        ['>>', PREC.SHIFT],
      ];

      return choice(...table.map(([operator, precedence]) => {
        return prec.left(precedence, seq(
          field('left', $._preproc_expression),
          // @ts-ignore
          field('operator', operator),
          field('right', $._preproc_expression),
        ));
      }));
    },

    // Main Grammar

    function_definition: $ => seq(
      optional($.ms_call_modifier),
      $._macro_declaration_specifiers,
      $._call_modified_declarator,
      field('body', choice(
        $.compound_statement,
        // `OS_TOOL_ASM_KEYWORD volatile int f(int x) {` with `#define
        // OS_TOOL_ASM_KEYWORD __asm`: a Diab asm macro behind a macro.
        alias($._asm_macro_storage_body, $.asm_block),
      )),
    ),

    // Diab (Wind River) asm macro functions, inlined assembly with C
    // parameters: `asm volatile int f(int x)` followed by a body of storage
    // mode lines (`% reg x; mem y`), the clobber list (`! "%d2"`) and
    // assembly, up to the `}` that starts a line.
    _asm_function_definition: $ => seq(
      choice('asm', '__asm'),
      $._declaration_specifiers,
      field('declarator', $._declarator),
      field('body', alias($._asm_macro_body, $.asm_block)),
    ),

    // (Tokens, so the assembly inside is never read as C.) After `asm` the
    // body is assembly even without storage mode lines or a clobber list:
    // `asm uint32_t __get_pir(void)` `{` `mfspr r3, PIR` `}`.
    _asm_macro_body: _ => token(seq(
      '{',
      /([ \t]|\/\*[^*]*\*+([^/*][^*]*\*+)*\/)*/,
      /\r?(\n([^}\n][^\n]*)?)*\n\}/,
    )),
    _asm_macro_storage_body: _ => token(seq(
      '{',
      /([ \t]|\/\*[^*]*\*+([^/*][^*]*\*+)*\/)*/,
      // A storage mode line, or a clobber list (`!` alone, `! "%d2"` or
      // `! /* none */`): no C statement starts a block that way.
      /\r?\n(%[^\n]*|![ \t]*("[^\n]*|\/\*[^\n]*)?\r?)(\n([^}\n][^\n]*)?)*\n\}/,
    )),

    _old_style_function_definition: $ => seq(
      optional($.ms_call_modifier),
      $._declaration_specifiers,
      field('declarator', alias($._old_style_function_declarator, $.function_declarator)),
      repeat1($.declaration),
      field('body', $.compound_statement),
    ),

    declaration: $ => choice(
      seq(
        $._macro_declaration_specifiers,
        $._declaration_declarators,
        ';',
      ),
      seq(
        $._macro_declaration_specifiers,
        optional(seq($._declaration_declarators, ',')),
        field('declarator', alias($._bare_attributed_function_declarator, $.function_declarator)),
        ';',
      ),
    ),

    // C2Y if/switch headers (N3356). The semicolon belongs to the header, not
    // the declaration. Alias at the use site: aliasing the sequence itself
    // splits the node.
    _condition_declaration: $ => seq(
      $._declaration_specifiers,
      $._declaration_declarators,
    ),

    // Simple `if (declaration)` requires an initializer, so `if (a * b)` stays
    // an expression. `if (foo * bar = 1)` is a declaration, same as `for`.
    // The expression form is `if (foo * (bar = 1))`.
    _initialized_condition_declaration: $ => seq(
      $._declaration_specifiers,
      commaSep1(field('declarator', $.init_declarator)),
    ),

    _declaration_declarators: $ => commaSep1(field('declarator', choice(
      seq(
        optional($.ms_call_modifier),
        $._declaration_declarator,
        optional($.gnu_asm_expression),
      ),
      // A macro calling convention is never followed by a star: in
      // `XMLPUBFUN xmlChar * XMLCALL f(void);` the type is `xmlChar`, not a
      // `XMLPUBFUN` type followed by an `xmlChar` calling convention.
      seq(
        $.macro_call_modifier,
        choice(
          $.attributed_declarator,
          alias($._function_declaration_declarator, $.function_declarator),
          $.array_declarator,
          $.parenthesized_declarator,
          $.identifier,
        ),
        optional($.gnu_asm_expression),
      ),
      $.init_declarator,
      // Section and alignment macros after the type:
      // `os_syncspot_t OS_SECTION_ATTRIB_PRE(.bss.os.Lock) OS_ALIGNED(8) Lock[];`.
      // (Here rather than after the type in _macro_declaration_specifiers,
      // where the parser had to keep two readings open at every declarator
      // name, until the section token after it settles it here.)
      seq(
        alias($._section_macro_call, $.macro_modifier),
        repeat(alias($._macro_attribute_call, $.macro_modifier)),
        choice($._declaration_declarator, $.init_declarator),
      ),
      // A memory class macro between the type and the star:
      // `osqROM0 TaskType osqPTcbRAM3 * osqROM1 const q[4] = {0};`,
      // `T osqROM1 const *p;`. (One macro: further ones belong to the type.
      // More would keep a reading open at every name of a run of macro lines
      // without semicolons. It costs more than a macro in front of the type,
      // so `XMLPUBFUN xmlChar * XMLCALL f(void);` keeps `xmlChar` as its type.)
      prec.dynamic(PREC.MACRO - 1, seq(
        $._declarator_macro_qualifier,
        choice($.pointer_declarator, alias($._pointer_init_declarator, $.init_declarator)),
      )),
      // and before an initialized name: `T osqROM3 table[2] = {0};`.
      seq(
        $.macro_call_modifier,
        alias($._macro_qualified_init_declarator, $.init_declarator),
      ),
    ))),

    _declarator_macro_qualifier: $ => seq(
      alias($.identifier, $.macro_modifier),
      repeat($.type_qualifier),
    ),

    _declarator_macro_qualifiers: $ => seq(
      alias($.identifier, $.macro_modifier),
      repeat(choice(alias($.identifier, $.macro_modifier), $.type_qualifier)),
    ),

    _pointer_init_declarator: $ => seq(
      field('declarator', $.pointer_declarator),
      '=',
      field('value', choice($.initializer_list, $.expression)),
    ),

    // (Not a function: `T X f(T) Y(a)` stays a run of macro lines.)
    _macro_qualified_init_declarator: $ => seq(
      field('declarator', choice($.array_declarator, $.identifier)),
      '=',
      field('value', choice($.initializer_list, $.expression)),
    ),

    _declarator_macro_qualifiers: $ => seq(
      alias($.identifier, $.macro_modifier),
      repeat(choice(alias($.identifier, $.macro_modifier), $.type_qualifier)),
    ),

    type_definition: $ => seq(
      optional('__extension__'),
      'typedef',
      $._type_definition_type,
      repeat($.attribute_specifier),
      $._type_definition_declarators,
      // `typedef void (*F)(const char *msg, ...) LIBXML_ATTR_FORMAT(2,3);`
      repeat(choice(
        $.attribute_specifier,
        alias($._trailing_macro_call, $.call_expression),
      )),
      ';',
    ),
    _type_definition_type: $ => choice(
      seq(repeat($.type_qualifier), field('type', $.type_specifier), repeat($.type_qualifier)),
      // Memory or debug macros in front of the type:
      // `typedef DBGVAR const struct S_t * S_cpot;`, `typedef FAR void (*F)(void);`.
      prec.dynamic(PREC.MACRO, seq(
        repeat($.type_qualifier),
        $._declarator_macro_qualifiers,
        field('type', $.type_specifier),
        repeat($.type_qualifier),
      )),
    ),
    _type_definition_declarators: $ => choice(
      commaSep1(field('declarator', $._type_declarator)),
      // A calling-convention macro before a function pointer type:
      // `typedef void DESC_API_CALL_TYPE (*DescPreHandler)(void);`.
      seq(
        $.macro_call_modifier,
        field('declarator', alias($.function_type_declarator, $.function_declarator)),
      ),
    ),

    _declaration_modifiers: $ => choice(
      $.storage_class_specifier,
      $.type_qualifier,
      $.attribute_specifier,
      $.attribute_declaration,
      $.ms_declspec_modifier,
    ),

    _declaration_specifiers: $ => prec.right(seq(
      repeat($._declaration_modifiers),
      field('type', $.type_specifier),
      repeat($._declaration_modifiers),
    )),

    // Declarations, function definitions and struct fields also take macro
    // modifiers in front of the type: `VX_VOLATILE VX_UINT32 count;`.
    // Parameters do not: `uint32 objectId` would read both ways.
    _macro_declaration_specifiers: $ => choice(
      $._declaration_specifiers,
      $._macro_prefixed_declaration_specifiers,
    ),

    // With a storage class in front, `extern STATIC FUNC(T, CODE) f(P2CONST(…) p)`,
    // the macro reading scores a little higher. Without that, junk readings of
    // the parameter list (`FUNC(…)` as the declarator and `f(…)` as a trailing
    // macro call) outranked it and the parser, out of parallel readings, dropped
    // it. (Only behind a storage class: a bare `OS_DECL g(1);` keeps its macro
    // statement and call.)
    _macro_prefixed_declaration_specifiers: $ => choice(
      prec.right(seq(
        $.macro_modifier,
        repeat(choice($._declaration_modifiers, $.macro_modifier)),
        field('type', $.type_specifier),
        repeat($._declaration_modifiers),
      )),
      prec.dynamic(1, prec.right(seq(
        repeat1($._declaration_modifiers),
        $.macro_modifier,
        repeat(choice($._declaration_modifiers, $.macro_modifier)),
        field('type', $.type_specifier),
        repeat($._declaration_modifiers),
      ))),
    ),

    // More macros after a section macro: `OS_ALIGNED_ATTRIB_PRE(GRANULE)`.
    // (Spelled out rather than reusing macro_modifier, whose arguments are
    // optional: a bare name there is the declarator. Only reached after a
    // section macro, it wins over a function declarator `ALIGNED(GRANULE)`
    // followed by the name.)
    _macro_attribute_call: $ => prec.dynamic(1, seq(
      field('name', $.identifier),
      field('arguments', $.argument_list),
    )),

    // The first macro after the type, or after a plain declarator, names a
    // linker section: `OS_SECTION_ATTRIB_PRE(.bss.os.Lock)`. Its argument list
    // is one token, so the lexer settles it. With an ordinary macro call there
    // the parser kept a second reading open at every `name (` after a type
    // (`void f (void)` as `void` plus a call `f(void)`), and after a few macro
    // lines without semicolons (`FuncGen_X(EvOrc)`) it ran out of parallel
    // readings and dropped the right one. (The name stays a plain identifier:
    // a token that also took the name overlapped every identifier, which kept
    // the parser from merging states and had the same effect.) Used in
    // _declaration_declarators, init_declarator and sectionSuffixedDeclarators.
    _section_macro_call: $ => seq(
      field('function', $.identifier),
      field('arguments', alias($._section_arguments, $.argument_list)),
    ),

    _section_arguments: _ => token(seq(
      /\([ \t]*/,
      /\.[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)+/,
      /[ \t]*\)/,
    )),

    linkage_specification: $ => seq(
      'extern',
      field('value', $.string_literal),
      field('body', choice(
        $.function_definition,
        $.declaration,
        $.declaration_list,
      )),
    ),

    attribute_specifier: $ => seq(
      choice('__attribute__', '__attribute'),
      '(',
      $.argument_list,
      ')',
    ),

    attribute: $ => seq(
      optional(seq(field('prefix', $.identifier), '::')),
      field('name', $.identifier),
      optional($.argument_list),
    ),

    attribute_declaration: $ => seq(
      '[[',
      commaSep1($.attribute),
      ']]',
    ),

    ms_declspec_modifier: $ => seq(
      '__declspec',
      '(',
      $.identifier,
      ')',
    ),

    ms_based_modifier: $ => seq(
      '__based',
      $.argument_list,
    ),

    // A calling-convention macro between the type and the name:
    // `XMLPUBFUN int XMLCALL xmlInit(void);`, `void (XMLCALL *xmlFree)(void *);`.
    _call_modifier: $ => choice($.ms_call_modifier, $.macro_call_modifier),

    // A function's declarator after its type, with the calling convention
    // before it; a macro one is never followed by a star (see
    // _declaration_declarators).
    _call_modified_declarator: $ => choice(
      seq(optional($.ms_call_modifier), field('declarator', $._declarator)),
      seq($.macro_call_modifier, field('declarator', choice(
        $.attributed_declarator,
        $.function_declarator,
        $.array_declarator,
        $.parenthesized_declarator,
        $.identifier,
      ))),
    ),

    macro_call_modifier: $ => prec.dynamic(PREC.MACRO, field('name', $.identifier)),

    ms_call_modifier: _ => choice(
      '__cdecl',
      '__clrcall',
      '__stdcall',
      '__fastcall',
      '__thiscall',
      '__vectorcall',
    ),

    ms_restrict_modifier: _ => '__restrict',

    ms_unsigned_ptr_modifier: _ => '__uptr',

    ms_signed_ptr_modifier: _ => '__sptr',

    ms_unaligned_ptr_modifier: _ => choice('_unaligned', '__unaligned'),

    ms_pointer_modifier: $ => choice(
      $.ms_unaligned_ptr_modifier,
      $.ms_restrict_modifier,
      $.ms_unsigned_ptr_modifier,
      $.ms_signed_ptr_modifier,
    ),

    declaration_list: $ => seq(
      '{',
      repeat($._block_item),
      '}',
    ),

    _declarator: $ => choice(
      $.attributed_declarator,
      $.pointer_declarator,
      $.function_declarator,
      $.array_declarator,
      $.parenthesized_declarator,
      $.identifier,
    ),

    _declaration_declarator: $ => choice(
      $.attributed_declarator,
      seq($._non_function_declarator, repeat1($.attribute_specifier)),
      // `Lock[] OS_SECTION_ATTRIB_POST(.bss.os.Lock);`
      ...sectionSuffixedDeclarators($),
      $._non_function_declarator,
      alias($._function_declaration_declarator, $.function_declarator),
    ),

    _non_function_declarator: $ => choice(
      $.pointer_declarator,
      $.array_declarator,
      $.parenthesized_declarator,
      $.identifier,
    ),

    _field_declarator: $ => choice(
      alias($.attributed_field_declarator, $.attributed_declarator),
      alias($.pointer_field_declarator, $.pointer_declarator),
      alias($.function_field_declarator, $.function_declarator),
      alias($.array_field_declarator, $.array_declarator),
      alias($.parenthesized_field_declarator, $.parenthesized_declarator),
      $._field_identifier,
    ),

    _type_declarator: $ => choice(
      alias($.attributed_type_declarator, $.attributed_declarator),
      alias($.pointer_type_declarator, $.pointer_declarator),
      alias($.function_type_declarator, $.function_declarator),
      alias($.array_type_declarator, $.array_declarator),
      alias($.parenthesized_type_declarator, $.parenthesized_declarator),
      $._type_identifier,
      alias(choice('signed', 'unsigned', '__signed__', '__unsigned__', 'long', 'short'), $.primitive_type),
      $.primitive_type,
    ),

    _abstract_declarator: $ => choice(
      $.abstract_pointer_declarator,
      $.abstract_function_declarator,
      $.abstract_array_declarator,
      $.abstract_parenthesized_declarator,
    ),

    parenthesized_declarator: $ => prec.dynamic(PREC.PAREN_DECLARATOR, seq(
      '(',
      optional($._call_modifier),
      field('declarator', $._declarator),
      ')',
    )),
    parenthesized_field_declarator: $ => prec.dynamic(PREC.PAREN_DECLARATOR, seq(
      '(',
      optional($._call_modifier),
      field('declarator', $._field_declarator),
      ')',
    )),
    parenthesized_type_declarator: $ => prec.dynamic(PREC.PAREN_DECLARATOR, seq(
      '(',
      optional($._call_modifier),
      field('declarator', $._type_declarator),
      ')',
    )),
    abstract_parenthesized_declarator: $ => prec(1, seq(
      '(',
      optional($._call_modifier),
      field('declarator', $._abstract_declarator),
      ')',
    )),


    attributed_declarator: $ => prec.right(seq(
      $._declarator,
      repeat1($.attribute_declaration),
    )),
    attributed_field_declarator: $ => prec.right(seq(
      $._field_declarator,
      repeat1($.attribute_declaration),
    )),
    attributed_type_declarator: $ => prec.right(seq(
      $._type_declarator,
      repeat1($.attribute_declaration),
    )),

    pointer_declarator: $ => prec.dynamic(1, prec.right(seq(
      optional($.ms_based_modifier),
      '*',
      repeat($.attribute_declaration),
      repeat($.attribute_specifier),
      repeat($.ms_pointer_modifier),
      repeat($.type_qualifier),
      // A calling convention after the star: `xmlChar * XMLCALL xmlStrdup(...)`;
      // or memory class macros between qualifiers:
      // `T * osqROM1 const osqROM2 osqROM3 table[4]`.
      optional(choice(
        $.ms_call_modifier,
        repeat1(seq($.macro_call_modifier, repeat($.type_qualifier))),
      )),
      field('declarator', $._declarator),
    ))),
    pointer_field_declarator: $ => prec.dynamic(1, prec.right(seq(
      optional($.ms_based_modifier),
      '*',
      repeat($.attribute_declaration),
      repeat($.ms_pointer_modifier),
      repeat($.type_qualifier),
      // A qualifier macro after the star: `T * VX1000_INNERSTRUCT_VOLATILE p;`.
      optional($.macro_call_modifier),
      field('declarator', $._field_declarator),
    ))),
    pointer_type_declarator: $ => prec.dynamic(1, prec.right(seq(
      optional($.ms_based_modifier),
      '*',
      repeat($.attribute_declaration),
      repeat($.ms_pointer_modifier),
      repeat($.type_qualifier),
      field('declarator', $._type_declarator),
    ))),
    abstract_pointer_declarator: $ => prec.dynamic(1, prec.right(seq('*',
      repeat($.attribute_declaration),
      repeat($.ms_pointer_modifier),
      repeat($.type_qualifier),
      field('declarator', optional($._abstract_declarator)),
    ))),

    function_declarator: $ => prec.right(1,
      seq(
        field('declarator', $._declarator),
        field('parameters', $.parameter_list),
        optional($.gnu_asm_expression),
        repeat(choice(
          $.attribute_specifier,
          $.identifier,
          alias($._trailing_macro_call, $.call_expression),
        )),
      ),
    ),

    // An attribute-like macro after the parameters: `void f(void) NONNULL(1)`.
    // It costs more than a macro modifier, so `STATIC FUNC(void, CODE) f(void)`
    // is not read as a function `FUNC` of type `STATIC` followed by `f(void)`.
    // (A preproc_call_expression, spelled out: a rule that only wraps another
    // symbol is folded away by the generator, and its precedence with it.)
    _trailing_macro_call: $ => prec.dynamic(PREC.TRAILING_MACRO_CALL, prec(PREC.CALL, seq(
      field('function', $.identifier),
      field('arguments', alias($.preproc_argument_list, $.argument_list)),
    ))),

    _function_declaration_declarator: $ => prec.right(1,
      seq(
        field('declarator', $._declarator),
        field('parameters', $.parameter_list),
        optional($.gnu_asm_expression),
        // An attribute-like macro ends a prototype as it does a definition:
        // `int f(const char *fmt, ...) LIBXML_ATTR_FORMAT(1,2);`.
        repeat(choice(
          $.attribute_specifier,
          alias($._trailing_macro_call, $.call_expression),
        )),
      )),

    // A bare attribute macro ends a prototype only right before its `;`
    // (`void f(void) OS_ATTR_NORETURN;`), so a K&R parameter declaration
    // after the parameters stays one.
    _bare_attributed_function_declarator: $ => prec.right(1,
      seq(
        field('declarator', $._declarator),
        field('parameters', $.parameter_list),
        optional($.gnu_asm_expression),
        repeat(choice(
          $.attribute_specifier,
          alias($._trailing_macro_call, $.call_expression),
        )),
        $.identifier,
        repeat(choice(
          $.attribute_specifier,
          $.identifier,
          alias($._trailing_macro_call, $.call_expression),
        )),
      )),

    function_field_declarator: $ => prec(1, seq(
      field('declarator', $._field_declarator),
      field('parameters', $.parameter_list),
    )),
    function_type_declarator: $ => prec(1, seq(
      field('declarator', $._type_declarator),
      field('parameters', $.parameter_list),
    )),
    abstract_function_declarator: $ => prec(1, seq(
      field('declarator', optional($._abstract_declarator)),
      field('parameters', $.parameter_list),
    )),

    _old_style_function_declarator: $ => seq(
      field('declarator', $._declarator),
      field('parameters', alias($._old_style_parameter_list, $.parameter_list)),
    ),

    array_declarator: $ => prec(1, seq(
      field('declarator', $._declarator),
      '[',
      repeat(choice($.type_qualifier, 'static')),
      field('size', optional(choice($.expression, '*'))),
      ']',
    )),
    array_field_declarator: $ => prec(1, seq(
      field('declarator', $._field_declarator),
      '[',
      repeat(choice($.type_qualifier, 'static')),
      field('size', optional(choice($.expression, '*'))),
      ']',
    )),
    array_type_declarator: $ => prec(1, seq(
      field('declarator', $._type_declarator),
      '[',
      repeat(choice($.type_qualifier, 'static')),
      field('size', optional(choice($.expression, '*'))),
      ']',
    )),
    abstract_array_declarator: $ => prec(1, seq(
      field('declarator', optional($._abstract_declarator)),
      '[',
      repeat(choice($.type_qualifier, 'static')),
      field('size', optional(choice($.expression, '*'))),
      ']',
    )),

    init_declarator: $ => choice(
      seq(
        field('declarator', $._declarator),
        repeat($.attribute_specifier),
        '=',
        field('value', choice($.initializer_list, $.expression)),
      ),
      // `OS_appMode OS_DATA_SECTION_ATTRIB_POST(.data.os.OS_appMode) = 0;`
      // (One section macro, not the trailing macro calls of a declarator: an
      // `=` after those split the parser states that follow every function
      // declarator, and runs of macro lines without semicolons then needed
      // more parallel readings than the parser keeps.)
      seq(
        field('declarator', choice($.identifier, $.array_declarator)),
        alias($._section_macro_call, $.call_expression),
        '=',
        field('value', choice($.initializer_list, $.expression)),
      ),
      // An object placed at an absolute address or in a named section, as
      // the Cosmic, IAR and CodeWarrior compilers for small microcontrollers
      // write it: `u8 au8_id[8] @ 0x0600;`, `const u8 v[2] @"SEC_SW" = {…};`.
      seq(
        field('declarator', $._non_function_declarator),
        $.address_specifier,
        optional(seq('=', field('value', choice($.initializer_list, $.expression)))),
      ),
    ),

    address_specifier: $ => seq(
      '@',
      field('address', choice(
        $.number_literal,
        $.string_literal,
        $.identifier,
        $.parenthesized_expression,
      )),
    ),

    compound_statement: $ => seq(
      '{',
      repeat($._block_item),
      '}',
    ),

    storage_class_specifier: _ => choice(
      'extern',
      'static',
      'auto',
      'register',
      'inline',
      '__inline',
      '__inline__',
      '__forceinline',
      'thread_local',
      '_Thread_local',
      '__thread',
      'constexpr',
    ),

    type_qualifier: $ => choice(
      'const',
      'volatile',
      'restrict',
      '__restrict__',
      '__extension__',
      '_Atomic',
      '_Noreturn',
      'noreturn',
      '_Nonnull',
      $.alignas_qualifier,
    ),

    alignas_qualifier: $ => seq(
      choice('alignas', '_Alignas'),
      '(',
      choice($.expression, $.type_descriptor),
      ')',
    ),

    type_specifier: $ => choice(
      $.struct_specifier,
      $.union_specifier,
      $.enum_specifier,
      $.macro_type_specifier,
      $.sized_type_specifier,
      $.primitive_type,
      $.bitint_type,
      $.typeof_specifier,
      $.atomic_type_specifier,
      alias('auto', $.primitive_type),
      $._type_identifier,
    ),

    // C23 _BitInt, also the underlying type of a C2Y bit-precise enum (N3705).
    bitint_type: $ => seq(
      optional(choice('signed', 'unsigned')),
      '_BitInt',
      '(',
      field('width', $.expression),
      ')',
    ),

    // C23 typeof / typeof_unqual. GNU spellings are the pre-standard form.
    typeof_specifier: $ => seq(
      choice('typeof', 'typeof_unqual', '__typeof__', '__typeof', '__typeof_unqual__'),
      '(',
      choice(
        $.expression,
        prec.dynamic(-1, $.type_descriptor),
      ),
      ')',
    ),

    // C11 type-specifier form. `_Atomic int` stays a qualifier.
    atomic_type_specifier: $ => seq(
      '_Atomic',
      '(',
      field('type', $.type_descriptor),
      ')',
    ),

    sized_type_specifier: $ => choice(
      seq(
        repeat(choice(
          'signed',
          'unsigned',
          '__signed__',
          '__unsigned__',
          'long',
          'short',
          '_Complex',
          '_Imaginary',
        )),
        field('type', optional(choice(
          prec.dynamic(-1, $._type_identifier),
          $.primitive_type,
        ))),
        repeat1(choice(
          'signed',
          'unsigned',
          '__signed__',
          '__unsigned__',
          'long',
          'short',
          '_Complex',
          '_Imaginary',
        )),
      ),
      seq(
        repeat1(choice(
          'signed',
          'unsigned',
          '__signed__',
          '__unsigned__',
          'long',
          'short',
          '_Complex',
          '_Imaginary',
        )),
        repeat($.type_qualifier),
        field('type', optional(choice(
          prec.dynamic(-1, $._type_identifier),
          $.primitive_type,
        ))),
        repeat(choice(
          'signed',
          'unsigned',
          '__signed__',
          '__unsigned__',
          'long',
          'short',
          '_Complex',
          '_Imaginary',
        )),
      ),
    ),

    primitive_type: _ => token(choice(
      'bool',
      '_Bool',
      'char',
      'int',
      ...[16, 32, 64, 128].map(n => `_Float${n}`),
      ...[16, 32, 64, 128].map(n => `_Float${n}x`),
      ...[64, 128].map(n => `_Decimal${n}x`),
      'float',
      'double',
      'void',
      '_Decimal32',
      '_Decimal64',
      '_Decimal128',
      'size_t',
      'ssize_t',
      'ptrdiff_t',
      'intptr_t',
      'uintptr_t',
      'charptr_t',
      'nullptr_t',
      'max_align_t',
      ...[8, 16, 32, 64].map(n => `int${n}_t`),
      ...[8, 16, 32, 64].map(n => `uint${n}_t`),
      ...[8, 16, 32, 64].map(n => `char${n}_t`),
    )),

    enum_specifier: $ => seq(
      'enum',
      choice(
        seq(
          field('name', $._type_identifier),
          optional(seq(':', field('underlying_type', $._enum_underlying_type))),
          optional($.attribute_specifier),
          field('body', optional($.enumerator_list)),
        ),
        seq(
          ':',
          field('underlying_type', $._enum_underlying_type),
          field('body', $.enumerator_list),
        ),
        seq(
          optional($.attribute_specifier),
          field('body', $.enumerator_list),
        ),
      ),
      optional($.attribute_specifier),
    ),

    _enum_underlying_type: $ => choice(
      $.primitive_type,
      $.sized_type_specifier,
      $.bitint_type,
      $._type_identifier,
    ),

    enumerator_list: $ => seq(
      '{',
      repeat(choice(
        seq($.enumerator, ','),
        alias($.preproc_if_in_enumerator_list, $.preproc_if),
        alias($.preproc_ifdef_in_enumerator_list, $.preproc_ifdef),
        seq($.preproc_call, ','),
        // A standalone line marker (e.g. #line) may appear between enumerators
        // without a trailing comma when an X-macro #include is expanded.
        prec(1, $.preproc_call),
      )),
      optional(seq(
        choice(
          $.enumerator,
          alias($.preproc_if_in_enumerator_list_no_comma, $.preproc_if),
          alias($.preproc_ifdef_in_enumerator_list_no_comma, $.preproc_ifdef),
          $.preproc_call,
        ),
      )),
      '}',
    ),

    struct_specifier: $ => prec.right(seq(
      'struct',
      optional($.attribute_specifier),
      optional($.ms_declspec_modifier),
      choice(
        seq(
          field('name', $._type_identifier),
          field('body', optional($.field_declaration_list)),
        ),
        field('body', $.field_declaration_list),
      ),
      optional($.attribute_specifier),
    )),

    union_specifier: $ => prec.right(seq(
      'union',
      optional($.ms_declspec_modifier),
      choice(
        seq(
          field('name', $._type_identifier),
          field('body', optional($.field_declaration_list)),
        ),
        field('body', $.field_declaration_list),
      ),
      optional($.attribute_specifier),
    )),

    field_declaration_list: $ => seq(
      '{',
      repeat($._field_declaration_list_item),
      '}',
    ),

    _field_declaration_list_item: $ => choice(
      $.field_declaration,
      alias($._macro_function_field_declaration, $.field_declaration),
      alias($._field_macro_statement, $.macro_statement),
      $.preproc_def,
      $.preproc_function_def,
      $.preproc_call,
      alias($.preproc_if_in_field_declaration_list, $.preproc_if),
      alias($.preproc_ifdef_in_field_declaration_list, $.preproc_ifdef),
      // A stray semicolon after a field: `unsigned char ok;;`.
      ';',
    ),

    // A macro that stands for a field, or for none, in a configuration:
    // `OS_Cfg_app_decl(const os_appcontext_t *app)`,
    // `VAR_ALIGN(EVADC_GRP_RES_DMA AdcResult_Q0, 32)`.
    _field_macro_statement: $ => prec.dynamic(PREC.MACRO_STATEMENT, seq(
      field('name', $.identifier),
      field('arguments', alias($._macro_argument_list, $.argument_list)),
      optional(';'),
    )),

    field_declaration: $ => seq(
      $._macro_declaration_specifiers,
      optional($._field_declaration_declarator),
      optional($.attribute_specifier),
      ';',
    ),
    // An unnamed bit-field pads or aligns the next one: `unsigned int : 0;`.
    _field_declaration_declarator: $ => commaSep1(choice(
      seq(
        field('declarator', $._field_declarator),
        optional($.bitfield_clause),
      ),
      $.bitfield_clause,
    )),

    bitfield_clause: $ => seq(':', $.expression),

    enumerator: $ => seq(
      field('name', $.identifier),
      optional(seq('=', field('value', $.expression))),
    ),

    variadic_parameter: _ => '...',

    parameter_list: $ => seq(
      '(',
      choice(
        commaSep(choice(
          $.parameter_declaration,
          alias($._macro_function_parameter_declaration, $.parameter_declaration),
          alias($._macro_prefixed_parameter_declaration, $.parameter_declaration),
          $.variadic_parameter,
        )),
        $.compound_statement,
      ),
      ')',
    ),
    _old_style_parameter_list: $ => seq(
      '(',
      commaSep(choice($.identifier, $.variadic_parameter)),
      ')',
    ),

    parameter_declaration: $ => seq(
      $._declaration_specifiers,
      optional(field('declarator', choice(
        $._declarator,
        $._abstract_declarator,
        // A pointer class macro between the type and the star:
        // `const VX1000_CHAR VX1000_DECL_PTR * pBuf`.
        alias($._macro_pointer_declarator, $.pointer_declarator),
        alias($._macro_abstract_pointer_declarator, $.abstract_pointer_declarator),
      ))),
      repeat($.attribute_specifier),
    ),

    // A macro in front of a parameter: one that stands for the leading
    // parameters, comma included (`CanInit(CAN_CHANNEL_CANTYPE_FIRST uint8
    // initObject)`), or a storage macro (`f(DBGVAR BapDataType_et x)`). The
    // name is required, so `uint32 objectId` stays a type and a name.
    _macro_prefixed_parameter_declaration: $ => prec.dynamic(PREC.MACRO, seq(
      alias($.identifier, $.macro_modifier),
      $._declaration_specifiers,
      field('declarator', choice(
        $._declarator,
        alias($._macro_pointer_declarator, $.pointer_declarator),
      )),
      repeat($.attribute_specifier),
    )),

    // One or more: `V_MEMROM1 DescSvcHead V_MEMROM2 V_MEMROM3 * pSvcHead`.
    _macro_pointer_declarator: $ => prec.dynamic(PREC.MACRO, seq(
      repeat1(alias($.identifier, $.macro_modifier)),
      $.pointer_declarator,
    )),
    _macro_abstract_pointer_declarator: $ => prec.dynamic(PREC.MACRO, seq(
      repeat1(alias($.identifier, $.macro_modifier)),
      $.abstract_pointer_declarator,
    )),

    // Statements

    attributed_statement: $ => seq(
      repeat1($.attribute_declaration),
      $.statement,
    ),

    statement: $ => choice(
      $.case_statement,
      $._non_case_statement,
    ),

    _non_case_statement: $ => choice(
      $.attributed_statement,
      $.labeled_statement,
      $.compound_statement,
      $.expression_statement,
      $.if_statement,
      $.defer_statement,
      $.switch_statement,
      $.do_statement,
      $.while_statement,
      $.for_statement,
      $.return_statement,
      $.break_statement,
      $.continue_statement,
      $.goto_statement,
      $.seh_try_statement,
      $.seh_leave_statement,
      alias($._asm_block_statement, $.asm_block),
      alias($._macro_closed_statement, $.expression_statement),
    ),

    // A call between two macros that open and close a block, the second one
    // bringing the semicolon: `_ssSafelyCallGenericFcnStart(S)(S, F, 0, &v)`
    // `_ssSafelyCallGenericFcnEnd;`. (Below a macro statement, so `F(x) END;`
    // stays a macro line and a statement.)
    _macro_closed_statement: $ => prec.dynamic(PREC.MACRO_STATEMENT - 1, seq(
      $.call_expression,
      alias($.identifier, $.macro_modifier),
      ';',
    )),

    // A block of assembly in a function, as the Microsoft, CodeWarrior and
    // Cosmic compilers write it: `__asm {` `LD D6, x` `BEQ end` `}`. (A token,
    // so the assembly inside is never read as C.)
    _asm_block_statement: _ => token(seq(
      choice('__asm', '_asm', 'asm'),
      /\s*/,
      '{',
      /[^}]*/,
      '}',
    )),

    _top_level_statement: $ => choice(
      $.case_statement,
      $.attributed_statement,
      $.labeled_statement,
      $.compound_statement,
      alias($._top_level_expression_statement, $.expression_statement),
      $.if_statement,
      $.defer_statement,
      $.switch_statement,
      $.do_statement,
      $.while_statement,
      $.for_statement,
      $.return_statement,
      $.break_statement,
      $.continue_statement,
      $.goto_statement,
    ),

    // C23 lets a label end a block (`done: }`); generated lexers put a #line
    // marker between a label and its statement (`yy3:` `#line 139 "x.re"`).
    labeled_statement: $ => prec.right(seq(
      field('label', $._statement_identifier),
      ':',
      repeat($.attribute_specifier),
      optional(choice($.declaration, $.statement)),
    )),

    // This is missing binary expressions, others were kept so that macro code can be parsed better and code examples
    _top_level_expression_statement: $ => seq(
      optional($._expression_not_binary),
      ';',
    ),

    expression_statement: $ => seq(
      optional(choice(
        $.expression,
        $.comma_expression,
      )),
      ';',
    ),

    // The second form is an `if` whose body a preprocessor directive cut off:
    // `#if X  if (a)  #endif  { … }`. Its lower precedence keeps every other
    // `if` in the first form.
    if_statement: $ => choice(
      prec.right(seq(
        'if',
        $._if_condition,
        field('consequence', $.statement),
        optional(field('alternative', $.else_clause)),
      )),
      prec(-1, seq('if', $._if_condition)),
      // A macro name that expands to the parenthesized condition, before a
      // block: `if BSWM_ISDEF_BswMLogicalExpression_ShutDown { … }`.
      prec.right(seq(
        'if',
        prec.dynamic(-1, field('condition', $.identifier)),
        field('consequence', $.compound_statement),
        optional(field('alternative', $.else_clause)),
      )),
    ),

    // The last form is a macro that expands to the parenthesized condition:
    // `if Is_front_wheel(n)` under `#define Is_front_wheel(n) ((n) == WhF)`.
    _if_condition: $ => choice(
      field('condition', $.parenthesized_expression),
      prec.dynamic(-1, seq('(', $._selection_header, ')')),
      prec.dynamic(-1, field('condition', alias($._macro_loop_header, $.call_expression))),
    ),

    // Same for `else`: `if (a) { … } else  #endif  { … }`. A lone else_clause is
    // also a block item, for `#if X  else if (b) { … }  #endif  else { … }`.
    else_clause: $ => choice(
      seq('else', $.statement),
      prec(-1, 'else'),
    ),

    // C2Y defer (TS 25755 / N3734). `_Defer` is the keyword; `defer` is the
    // spelling used by the draft and by <stddefer.h>-style code.
    defer_statement: $ => prec.right(seq(
      choice('_Defer', 'defer'),
      field('body', $.statement),
    )),

    // The last form is a macro that expands to the parenthesized value, as in
    // `if Is_front_wheel(n)` (see _if_condition).
    switch_statement: $ => seq(
      'switch',
      choice(
        field('condition', $.parenthesized_expression),
        prec.dynamic(-1, seq('(', $._selection_header, ')')),
        prec.dynamic(-1, field('condition', alias($._macro_loop_header, $.call_expression))),
      ),
      field('body', $.statement),
    ),

    // Two-clause form first so the semicolon is not lost to the simple form.
    _selection_header: $ => choice(
      seq(
        field('initializer', alias($._condition_declaration, $.declaration)),
        ';',
        field('condition', choice($.expression, $.comma_expression)),
      ),
      field('condition', alias($._initialized_condition_declaration, $.declaration)),
    ),

    case_statement: $ => prec.right(seq(
      choice(
        seq(
          'case',
          field('value', $.expression),
          // C2Y case ranges (N3370). Whitespace around `...` is required by the standard.
          optional(seq('...', field('end_value', $.expression))),
        ),
        'default',
      ),
      ':',
      repeat(choice(
        $._non_case_statement,
        $.declaration,
        $.type_definition,
        // `case tULLIDENT:  KEYWORD_CASES  if (…)`, a macro of more labels.
        $.macro_statement,
      )),
    )),

    while_statement: $ => seq(
      'while',
      field('condition', $.parenthesized_expression),
      field('body', $.statement),
    ),

    do_statement: $ => seq(
      'do',
      field('body', $.statement),
      'while',
      field('condition', $.parenthesized_expression),
      ';',
    ),

    // The second form is a macro that expands to the loop head:
    // `for (Each_member_in_enum(t, i))`, `for All_wheels_wh(i)`.
    for_statement: $ => choice(
      seq(
        'for',
        '(',
        $._for_statement_body,
        ')',
        field('body', $.statement),
      ),
      prec.dynamic(-1, seq(
        'for',
        choice(
          seq('(', field('header', $.call_expression), ')'),
          // A name that expands to the whole head: `for (AllClients)`.
          seq('(', field('header', $.identifier), ')'),
          field('header', alias($._macro_loop_header, $.call_expression)),
        ),
        field('body', $.statement),
      )),
    ),
    // A plain name and arguments: a general expression here would let the
    // loop's own `(` open a cast, hiding `for (T *p = ...` declarations.
    _macro_loop_header: $ => seq(
      field('function', $.identifier),
      field('arguments', $.argument_list),
    ),
    _for_statement_body: $ => seq(
      choice(
        field('initializer', $.declaration),
        seq(field('initializer', optional(choice($.expression, $.comma_expression))), ';'),
      ),
      field('condition', optional(choice($.expression, $.comma_expression))),
      ';',
      field('update', optional(choice($.expression, $.comma_expression))),
    ),

    return_statement: $ => seq(
      'return',
      optional(choice($.expression, $.comma_expression)),
      ';',
    ),

    break_statement: $ => seq(
      'break',
      optional(field('label', $._statement_identifier)),
      ';',
    ),

    continue_statement: $ => seq(
      'continue',
      optional(field('label', $._statement_identifier)),
      ';',
    ),

    goto_statement: $ => seq(
      'goto',
      choice(
        field('label', $._statement_identifier),
        seq('*', field('target', $.expression)),
      ),
      ';',
    ),

    seh_try_statement: $ => seq(
      '__try',
      field('body', $.compound_statement),
      choice($.seh_except_clause, $.seh_finally_clause),
    ),

    seh_except_clause: $ => seq(
      '__except',
      field('filter', $.parenthesized_expression),
      field('body', $.compound_statement),
    ),

    seh_finally_clause: $ => seq(
      '__finally',
      field('body', $.compound_statement),
    ),

    seh_leave_statement: _ => seq(
      '__leave', ';',
    ),

    // Expressions

    expression: $ => choice(
      $._expression_not_binary,
      $.binary_expression,
    ),

    _expression_not_binary: $ => choice(
      $.conditional_expression,
      $.assignment_expression,
      $.unary_expression,
      $.update_expression,
      $.cast_expression,
      $.pointer_expression,
      $.sizeof_expression,
      $.countof_expression,
      $.va_arg_expression,
      $.alignof_expression,
      $.offsetof_expression,
      $.generic_expression,
      $.static_assert_expression,
      $.pragma_operator,
      $.subscript_expression,
      $.call_expression,
      $.field_expression,
      $.compound_literal_expression,
      $.identifier,
      $.number_literal,
      $._string,
      $.true,
      $.false,
      $.null,
      $.char_literal,
      $.parenthesized_expression,
      $.gnu_asm_expression,
      alias($._macro_gnu_asm_expression, $.gnu_asm_expression),
      $.extension_expression,
    ),

    _string: $ => prec.left(choice(
      $.string_literal,
      $.concatenated_string,
    )),

    comma_expression: $ => seq(
      field('left', $.expression),
      ',',
      field('right', choice($.expression, $.comma_expression)),
    ),

    conditional_expression: $ => prec.right(PREC.CONDITIONAL, seq(
      field('condition', $.expression),
      '?',
      optional(field('consequence', choice($.expression, $.comma_expression))),
      ':',
      field('alternative', $.expression),
    )),

    _assignment_left_expression: $ => choice(
      $.identifier,
      $.call_expression,
      $.field_expression,
      $.pointer_expression,
      $.subscript_expression,
      $.parenthesized_expression,
    ),

    assignment_expression: $ => prec.right(PREC.ASSIGNMENT, seq(
      field('left', $._assignment_left_expression),
      field('operator', choice(
        '=',
        '*=',
        '/=',
        '%=',
        '+=',
        '-=',
        '<<=',
        '>>=',
        '&=',
        '^=',
        '|=',
      )),
      field('right', $.expression),
    )),

    pointer_expression: $ => prec.left(PREC.CAST, seq(
      field('operator', choice('*', '&')),
      field('argument', $.expression),
    )),

    unary_expression: $ => prec.left(PREC.UNARY, choice(
      seq(
        field('operator', choice('!', '~', '-', '+')),
        field('argument', $.expression),
      ),
      seq('&&', $._statement_identifier),
    )),

    binary_expression: $ => {
      const table = [
        ['+', PREC.ADD],
        ['-', PREC.ADD],
        ['*', PREC.MULTIPLY],
        ['/', PREC.MULTIPLY],
        ['%', PREC.MULTIPLY],
        ['||', PREC.LOGICAL_OR],
        ['&&', PREC.LOGICAL_AND],
        ['|', PREC.INCLUSIVE_OR],
        ['^', PREC.EXCLUSIVE_OR],
        ['&', PREC.BITWISE_AND],
        ['==', PREC.EQUAL],
        ['!=', PREC.EQUAL],
        ['>', PREC.RELATIONAL],
        ['>=', PREC.RELATIONAL],
        ['<=', PREC.RELATIONAL],
        ['<', PREC.RELATIONAL],
        ['<<', PREC.SHIFT],
        ['>>', PREC.SHIFT],
      ];

      return choice(...table.map(([operator, precedence]) => {
        return prec.left(precedence, seq(
          field('left', $.expression),
          // @ts-ignore
          field('operator', operator),
          field('right', $.expression),
        ));
      }));
    },

    update_expression: $ => {
      const argument = field('argument', $.expression);
      const operator = field('operator', choice('--', '++'));
      return prec.right(PREC.UNARY, choice(
        seq(operator, argument),
        seq(argument, operator),
      ));
    },

    cast_expression: $ => prec(PREC.CAST, seq(
      '(',
      field('type', choice(
        $.type_descriptor,
        alias($._macro_type_descriptor, $.type_descriptor),
        alias($._implicit_int_type_descriptor, $.type_descriptor),
      )),
      ')',
      field('value', $.expression),
    )),

    // C89 implicit int: a cast to qualifiers alone, `(const)x` for `(const int)x`.
    _implicit_int_type_descriptor: $ => repeat1($.type_qualifier),

    type_descriptor: $ => seq(
      repeat($.type_qualifier),
      field('type', $.type_specifier),
      // `sizeof(uint32 __attribute__ ((aligned (4))))`
      repeat(choice($.type_qualifier, $.attribute_specifier)),
      field('declarator', optional($._abstract_declarator)),
    ),

    // Memory class macros in a cast, in front of the type or the star:
    // `(osqPTcbRAM1 osqPTcbRAM2 TaskType osqPTcbRAM3 *)0`. (Only in casts: in
    // macro arguments they would compete with parameter declarations.)
    // A macro after the star too: `(osqPRAM1 osuint32 const osqPRAM2 * osqPRAM3)p`.
    _macro_type_descriptor: $ => {
      const declarator = field('declarator', choice(
        $._abstract_declarator,
        alias($._macro_abstract_pointer_suffix_declarator, $.abstract_pointer_declarator),
      ));
      // When both fit, the type is the name just before the qualifier macro:
      // `osuint32` in `(osqPRAM1 osuint32 const osqPRAM2 * osqPRAM3)`.
      return choice(
        prec.dynamic(PREC.MACRO - 1, seq(
          repeat($.type_qualifier),
          $._declarator_macro_qualifiers,
          field('type', $.type_specifier),
          repeat($.type_qualifier),
          optional(declarator),
        )),
        prec.dynamic(PREC.MACRO, seq(
          repeat($.type_qualifier),
          optional($._declarator_macro_qualifiers),
          field('type', $.type_specifier),
          repeat($.type_qualifier),
          $._declarator_macro_qualifier,
          declarator,
        )),
        // Only a macro after the star: `(volatile uint16 * FR_REG_FAR)p`.
        prec.dynamic(PREC.MACRO, seq(
          repeat($.type_qualifier),
          field('type', $.type_specifier),
          repeat($.type_qualifier),
          field('declarator', alias($._macro_abstract_pointer_suffix_declarator, $.abstract_pointer_declarator)),
        )),
      );
    },

    _macro_abstract_pointer_suffix_declarator: $ => prec.right(seq(
      '*',
      repeat($.type_qualifier),
      repeat1(seq(alias($.identifier, $.macro_modifier), repeat($.type_qualifier))),
    )),

    sizeof_expression: $ => prec(PREC.SIZEOF, seq(
      'sizeof',
      choice(
        field('value', prec.dynamic(1, $.expression)),
        seq('(', field('type', $.type_descriptor), ')'),
      ),
    )),

    // C2Y _Countof (N3369 / N3469). Same operand shapes as sizeof.
    countof_expression: $ => prec(PREC.SIZEOF, seq(
      '_Countof',
      choice(
        field('value', $.expression),
        seq('(', field('type', $.type_descriptor), ')'),
      ),
    )),

    va_arg_expression: $ => prec(PREC.VA_ARG, seq(
      choice('va_arg', '__builtin_va_arg'),
      '(',
      field('value', $.expression),
      ',',
      field('type', $.type_descriptor),
      ')',
    )),

    alignof_expression: $ => prec(PREC.SIZEOF, seq(
      choice('__alignof__', '__alignof', '_alignof', 'alignof', '_Alignof'),
      seq('(', field('type', $.type_descriptor), ')'),
    )),

    offsetof_expression: $ => prec(PREC.OFFSETOF, seq(
      'offsetof',
      seq('(', field('type', $.type_descriptor), ',', field('member', $._field_identifier), ')'),
    )),

    generic_expression: $ => prec(PREC.CALL, seq(
      '_Generic',
      '(',
      // N3260: the controlling operand may be a type. Prefer an expression when both match.
      choice(
        $.expression,
        prec.dynamic(-1, $.type_descriptor),
      ),
      ',',
      commaSep1(choice(
        seq($.type_descriptor, ':', $.expression),
        seq('default', ':', $.expression),
      )),
      ')',
    )),

    // C2Y static assertions in expressions (N3715). Also covers the declaration form
    // `static_assert(...);`, which is an expression statement.
    static_assert_expression: $ => prec(PREC.CALL, seq(
      choice('static_assert', '_Static_assert'),
      '(',
      field('condition', $.expression),
      optional(seq(',', field('message', $._string))),
      ')',
    )),

    subscript_expression: $ => prec(PREC.SUBSCRIPT, seq(
      field('argument', $.expression),
      '[',
      field('index', $.expression),
      ']',
    )),

    call_expression: $ => prec(PREC.CALL, seq(
      field('function', $.expression),
      field('arguments', $.argument_list),
    )),

    gnu_asm_expression: $ => prec(PREC.CALL, seq(
      choice('asm', '__asm__', '__asm'),
      repeat($.gnu_asm_qualifier),
      $._gnu_asm_operands,
    )),

    // The asm keyword behind a macro, known by the qualifier after it:
    // `OS_TOOL_ASM_KEYWORD volatile ("dsync" : : : "memory");`.
    _macro_gnu_asm_expression: $ => prec.dynamic(PREC.MACRO, seq(
      alias($.identifier, $.macro_modifier),
      repeat1($.gnu_asm_qualifier),
      $._gnu_asm_operands,
    )),

    _gnu_asm_operands: $ => seq(
      '(',
      field('assembly_code', $._string),
      optional(seq(
        field('output_operands', $.gnu_asm_output_operand_list),
        optional(seq(
          field('input_operands', $.gnu_asm_input_operand_list),
          optional(seq(
            field('clobbers', $.gnu_asm_clobber_list),
            optional(field('goto_labels', $.gnu_asm_goto_list)),
          )),
        )),
      )),
      ')',
    ),

    gnu_asm_qualifier: _ => choice(
      'volatile',
      '__volatile__',
      'inline',
      'goto',
    ),

    gnu_asm_output_operand_list: $ => seq(
      ':',
      commaSep(field('operand', $.gnu_asm_output_operand)),
    ),

    gnu_asm_output_operand: $ => seq(
      optional(seq(
        '[',
        field('symbol', $.identifier),
        ']',
      )),
      field('constraint', $.string_literal),
      '(',
      field('value', $.expression),
      ')',
    ),

    gnu_asm_input_operand_list: $ => seq(
      ':',
      commaSep(field('operand', $.gnu_asm_input_operand)),
    ),

    gnu_asm_input_operand: $ => seq(
      optional(seq(
        '[',
        field('symbol', $.identifier),
        ']',
      )),
      field('constraint', $.string_literal),
      '(',
      field('value', $.expression),
      ')',
    ),

    gnu_asm_clobber_list: $ => seq(
      ':',
      commaSep(field('register', $._string)),
    ),

    gnu_asm_goto_list: $ => seq(
      ':',
      commaSep(field('label', $.identifier)),
    ),

    extension_expression: $ => seq('__extension__', $.expression),

    // C99 _Pragma operator.
    pragma_operator: $ => prec(PREC.CALL, seq(
      '_Pragma',
      '(',
      field('argument', $._string),
      ')',
    )),

    // Allow compound statements and designated initializers as macro arguments, including trailing commas. For example:
    // MYFORLOOP(1, 10, i, { foo(i); bar(i); })
    // PARAMS(.foo = foo, .bar = { bar, 1 },)
    // The argument choice is written out in place (not as a rule of its own)
    // so that its states stay shared with `_macro_argument_list`'s.
    argument_list: $ => {
      const argument = choice(
        $.expression,
        $._macro_prefixed_argument,
        $.compound_statement,
        $.initializer_pair,
        alias($._operator_argument, $.operator),
        alias($._section_name, $.section_name),
        // A pointer type a macro takes: `GetInterfacePointer(Request_t*, ArbReq)`.
        alias($._macro_pointer_type_argument, $.type_descriptor),
      );
      return seq('(', choice(
        commaSep(argument),
        // A macro call with its first argument left empty: `COU_CALL(, "t+1")`.
        seq(',', commaSep1(argument)),
      ), optional(','), ')');
    },
    _macro_pointer_type_argument: $ => prec.dynamic(PREC.MACRO, seq(
      field('type', alias($.identifier, $.type_identifier)),
      field('declarator', alias($._macro_bare_abstract_pointer, $.abstract_pointer_declarator)),
    )),
    _macro_bare_abstract_pointer: $ => seq(
      '*',
      optional(field('declarator', alias($._macro_bare_abstract_pointer, $.abstract_pointer_declarator))),
    ),

    // A macro in front of an argument that stands for the leading arguments,
    // comma included: `CanInit(CAN_CHANNEL_CANPARA_FIRST initObject)`. Only a
    // name, a member of one (`info->bus.id`) or a number after it: `X_FIRST &a`
    // and `X_FIRST (a)` already read as an expression, and with any expression
    // (or a macro call in front) the parser would keep a second reading open at
    // every call inside an argument list. Also words a test macro turns into a
    // name or a string: `COU_ADD_SUITE(VIL__DIA__ALL Application ReadDtc tests, …)`.
    _macro_prefixed_argument: $ => prec.dynamic(PREC.MACRO, seq(
      repeat1(alias($.identifier, $.macro_modifier)),
      choice(
        $.identifier,
        alias($._macro_argument_member, $.field_expression),
        alias($._unsigned_number_literal, $.number_literal),
        // A channel macro that expands to the first argument and its comma:
        // `CanHL_GetTxHwToLogHandle(CAN_CHANNEL_CANPARA_FIRST Can_GetHwHandle(Htrh))`.
        alias($._macro_argument_call, $.call_expression),
        alias($._macro_argument_subscript, $.subscript_expression),
        // Several string macros before a string, one string together:
        // `fprintf(f, _COU_INDENT _COU_BOX_LOCATION "Test %s\n", name)`.
        $.concatenated_string,
      ),
    )),
    _macro_argument_call: $ => seq(
      field('function', $.identifier),
      field('arguments', $.argument_list),
    ),
    _macro_argument_subscript: $ => seq(
      field('argument', $.identifier),
      '[',
      field('index', $.expression),
      ']',
    ),

    _macro_argument_member: $ => seq(
      field('argument', choice($.identifier, alias($._macro_argument_member, $.field_expression))),
      field('operator', choice('.', '->')),
      field('field', $._field_identifier),
    ),

    field_expression: $ => seq(
      prec(PREC.FIELD, seq(
        field('argument', $.expression),
        field('operator', choice('.', '->')),
      )),
      field('field', $._field_identifier),
    ),

    compound_literal_expression: $ => seq(
      '(',
      // N3871: storage-class specifiers in compound literals.
      field('storage_class', repeat($.storage_class_specifier)),
      field('type', $.type_descriptor),
      ')',
      field('value', $.initializer_list),
    ),

    parenthesized_expression: $ => seq(
      '(',
      choice($.expression, $.comma_expression, $.compound_statement),
      ')',
    ),

    initializer_list: $ => seq(
      '{',
      repeat(choice(
        prec(1, choice(
          seq($.initializer_pair, ','),
          seq($.expression, ','),
          seq($.initializer_list, ','),
          seq($.preproc_embed, ','),
        )),
        // A standalone preprocessor directive (e.g. a #line marker emitted when
        // an X-macro #include expands inside the initializer) needs no comma.
        // No precedence: at `{ #pragma x` in a function the braces may still be
        // a block (an initializer_fragment could start there too), and a
        // precedence would decide for the initializer before the code after
        // the directive does.
        $.preproc_call,
        $.preproc_def,
        $.preproc_function_def,
        // Braced elements may lack the comma between them where a skipped
        // `#else` cut the list in two: `{ {a, 1}, {b, 2} #else {a, 1} #endif }`.
        // Only another braced element may follow one without a comma, so a
        // directive after it is still skipped like a comment.
        seq($._initializer_list_run, ','),
        // Such macro elements before a name that ends the list:
        // `{ ADD_TEST(SUITE, CASE, fn)  COU_ADD_TEST_END, }`.
        seq($._initializer_macro_terminated, ','),
      )),
      optional(choice(
        $.initializer_pair,
        $.expression,
        $.initializer_list,
        $.preproc_embed,
        $._initializer_list_run,
        $._initializer_macro_terminated,
      )),
      optional(','),
      '}',
    ),

    // A macro call that expands to a braced element and its comma runs on the
    // same way: `{ ELEMENT(1) ELEMENT(2) }`, each in its own `#if`.
    _initializer_list_run: $ => prec.left(seq(
      choice($.initializer_list, alias($._initializer_macro_element, $.call_expression)),
      repeat1(choice($.initializer_list, alias($._initializer_macro_element, $.call_expression))),
    )),

    _initializer_macro_terminated: $ => seq(
      repeat1(alias($._initializer_macro_element, $.call_expression)),
      $.identifier,
    ),

    _initializer_macro_element: $ => prec.dynamic(-1, seq(
      field('function', $.identifier),
      field('arguments', $.argument_list),
    )),

    initializer_pair: $ => choice(
      seq(
        field('designator', repeat1(choice(
          $.subscript_designator,
          $.field_designator,
          $.subscript_range_designator,
        ))),
        '=',
        field('value', choice($.expression, $.initializer_list)),
      ),
      seq(
        field('designator', $._field_identifier),
        ':',
        field('value', choice($.expression, $.initializer_list)),
      ),
    ),

    subscript_designator: $ => seq('[', $.expression, ']'),

    subscript_range_designator: $ => seq('[', field('start', $.expression), '...', field('end', $.expression), ']'),

    field_designator: $ => seq('.', $._field_identifier),

    number_literal: _ => numberLiteral(true),
    // A number without a sign, after a macro that stands for leading arguments
    // (see _macro_prefixed_argument): with the sign, `len -1` would lex as a
    // name and the number `-1` there instead of a subtraction.
    _unsigned_number_literal: _ => numberLiteral(false),

    char_literal: $ => seq(
      choice('L\'', 'u\'', 'U\'', 'u8\'', '\''),
      repeat1(choice(
        $.escape_sequence,
        alias(token.immediate(/[^\\\n']/), $.character),
        $.invalid_escape_sequence,
      )),
      '\'',
    ),

    // Must concatenate at least 2 nodes, one of which must be a string_literal.
    // Identifier is added to parse macros that are strings, like PRIu64.
    concatenated_string: $ => prec.right(seq(
      choice(
        seq($.identifier, $.string_literal),
        seq($.string_literal, $.string_literal),
        seq($.string_literal, $.identifier),
        // A macro call after a string:
        // `"e_lwz r11, " osdExpandQuoted(osdOfsTable) "(r11)"`.
        seq($.string_literal, alias($._string_macro_call, $.call_expression)),
      ),
      repeat(choice(
        $.string_literal,
        $.identifier,
        alias($._string_macro_call, $.call_expression),
      )),
    )),

    _string_macro_call: $ => seq(
      field('function', $.identifier),
      field('arguments', $.argument_list),
    ),

    string_literal: $ => seq(
      choice('L"', 'u"', 'U"', 'u8"', '"'),
      repeat(choice(
        alias(token.immediate(prec(1, /[^\\"\n]+/)), $.string_content),
        $.escape_sequence,
        $.invalid_escape_sequence,
      )),
      '"',
    ),

    escape_sequence: _ => token(prec(1, seq(
      '\\',
      choice(
        // C2Y delimited escapes (N3353): \o{}, \x{}, \u{}. Longer forms first.
        /x\{[0-9a-fA-F]+\}/,
        /u\{[0-9a-fA-F]+\}/,
        /o\{[0-7]+\}/,
        // eE: GNU escape; \r?\n: line continuation inside a literal.
        /['"?\\abfnrtveE]/,
        /\r?\n/,
        /[0-7]{1,3}/,
        /x[0-9a-fA-F]+/,
        /u[0-9a-fA-F]{4}/,
        /U[0-9a-fA-F]{8}/,
      ),
    ))),

    invalid_escape_sequence: _ => token(prec(1, seq(
      '\\',
      choice(
        /[^'"?\\abfnrtveE\r\n]/,
        /u[0-9a-fA-F]{1,3}/,
        /U[0-9a-fA-F]{1,7}/,
      ),
    ))),

    system_lib_string: _ => token(seq(
      '<',
      repeat(choice(/[^>\n]/, '\\>')),
      '>',
    )),

    true: _ => token(choice('TRUE', 'true')),
    false: _ => token(choice('FALSE', 'false')),
    null: _ => choice('NULL', 'nullptr'),

    identifier: _ =>
      // eslint-disable-next-line max-len
      /(\p{XID_Start}|\$|_|\\u[0-9A-Fa-f]{4}|\\U[0-9A-Fa-f]{8}|\\u\{[0-9A-Fa-f]+\})(\p{XID_Continue}|\$|\\u[0-9A-Fa-f]{4}|\\U[0-9A-Fa-f]{8}|\\u\{[0-9A-Fa-f]+\})*/,

    _type_identifier: $ => alias(
      $.identifier,
      $.type_identifier,
    ),
    _field_identifier: $ => alias($.identifier, $.field_identifier),
    _statement_identifier: $ => alias($.identifier, $.statement_identifier),

    _empty_declaration: $ => seq(
      $.type_specifier,
      ';',
    ),

    // `GIT_INLINE(int *)`, and the AUTOSAR compiler abstraction, which follows the
    // type with memory and pointer classes: `CONST(uint8, DEM_CONST) x[] = {…};`,
    // `FUNC(void, DEM_CODE) Dem_Init(void)`, `P2CONST(T, AUTOMATIC, DEM_APPL_DATA) p`.
    // Without the extra arguments those declarations failed, and error recovery
    // read a large table initializer as one comma_expression nested one level
    // per element, deep enough to overflow a recursive tree walk.
    macro_type_specifier: $ => prec.dynamic(-1, seq(
      field('name', $.identifier),
      '(',
      field('type', $.type_descriptor),
      // A keyword type as a later argument, `V_DEF_FUNC(V_NONE, void, CODE)`,
      // stays an identifier as before; it has to be accepted as primitive_type
      // too, because where a macro declarator could follow (`P2FUNC(…)`) the
      // word is read as that.
      repeat(seq(',', field('argument', choice($.identifier, alias($.primitive_type, $.identifier))))),
      ')',
    )),

    // http://stackoverflow.com/questions/13014947/regex-to-match-a-c-style-multiline-comment/36328890#36328890
    comment: _ => token(choice(
      seq('//', /(\\+(.|\r?\n)|[^\\\n])*/),
      seq(
        '/*',
        /[^*]*\*+([^/*][^*]*\*+)*/,
        '/',
      ),
    )),
  },
});

/**
 * A C number token, with or without a leading sign.
 *
 * @param {boolean} signed
 *
 * @returns {RuleOrLiteral}
 */
function numberLiteral(signed) {
  const separator = '\'';
  const hex = /[0-9a-fA-F]/;
  const decimal = /[0-9]/;
  const hexDigits = seq(repeat1(hex), repeat(seq(separator, repeat1(hex))));
  const decimalDigits = seq(repeat1(decimal), repeat(seq(separator, repeat1(decimal))));
  return token(seq(
    signed ? optional(/[-\+]/) : blank(),
    optional(choice(/0[xX]/, /0[bB]/, /0[oO]/)),
    choice(
      seq(
        choice(
          decimalDigits,
          seq(/0[bB]/, decimalDigits),
          seq(/0[oO]/, decimalDigits),
          seq(/0[xX]/, hexDigits),
        ),
        optional(seq('.', optional(hexDigits))),
      ),
      seq('.', decimalDigits),
    ),
    optional(seq(
      /[eEpP]/,
      optional(seq(
        optional(/[-\+]/),
        hexDigits,
      )),
    )),
    // i/I/j/J: C2Y imaginary/complex suffixes (N3298), any order with f/l.
    /[uUlLwWfFbBdDiIjJ]*/,
    // Rest of a pp-number (0offset, 0bxyz, 0xgg) stays one token.
    optional(/[A-Za-z_$][A-Za-z0-9_$]*/),
  ));
}

/**
 *
 * @param {string} suffix
 *
 * @param {RuleBuilder<string>} content
 *
 * @param {number} precedence
 *
 * @returns {RuleBuilders<string, string>}
 */
function preprocIf(suffix, content, precedence = 0) {
  /**
   *
   * @param {GrammarSymbols<string>} $
   *
   * @returns {ChoiceRule}
   */
  function alternativeBlock($) {
    return choice(
      suffix ? alias($['preproc_else' + suffix], $.preproc_else) : $.preproc_else,
      suffix ? alias($['preproc_elif' + suffix], $.preproc_elif) : $.preproc_elif,
      suffix ? alias($['preproc_elifdef' + suffix], $.preproc_elifdef) : $.preproc_elifdef,
    );
  }

  return {
    ['preproc_if' + suffix]: $ => prec(precedence, seq(
      preprocessor('if'),
      field('condition', $._preproc_expression),
      '\n',
      repeat(content($)),
      field('alternative', optional(alternativeBlock($))),
      preprocessor('endif'),
    )),

    ['preproc_ifdef' + suffix]: $ => prec(precedence, seq(
      choice(preprocessor('ifdef'), preprocessor('ifndef')),
      field('name', $.identifier),
      repeat(content($)),
      field('alternative', optional(alternativeBlock($))),
      preprocessor('endif'),
    )),

    ['preproc_else' + suffix]: $ => prec(precedence, seq(
      preprocessor('else'),
      repeat(content($)),
    )),

    ['preproc_elif' + suffix]: $ => prec(precedence, seq(
      preprocessor('elif'),
      field('condition', $._preproc_expression),
      '\n',
      repeat(content($)),
      field('alternative', optional(alternativeBlock($))),
    )),

    ['preproc_elifdef' + suffix]: $ => prec(precedence, seq(
      choice(preprocessor('elifdef'), preprocessor('elifndef')),
      field('name', $.identifier),
      repeat(content($)),
      field('alternative', optional(alternativeBlock($))),
    )),
  };
}

/**
 * Creates a preprocessor regex rule
 *
 * @param {RegExp | Rule | string} command
 *
 * @returns {AliasRule}
 */
function preprocessor(command) {
  return alias(new RegExp('#[ \t]*' + command), '#' + command);
}

/**
 * Creates a rule to optionally match one or more of the rules separated by a comma
 *
 * @param {Rule} rule
 *
 * @returns {ChoiceRule}
 */
function commaSep(rule) {
  return optional(commaSep1(rule));
}

/**
 * Creates a rule to match one or more of the rules separated by a comma
 *
 * @param {Rule} rule
 *
 * @returns {SeqRule}
 */
function commaSep1(rule) {
  return seq(rule, repeat(seq(',', rule)));
}

/**
 * The declarators that section and alignment macros follow:
 * `OS_appMode OS_DATA_SECTION_ATTRIB_POST(.data.os.OS_appMode)` and
 * `Lock[N] OS_ALIGNED_ATTRIB_POST(8) OS_BSS_SECTION_ATTRIB_POST(.bss.os.Lock)`.
 *
 * After a plain name the first macro must name a linker section, one token
 * (_section_macro_call), so a name after a declarator does not open a second
 * reading. With any macro there, the parser kept one open through every run
 * of macro lines without semicolons (`FuncGen_A(x)` `FuncGen_B(y)`) and ran
 * out of parallel readings before the function after them.
 *
 * @param {GrammarSymbols<string>} $
 * @param {(rule: Rule) => Rule} wrap wraps the declarator (to give it a field)
 *
 * @returns {Rule[]}
 */
function sectionSuffixedDeclarators($, wrap = (rule) => rule) {
  const trailing = choice(
    alias($._trailing_macro_call, $.call_expression),
    alias($._section_macro_call, $.call_expression),
  );
  return [
    seq(
      wrap($.identifier),
      alias($._section_macro_call, $.call_expression),
      repeat(trailing),
    ),
    seq(wrap($.array_declarator), repeat1(trailing)),
  ];
}

module.exports.PREC = PREC;
module.exports.preprocIf = preprocIf;
module.exports.preprocessor = preprocessor;
module.exports.commaSep = commaSep;
module.exports.commaSep1 = commaSep1;
