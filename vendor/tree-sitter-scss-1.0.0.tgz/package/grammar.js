/**
 * @file SCSS grammar for tree-sitter
 * @author Amaan Qureshi <amaanq12@gmail.com>
 * @license MIT
 */

/// <reference types="tree-sitter-cli/dsl" />
// @ts-check

const CSS = require('tree-sitter-css/grammar');

module.exports = grammar(CSS, {
  name: 'scss',

  externals: ($, original) => original.concat([
    $._concat,
  ]),

  rules: {
    _top_level_item: ($, original) => choice(
      original,
      $.postcss_statement,
      $.use_statement,
      $.forward_statement,
      $.mixin_statement,
      $.include_statement,
      $.function_statement,
      $.return_statement,
      $.extend_statement,
      $.error_statement,
      $.warn_statement,
      $.debug_statement,
      $.at_root_statement,
      $.if_statement,
      $.each_statement,
      $.for_statement,
      $.while_statement,
    ),

    _block_item: ($, original) => choice(
      original,
      $.mixin_statement,
      $.include_statement,
      $.function_statement,
      $.return_statement,
      $.extend_statement,
      $.error_statement,
      $.warn_statement,
      $.debug_statement,
      $.at_root_statement,
      $.if_statement,
      $.each_statement,
      $.for_statement,
      $.while_statement,
    ),

    // Selectors

    // From fork kensternberg-authentik/tree-sitter-scss@ece76b7 (Ken Sternberg): bare leading
    // combinators in nested rules, e.g. `.a { > .b { ... } }`.
    selector_combinator: _ => choice(prec.left('>'), prec.left('~'), prec.left('+')),

    _selector: ($, original) => choice(
      original,
      alias($._concatenated_identifier, $.tag_name),
      $.selector_combinator,
      $.placeholder,
    ),

    class_selector: $ => prec(1, seq(
      optional($._selector),
      choice('.', $.nesting_selector),
      alias(choice($.identifier, $._concatenated_identifier), $.class_name),
    )),

    pseudo_class_selector: $ => seq(
      optional($._selector),
      alias($._pseudo_class_selector_colon, ':'),
      alias(choice($.identifier, $._concatenated_identifier), $.class_name),
      optional(alias($.pseudo_class_arguments, $.arguments)),
    ),

    // Declarations

    declaration: $ => seq(
      alias(
        choice($.identifier, $.variable, $._concatenated_identifier),
        $.property_name,
      ),
      ':',
      $._value,
      repeat(seq(optional(','), $._value)),
      optional($.important),
      // From fork kensternberg-authentik/tree-sitter-scss@8e3dd5d, c0aa542 (Ken Sternberg): the
      // `!default` and `!global` variable flags. Adapted: the fork also split variable
      // assignments into their own `(variable)` left-hand side (9216e50); that is not ported, so
      // the left side stays `(property_name)` (Graft reads `$name` variables from it), and the
      // flags may be combined (`$a: 1 !default !global;`).
      repeat(choice($.default, $.global)),
      ';',
    ),

    default: _ => '!default',

    global: _ => '!global',

    // Media queries

    _query: ($, original) => choice(
      original,
      prec(-1, $.interpolation),
    ),

    // Property Values

    _value: ($, original) => choice(
      original,
      // From fork kensternberg-authentik/tree-sitter-scss@96136ee (Ken Sternberg): a bare escape
      // sequence is a valid value, e.g. `$icon: \f42c;`.
      $.escape_sequence,
      prec(-1, choice(
        $.nesting_selector,
        $._concatenated_identifier,
        $.list_value,
        $.map_value,
      )),
      $.variable,
    ),

    // tree-sitter-css 0.20 (which this grammar extends) has no `escape_sequence` rule, so it is
    // defined here (CSS escape: a backslash followed by 1-6 hex digits or one other character).
    escape_sequence: _ => token(seq('\\', choice(/[^\r\n\t 0-9a-fA-F]/, /[0-9a-fA-F]{1,6}/))),

    // From forks kensternberg-authentik/tree-sitter-scss@c86724d (Ken Sternberg) and
    // folliehiyuki/tree-sitter-scss@8acd1f8 (Hoang Nguyen): Sass maps, e.g. `$m: (a: 1, "b": $c);`.
    // Combined: one or more pairs (the folliehiyuki version required two), an optional trailing
    // comma (as in panicinc/tree-sitter-scss@1d77f11), and `key`/`value` fields.
    map_value: $ => prec(2, seq(
      '(',
      sep1(',', $.map_pair),
      optional(','),
      ')',
    )),

    map_pair: $ => seq(
      field('key', $._value),
      ':',
      field('value', $._value),
    ),

    // From fork kensternberg-authentik/tree-sitter-scss@ece76b7 (Ken Sternberg): `@use "x" as ns;`
    // and `@use "x" as *;`.
    use_statement: $ => seq('@use', $.string_value, optional($.use_namespace), ';'),

    use_namespace: $ => seq('as', choice('*', $.namespace)),

    namespace: _ => /[a-zA-Z_\xA0-\xFF][a-zA-Z0-9-_\xA0-\xFF]*/,

    forward_statement: $ => seq('@forward', $._value, ';'),

    mixin_statement: $ => seq(
      '@mixin',
      field('name', $.identifier),
      optional($.parameters),
      $.block,
    ),

    include_statement: $ => seq(
      '@include',
      $.identifier,
      optional(alias($._include_arguments, $.arguments)),
      // From fork panicinc/tree-sitter-scss@1d77f11 (Logan Collins): content block arguments,
      // `@include m using ($x) { ... }`.
      optional(seq('using', $.parameters)),
      choice($.block, ';'),
    ),

    // From fork kensternberg-authentik/tree-sitter-scss@ece76b7 (Ken Sternberg): allow whitespace
    // before `)` and space-separated multi-value arguments, e.g. `@include m( $a: 10px 20px );`.
    // From fork panicinc/tree-sitter-scss@1d77f11 (Logan Collins): trailing comma and `$args...`.
    _include_arguments: $ => seq(
      token.immediate('('),
      sep1(',', alias($._include_argument, $.argument)),
      optional(','),
      ')',
    ),

    _include_argument: $ => seq(
      optional(seq(field('name', $.variable), ':')),
      field('value', $._include_value),
      optional('...'),
    ),

    _include_value: $ => seq($._value, repeat($._value)),

    function_statement: $ => seq(
      '@function',
      field('name', $.identifier),
      optional($.parameters),
      $.block,
    ),

    // From fork panicinc/tree-sitter-scss@1d77f11 (Logan Collins): trailing comma, `@mixin m($a,)`.
    parameters: $ => seq('(', sep1(',', $.parameter), optional(','), ')'),

    parameter: $ => seq(
      $.variable,
      optional(seq(
        ':',
        field('default', $._value),
      )),
    ),

    return_statement: $ => seq('@return', $._value, ';'),

    extend_statement: $ => seq('@extend', choice($._value, $.class_selector), ';'),

    error_statement: $ => seq('@error', $._value, ';'),

    warn_statement: $ => seq('@warn', $._value, ';'),

    debug_statement: $ => seq('@debug', $._value, ';'),

    // From fork kensternberg-authentik/tree-sitter-scss@ece76b7 (Ken Sternberg): `@at-root` takes a
    // selector, e.g. `@at-root b#{&} { ... }`.
    at_root_statement: $ => seq('@at-root', $._selector, $.block),

    if_statement: $ => seq(
      '@if',
      field('condition', $._value),
      $.block,
      repeat($.else_if_clause),
      optional($.else_clause),
    ),

    else_if_clause: $ => seq(
      '@else',
      'if',
      field('condition', $._value),
      $.block,
    ),

    else_clause: $ => seq('@else', $.block),

    each_statement: $ => seq(
      '@each',
      optional(seq(field('key', $.variable), ',')),
      field('value', $.variable),
      'in',
      $._value,
      $.block,
    ),

    for_statement: $ => seq(
      '@for',
      $.variable,
      'from',
      field('from', $._value),
      // From fork panicinc/tree-sitter-scss@1d77f11 (Logan Collins): exclusive `@for ... to ...`.
      choice(
        seq('through', field('through', $._value)),
        seq('to', field('to', $._value)),
      ),
      $.block,
    ),

    while_statement: $ => seq('@while', $._value, $.block),

    call_expression: $ => seq(
      alias(choice($.identifier, $.plain_value), $.function_name),
      $.arguments,
    ),

    binary_expression: $ => prec.left(seq(
      $._value,
      choice('+', '-', '*', '/', '==', '<', '>', '!=', '<=', '>='),
      $._value,
    )),

    list_value: $ => seq(
      '(',
      sep2(',', $._value),
      ')',
    ),

    interpolation: $ => seq('#{', $._value, '}'),

    placeholder: $ => seq('%', $.identifier),

    // From fork kensternberg-authentik/tree-sitter-scss@fa75394 (Ken Sternberg): a concatenated
    // piece may start with a digit, e.g. `.#{$a}-500px`.
    _concatenated_identifier_token: _ => /(--|-?[0-9a-zA-Z_\xA0-\xFF])[a-zA-Z0-9-_\xA0-\xFF]*/,

    _concatenated_identifier: $ => choice(
      seq(
        $.identifier,
        repeat1(seq(
          $._concat,
          choice(
            $.interpolation,
            alias($._concatenated_identifier_token, $.identifier),
            alias(token.immediate('-'), $.identifier),
          ),
        )),
      ),
      seq(
        $.interpolation,
        repeat(seq(
          $._concat,
          choice(
            $.interpolation,
            alias($._concatenated_identifier_token, $.identifier),
            alias(token.immediate('-'), $.identifier),
          ),
        )),
      ),
    ),

    variable: _ => /([a-zA-Z_]+\.)?\$[a-zA-Z-_][a-zA-Z0-9-_]*/,

    // A plain value may not END with a colon, so a bare map key such as `foo` in `(foo: 1)` is not
    // lexed as `foo:` (the problem kensternberg-authentik/tree-sitter-scss@c86724d left open).
    // Same last-character rule as panicinc/tree-sitter-scss@1d77f11 (Logan Collins) /
    // the upstream `improve` branch; otherwise identical to tree-sitter-css 0.20's plain_value.
    plain_value: _ => token(seq(
      repeat(choice(
        /[-_]/,
        /\/[^\*\s,;#!{}()\[\]]/, // Slash not followed by a '*' (which would be a comment)
      )),
      /[a-zA-Z]/,
      optional(seq(
        repeat(choice(
          /[^/\s,;#!{}()\[\]]/, // Not a slash, not a delimiter character
          /\/[^\*\s,;#!{}()\[\]]/, // Slash not followed by a '*' (which would be a comment)
        )),
        choice(
          /[^/\s,:;#!{}()\[\]]/, // Not a slash, not a delimiter character (no colon)
          /\/[^\*\s,:;#!{}()\[\]]/, // Slash not followed by a '*' (no colon)
        ),
      )),
    )),
  },
});

/**
 * Creates a rule to match one or more of the rules separated by `separator`
 *
 * @param {RuleOrLiteral} separator
 *
 * @param {RuleOrLiteral} rule
 *
 * @return {SeqRule}
 *
 */
function sep1(separator, rule) {
  return seq(rule, repeat(seq(separator, rule)));
}

/**
 * Creates a rule to match two or more of the rules separated by `separator`
 *
 * @param {RuleOrLiteral} separator
 *
 * @param {RuleOrLiteral} rules
 *
 * @return {SeqRule}
 */
function sep2(separator, rules) {
  return seq(rules, repeat1(seq(separator, rules)));
}
