; From fork DexClub/tree-sitter-kotlin@d2ff88b (Gang): locals queries.
; Adapted to this grammar: the fork's `callable_reference member:` field does not
; exist here, so the member pattern matches the callable_reference's direct
; simple_identifier child instead. The fork's comments are translated from
; Chinese.

; ============================================
; Scopes
; ============================================

(source_file) @local.scope

(class_declaration) @local.scope
(object_declaration) @local.scope
(companion_object) @local.scope
(anonymous_initializer) @local.scope

(function_declaration) @local.scope
(secondary_constructor) @local.scope
(anonymous_function) @local.scope
(getter) @local.scope
(setter) @local.scope
(lambda_literal) @local.scope

(for_statement) @local.scope
(catch_block) @local.scope
(finally_block) @local.scope
(when_expression) @local.scope
(control_structure_body) @local.scope

; ============================================
; Definitions
; ============================================

; --- function / setter parameters ---
;
; The scope of a Kotlin primary-constructor parameter is not an ordinary
; lexical local:
; 1. a `val`/`var` parameter is really a property;
; 2. a plain parameter is not simply visible in the whole class body either.
;
; class_parameter is therefore not recorded as a local, so it does not leak
; into member functions.

(parameter
  (simple_identifier) @local.definition)

(parameter_with_optional_type
  (simple_identifier) @local.definition)

; --- lambda parameters ---

(lambda_literal
  (lambda_parameters
    (variable_declaration
      (simple_identifier) @local.definition)))

(lambda_literal
  (lambda_parameters
    (multi_variable_declaration
      (variable_declaration
        (simple_identifier) @local.definition))))

; --- block-level val / var definitions ---

(statements
  (property_declaration
    (variable_declaration
      (simple_identifier) @local.definition)))

(statements
  (property_declaration
    (multi_variable_declaration
      (variable_declaration
        (simple_identifier) @local.definition))))

(control_structure_body
  (property_declaration
    (variable_declaration
      (simple_identifier) @local.definition)))

(control_structure_body
  (property_declaration
    (multi_variable_declaration
      (variable_declaration
        (simple_identifier) @local.definition))))

; --- local function definitions ---

(statements
  (function_declaration
    (simple_identifier) @local.definition))

(control_structure_body
  (function_declaration
    (simple_identifier) @local.definition))

; --- for loop variables ---

(for_statement
  (variable_declaration
    (simple_identifier) @local.definition))

(for_statement
  (multi_variable_declaration
    (variable_declaration
      (simple_identifier) @local.definition)))

; --- when (val x = expr) ---

(when_subject
  (variable_declaration
    (simple_identifier) @local.definition))

; --- catch (e: Throwable) ---

(catch_block
  (simple_identifier) @local.definition)

; ============================================
; References
; ============================================

; References are captured only in expression positions, so package/import/
; type/member names are not counted as local references.

(statements
  (simple_identifier) @local.reference)

(control_structure_body
  (simple_identifier) @local.reference)

(property_declaration
  (simple_identifier) @local.reference)

(assignment
  (simple_identifier) @local.reference)

(directly_assignable_expression
  (simple_identifier) @local.reference)

(jump_expression
  (simple_identifier) @local.reference)

(when_subject
  (simple_identifier) @local.reference)

(when_condition
  (simple_identifier) @local.reference)

(if_expression
  (simple_identifier) @local.reference)

(while_statement
  (simple_identifier) @local.reference)

(do_while_statement
  (simple_identifier) @local.reference)

(for_statement
  (simple_identifier) @local.reference)

(value_argument
  . (simple_identifier) @local.reference .)

(value_argument
  (simple_identifier)
  (simple_identifier) @local.reference)

(parenthesized_expression
  (simple_identifier) @local.reference)

(collection_literal
  (simple_identifier) @local.reference)

(call_expression
  (simple_identifier) @local.reference)

(navigation_expression
  (simple_identifier) @local.reference)

(indexing_expression
  (simple_identifier) @local.reference)

(callable_reference
  (simple_identifier) @local.reference)

(prefix_expression
  (simple_identifier) @local.reference)

(postfix_expression
  (simple_identifier) @local.reference)

(spread_expression
  (simple_identifier) @local.reference)

(as_expression
  (simple_identifier) @local.reference)

(multiplicative_expression
  (simple_identifier) @local.reference)

(additive_expression
  (simple_identifier) @local.reference)

(range_expression
  (simple_identifier) @local.reference)

(infix_expression
  (simple_identifier) @local.reference)

(elvis_expression
  (simple_identifier) @local.reference)

(check_expression
  (simple_identifier) @local.reference)

(comparison_expression
  (simple_identifier) @local.reference)

(equality_expression
  (simple_identifier) @local.reference)

(conjunction_expression
  (simple_identifier) @local.reference)

(disjunction_expression
  (simple_identifier) @local.reference)

(interpolated_identifier) @local.reference

(interpolated_expression
  (simple_identifier) @local.reference)
