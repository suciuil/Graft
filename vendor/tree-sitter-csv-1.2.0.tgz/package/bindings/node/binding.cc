#include <napi.h>

typedef struct TSLanguage TSLanguage;

extern "C" TSLanguage *tree_sitter_csv();
extern "C" TSLanguage *tree_sitter_psv();
extern "C" TSLanguage *tree_sitter_tsv();

// "tree-sitter", "language" hashed with BLAKE2
const napi_type_tag LANGUAGE_TYPE_TAG = {
    0x8AF2E5212AD58ABF, 0xD5006CAD83ABBA16
};

static Napi::Object WrapLanguage(Napi::Env env, const char *name, TSLanguage *lang) {
    auto obj = Napi::Object::New(env);
    obj["name"] = Napi::String::New(env, name);
    auto language = Napi::External<TSLanguage>::New(env, lang);
    language.TypeTag(&LANGUAGE_TYPE_TAG);
    obj["language"] = language;
    return obj;
}

Napi::Object Init(Napi::Env env, Napi::Object exports) {
    exports["csv"] = WrapLanguage(env, "csv", tree_sitter_csv());
    exports["psv"] = WrapLanguage(env, "psv", tree_sitter_psv());
    exports["tsv"] = WrapLanguage(env, "tsv", tree_sitter_tsv());
    return exports;
}

NODE_API_MODULE(tree_sitter_csv_binding, Init);
