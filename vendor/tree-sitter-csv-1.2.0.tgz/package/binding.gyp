{
  "targets": [
    {
      "target_name": "tree_sitter_csv_binding",
      "dependencies": [
        "<!(node -p \"require('node-addon-api').targets\"):node_addon_api_except",
      ],
      "include_dirs": [
        "csv/src"
      ],
      "sources": [
        "bindings/node/binding.cc",
        "csv/src/parser.c",
        "psv/src/parser.c",
        "tsv/src/parser.c",
      ],
      "cflags_c": [
        "-std=c99",
      ]
    }
  ]
}
