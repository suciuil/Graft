/**
 * @file C++ grammar for tree-sitter
 * @author Max Brunsfeld <maxbrunsfeld@gmail.com>
 * @author Amaan Qureshi <amaanq12@gmail.com>
 * @author John Drouhard <john@drouhard.dev>
 * @author Pablo Hugen <pabloashugen@protonmail.com>
 * @license MIT
 */

/// <reference types="tree-sitter-cli/dsl" />
// @ts-check

const C = require('tree-sitter-c/grammar');

const PREC = Object.assign(C.PREC, {
  LAMBDA: 18,
  NEW: C.PREC.CALL + 1,
  STRUCTURED_BINDING: -1,
  THREE_WAY: C.PREC.RELATIONAL + 1,
});

const FOLD_OPERATORS = [
  '+', '-', '*', '/', '%',
  '^', '&', '|',
  '=', '<', '>',
  '<<', '>>',
  '+=', '-=', '*=', '/=', '%=', '^=', '&=', '|=',
  '>>=', '<<=',
  '==', '!=', '<=', '>=',
  '&&', '||',
  ',',
  '.*', '->*',
  'or', 'and', 'bitor', 'xor', 'bitand', 'not_eq',
];

const ASSIGNMENT_OPERATORS = [
  '=',
  '*=',
  '/=',
  '%=',
  '+=',
  '-=',
  '<<=',
  '>>=',
  '&=',
  '^=',
  '|=',
  'and_eq',
  'or_eq',
  'xor_eq',
];

// The AUTOSAR compiler abstraction macros that stand for a type
// (Specification of Compiler Abstraction, SWS_COMPILER).
const AUTOSAR_TYPE_MACROS = [
  'FUNC', 'FUNC_P2CONST', 'FUNC_P2VAR',
  'VAR', 'CONST',
  'P2VAR', 'P2CONST', 'CONSTP2VAR', 'CONSTP2CONST',
];

// The `#ifdef __cplusplus` / `#if defined(__cplusplus)` and `#endif` lines
// around an `extern "C" {` fragment (see _preproc_linkage_start), with the
// blank lines after them. Each line may end in a `//` comment or a one-line
// `/* … */` comment (`#endif /* __cplusplus */`, `} /* extern "C" */`).
const LINKAGE_LINE_END = String.raw`[ \t]*(?:\/\/[^\r\n]*|\/\*[^*\r\n]*\*+(?:[^/*\r\n][^*\r\n]*\*+)*\/[ \t]*)?\r?\n`;
const PREPROC_LINKAGE_IF = new RegExp(
  String.raw`#[ \t]*if(?:def[ \t]+__cplusplus|[ \t]+defined[ \t]*(?:\([ \t]*__cplusplus[ \t]*\)|__cplusplus))` +
  LINKAGE_LINE_END + String.raw`[ \t\r\n]*`,
);
const PREPROC_LINKAGE_ENDIF = new RegExp(String.raw`[ \t\r\n]*#[ \t]*endif` + LINKAGE_LINE_END);
// `extern "C" {`, with the brace on the same line or on its own line.
const LINKAGE_OPEN = new RegExp(String.raw`extern[ \t]+"C"[ \t\r\n]*\{` + LINKAGE_LINE_END);
const LINKAGE_CLOSE = new RegExp(String.raw`\}` + LINKAGE_LINE_END);

const commaSep = C.commaSep;
const commaSep1 = C.commaSep1;
const preprocIf = C.preprocIf;

// Items tree-sitter-c adds for unexpanded macros and for function heads,
// `if`/`else` or `extern "C" {` split by `#if`. C++ keeps its own linkage
// handling below.
const C_MACRO_ITEMS = new Set([
  'macro_statement',
  'macro_function_definition',
  '_preproc_function_definition',
  'else_clause',
  '_preproc_ifdef_linkage',
  '_preproc_if_linkage',
  // AUTOSAR function pointer macros, declaration macros and initializer
  // fragments: in C++ they would compete with calls, casts and constructors.
  '_macro_function_type_definition',
  '_macro_function_declaration',
  '_macro_function_field_declaration',
  '_macro_declaration',
  'initializer_fragment',
  // Diab `asm` macro functions: C compilers only.
  '_asm_function_definition',
]);

/**
 * @param {any} member
 * @returns {boolean}
 */
function isCMacroItem(member) {
  return C_MACRO_ITEMS.has(member.name ?? member.content?.name);
}

module.exports = grammar(C, {
  name: 'cpp',

  externals: $ => [
    $.raw_string_delimiter,
    $.raw_string_content,
  ],

  conflicts: $ => [
    // `TASK(name)` at file scope: a macro opening a body, or a macro
    // declaration with attributes (_attributed_macro_declaration).
    [$.macro_function_definition, $._declarator, $.type_specifier, $.expression, $._attributed_macro_declarator],
    // `STATIC FUNC(…)`: a macro modifier before an AUTOSAR type, or the type
    // (_autosar_prefixed_declaration_specifiers).
    [$._autosar_macro_modifier, $.type_specifier],
    [$._autosar_macro_modifier, $.macro_statement],
    [$._declaration_specifiers, $._autosar_prefixed_declaration_specifiers, $._constructor_specifiers],
    [$._macro_loop_header, $.expression],
    // (David Michael, 11d27b9 via arraypress/tree-sitter-cpp)
    // `A::* B<…>::*`: a nested pointer-to-member through a template scope. Giving
    // that scope a static precedence instead broke `ns::T<…>::name` elsewhere.
    [$._type_declarator, $.template_type],
    // `[[a]] [[b]]` before `friend` vs before a declaration's type: genuinely open
    // until the keyword arrives (same shape as the existing using_declaration one).
    [$._declaration_modifiers, $.friend_declaration],
    [$._declaration_modifiers, $.friend_declaration, $.using_declaration],
    // C
    [$.type_specifier, $._declarator],
    [$.type_specifier, $.expression],
    [$.sized_type_specifier],
    [$.attributed_statement],
    [$._declaration_modifiers, $.attributed_statement],
    [$._declaration_modifiers, $.attributed_statement, $.using_declaration],
    [$._top_level_item, $._top_level_statement],
    [$._block_item, $.statement],
    [$.type_qualifier, $.extension_expression],
    [$._declaration_modifiers, $.labeled_statement],
    [$._block_item, $.initializer_list],

    // C++
    [$.template_function, $.template_type],
    [$.template_function, $.template_type, $.expression],
    [$.template_function, $.template_type, $.qualified_identifier],
    [$.template_function, $.template_type, $.qualified_identifier, $.qualified_type_identifier],
    [$._type_declarator, $.sized_type_specifier],
    [$._type_declarator, $.type_specifier],
    [$.template_type, $.qualified_type_identifier],
    [$.qualified_type_identifier, $.qualified_identifier],
    [$.comma_expression, $.initializer_list],
    [$.expression, $._declarator],
    [$.expression, $.structured_binding_declarator],
    [$.expression, $._declarator, $.type_specifier],
    [$.expression, $.identifier_parameter_pack_expansion],
    [$.expression, $._lambda_capture_identifier],
    [$.expression, $._lambda_capture],
    [$.expression, $.structured_binding_declarator, $._lambda_capture_identifier],
    [$.structured_binding_declarator, $._lambda_capture_identifier],
    [$.parameter_list, $.argument_list],
    [$.type_specifier, $.call_expression],
    [$._declaration_specifiers, $._constructor_specifiers],
    [$._binary_fold_operator, $._fold_operator],
    [$._function_declarator_seq],
    [$.type_specifier, $.sized_type_specifier],
    [$.initializer_pair, $.comma_expression],
    [$.expression_statement, $._for_statement_body],
    [$.init_statement, $._for_statement_body],
    [$.field_expression, $.template_method, $.template_type],
    [$.field_expression, $.template_method],
    [$.qualified_field_identifier, $.template_method, $.template_type],
    [$.type_specifier, $.template_type, $.template_function, $.expression],
    [$.splice_type_specifier, $.splice_expression],
    // Unit-test and AUTOSAR macros (macro_function_definition, macro_type_specifier)
    [$._cpp_declaration_declarators],
    [$._call_modified_declarator, $.init_declarator],
    [$._call_modifier, $._call_modified_declarator],
    [$.macro_call_modifier, $.expression],
    [$.macro_call_modifier, $._declarator, $.expression],
    [$.macro_call_modifier, $.sized_type_specifier],
    [$.macro_call_modifier, $._type_declarator, $.type_specifier],
    [$.macro_call_modifier, $._declarator, $.type_specifier],
    [$.macro_call_modifier, $._field_declarator],
    [$.macro_call_modifier, $._type_declarator],
    [$.macro_call_modifier, $._declarator],
    [$.macro_call_modifier, $.type_specifier],
    [$.macro_call_modifier, $.type_specifier, $.expression],
    [$.macro_call_modifier, $._declarator, $.type_specifier, $.expression],
    [$.macro_function_definition, $._declarator, $.type_specifier, $.expression],
    [$.macro_call_modifier, $.init_declarator],
    [$._declarator, $.type_specifier, $._field_macro_statement],
    [$.macro_statement, $.type_specifier, $.expression],
    [$.macro_statement, $.expression],
    [$.macro_statement, $.type_specifier],
    [$.macro_statement, $._class_name],
    [$.macro_statement, $.sized_type_specifier],
    [$.macro_statement, $.type_specifier, $._macro_gnu_asm_expression],
    [$.macro_statement, $._macro_gnu_asm_expression],
    [$.macro_statement, $.concatenated_string],
    [$._field_macro_statement],
    [$._declaration_modifiers, $.type_descriptor],
    [$.macro_statement, $._declarator, $.type_specifier, $.expression],
    [$.macro_statement, $._declarator, $.type_specifier],
    // @auto-conflicts-end
  ],

  // tree-sitter-c skips stray `#if`/`#else`/`#endif` lines as extras. Here they
  // win over the C++ preprocessor rules, so whole `#if` blocks would be lost.
  extras: ($, original) => original.filter((e) => e.name !== 'preproc_conditional_line'),

  inline: ($, original) => original.concat([
    $._namespace_identifier,
    $._cpp_declaration_specifiers,
  ]),

  precedences: $ => [
    [$.argument_list, $.type_qualifier],
    [$._expression_not_binary, $._class_name],
  ],

  rules: {
    _top_level_item: ($, original) => choice(
      ...original.members.filter((member) =>
        member.content?.name != '_old_style_function_definition' &&
        !isCMacroItem(member),
      ),
      $._preproc_linkage_start,
      $._preproc_linkage_end,
      $.namespace_definition,
      $.concept_definition,
      $.namespace_alias_definition,
      $.using_declaration,
      $.alias_declaration,
      $.static_assert_declaration,
      $.consteval_block_declaration,
      $.template_declaration,
      $.template_instantiation,
      $.module_declaration,
      $.export_declaration,
      $.import_declaration,
      $.global_module_fragment_declaration,
      $.private_module_fragment_declaration,
      alias($.constructor_or_destructor_definition, $.function_definition),
      alias($.operator_cast_definition, $.function_definition),
      alias($.operator_cast_declaration, $.declaration),
      // Unit-test macros that open a body, at file scope only:
      // `COU_TEST(TestCase_001, "Init") { … }`. With its negative dynamic
      // precedence it only wins where no constructor or function reading exists.
      $.macro_function_definition,
      alias($._attributed_macro_declaration, $.declaration),
    ),

    // A macro that expands to a function's type and name, with attributes and
    // no type of its own: `TASK(Task_10ms) __attribute__((weak));` (OSEK). C
    // reads it as a declaration without a type; C++ has no such declaration.
    _attributed_macro_declaration: $ => prec.dynamic(PREC.MACRO, seq(
      field('declarator', alias($._attributed_macro_declarator, $.function_declarator)),
      repeat1($.attribute_specifier),
      ';',
    )),

    _attributed_macro_declarator: $ => seq(
      field('declarator', $.identifier),
      field('parameters', $.parameter_list),
    ),

    // C++ headers commonly split an extern "C" linkage specification across
    // preprocessor branches. Treat those two exact fragments as top-level
    // syntax so declarations between them remain ordinary declarations.
    // (Jonathan Ellis, 4257712 via BrokkAi/tree-sitter-cpp)
    //
    // Each fragment is one token, from `#if` to `#endif`. A token for the
    // `#ifdef __cplusplus` line alone also matched where that branch holds other
    // code (`#ifdef __cplusplus` `class Log { … };` `#endif`), and the parse then
    // failed on the line after it. A fragment token that does not match all the
    // way leaves the lexer with the ordinary `#ifdef`/`#if`.
    _preproc_linkage_start: _ => token(prec(1, seq(
      PREPROC_LINKAGE_IF,
      LINKAGE_OPEN,
      PREPROC_LINKAGE_ENDIF,
    ))),

    _preproc_linkage_end: _ => token(prec(1, seq(
      PREPROC_LINKAGE_IF,
      LINKAGE_CLOSE,
      PREPROC_LINKAGE_ENDIF,
    ))),

    _block_item: ($, original) => choice(
      ...original.members.filter((member) =>
        member.content?.name != '_old_style_function_definition' &&
        !isCMacroItem(member) &&
        !member.name?.startsWith('preproc_if'),
      ).map((member) =>
        // tree-sitter-c allows `#embed` inside an initializer list. A C++ argument_list
        // accepts both initializer lists and compound statements, so prefer the
        // initializer list for `f({ #embed "x" })`.
        member.name === 'preproc_embed' ? prec(-1, member) : member,
      ),
      $.namespace_definition,
      $.concept_definition,
      $.namespace_alias_definition,
      $.using_declaration,
      $.alias_declaration,
      $.static_assert_declaration,
      $.consteval_block_declaration,
      $.template_declaration,
      $.template_instantiation,
      $.export_declaration,
      $.import_declaration,
      alias($.preproc_if_in_block, $.preproc_if),
      alias($.preproc_ifdef_in_block, $.preproc_ifdef),
      alias($.constructor_or_destructor_definition, $.function_definition),
      alias($.operator_cast_definition, $.function_definition),
      alias($.operator_cast_declaration, $.declaration),
      // A macro statement without a semicolon inside a function body:
      // `SIM_LOCK(mutex)` on its own line. Only chosen when nothing else fits.
      $.macro_statement,
    ),

    ...preprocIf('', $ => $._top_level_item),
    ...preprocIf('_in_block', $ => $._block_item),

    // Types

    placeholder_type_specifier: $ => prec(1, seq(
      field('constraint', optional(choice(
        alias($.qualified_type_identifier, $.qualified_identifier),
        $.template_type,
        $._type_identifier,
      ))),
      choice($.auto, alias($.decltype_auto, $.decltype)),
    )),

    auto: _ => 'auto',
    decltype_auto: $ => seq(
      'decltype',
      '(',
      $.auto,
      ')',
    ),
    // The operand is an expression, which may be a comma expression: SFINAE
    // spells "this call compiles, and the type is void" as
    // `decltype(chip.SetChannels(a, b), void())`.
    decltype: $ => seq(
      'decltype',
      '(',
      choice($.expression, $.comma_expression),
      ')',
    ),

    type_specifier: $ => choice(
      $.struct_specifier,
      $.union_specifier,
      $.enum_specifier,
      $.class_specifier,
      $.sized_type_specifier,
      alias($.pack_index_expression, $.pack_index_type),
      $.primitive_type,
      $.template_type,
      $.dependent_type,
      $.splice_type_specifier,
      $.placeholder_type_specifier,
      $.decltype,
      // GNU `typeof` / `__typeof__` and Clang's `_BitInt(N)` are accepted in C++ too
      // (rules inherited from tree-sitter-c).
      $.typeof_specifier,
      $.bitint_type,
      $.macro_type_specifier,
      prec.right(choice(
        alias($.qualified_type_identifier, $.qualified_identifier),
        $._type_identifier,
      )),
    ),

    // tree-sitter-c treats C23 `constexpr` as a storage class specifier; this grammar
    // has always exposed it as a type qualifier (see storage_class_specifier below).
    type_qualifier: (_, original) => choice(
      original,
      'constexpr',
      'mutable',
      'constinit',
      'consteval',
    ),

    type_descriptor: (_, original) => prec.right(original),

    // The AUTOSAR compiler abstraction, as in C: `FUNC(void, X_CODE) f(void)`,
    // `VAR(uint8, AUTOMATIC) n;`, `P2CONST(T, AUTOMATIC, X_DATA) p`. Only the
    // standard macro names: in C++ any `T(` may begin a functional cast, a
    // constructor call, `new T(…)` or `operator T()`, and a macro reading open to
    // every name would take those over.
    macro_type_specifier: $ => prec.dynamic(-1, seq(
      field('name', alias(choice(...AUTOSAR_TYPE_MACROS), $.identifier)),
      '(',
      field('type', $.type_descriptor),
      repeat1(seq(',', field('argument', choice($.identifier, alias($.primitive_type, $.identifier))))),
      ')',
    )),

    attribute: ($, original) => seq(
      optional(seq('using', field('namespace', $.identifier), ':')),
      ...original.members,
    ),

    annotation: $ => seq('=', $.expression),

    attribute_declaration: ($, original) => choice(
      original,
      seq('[[', commaSep1($.annotation), ']]'),
    ),

    // When used in a trailing return type, these specifiers can now occur immediately before
    // a compound statement. This introduces a shift/reduce conflict that needs to be resolved
    // with an associativity.
    _class_declaration: $ => seq(
      repeat(choice($.attribute_specifier, $.alignas_qualifier)),
      optional($.ms_declspec_modifier),
      repeat($.attribute_declaration),
      $._class_declaration_item,
    ),
    _class_declaration_item: $ => prec.right(seq(
      choice(
        field('name', $._class_name),
        seq(
          optional(field('name', $._class_name)),
          optional($.virtual_specifier),
          optional($.base_class_clause),
          field('body', $.field_declaration_list),
        ),
      ),
      optional($.attribute_specifier),
    )),

    class_specifier: $ => seq(
      'class',
      $._class_declaration,
    ),

    union_specifier: $ => seq(
      'union',
      $._class_declaration,
    ),

    struct_specifier: $ => seq(
      'struct',
      $._class_declaration,
    ),

    _class_name: $ => prec.right(choice(
      $._type_identifier,
      $.template_type,
      $.splice_type_specifier,
      alias($.qualified_type_identifier, $.qualified_identifier),
    )),

    function_definition: ($, original) => ({
      ...original,
      members: original.members.map(
        (e) => e.name === '_macro_declaration_specifiers' ?
          // The specifiers of C++'s own `declaration` (see the overrides below).
          $._cpp_declaration_specifiers :
          e.name !== 'body' ?
          e :
          // `void f(int) = delete;` and `A::A() = default;` outside a class
          // (David Michael, 11d27b9 via arraypress/tree-sitter-cpp)
          choice(
            field('body', choice(e.content, $.try_statement)),
            prec.dynamic(1, $.default_method_clause),
            prec.dynamic(1, $.delete_method_clause),
          )),
    }),

    declaration: $ => choice(
      seq(
        $._cpp_declaration_specifiers,
        $._cpp_declaration_declarators,
        ';',
      ),
      seq(
        $._cpp_declaration_specifiers,
        optional(seq($._cpp_declaration_declarators, ',')),
        field('declarator', alias($._macro_attributed_function_declarator, $.function_declarator)),
        ';',
      ),
    ),

    // C's macro modifiers in front of the type (`STATIC uint8 x;`) would compete
    // with every C++ type name, so C++ takes them only before an AUTOSAR
    // compiler abstraction type: `STATIC FUNC(void, X_CODE) f(void)`,
    // `extern STATIC FUNC(T, X_CODE) g(P2CONST(uint8, AUTOMATIC, X) p);`.
    // Without this, `STATIC` reads as the type and `FUNC(…)` as the declarator.
    _cpp_declaration_specifiers: $ => choice(
      $._declaration_specifiers,
      $._autosar_prefixed_declaration_specifiers,
    ),

    _autosar_prefixed_declaration_specifiers: $ => prec.right(seq(
      repeat($._declaration_modifiers),
      alias($._autosar_macro_modifier, $.macro_modifier),
      field('type', $.macro_type_specifier),
      repeat($._declaration_modifiers),
    )),

    _autosar_macro_modifier: $ => prec.dynamic(PREC.MACRO, field('name', $.identifier)),

    _cpp_declaration_declarators: $ => commaSep1(field('declarator', choice(
      seq(
        // C uses _declaration_declarator here for some nice macro parsing in function declarators,
        // but this causes a world of pain for C++ so we'll just stick to the normal _declarator here.
        optional($._call_modifier),
        $._declarator,
        optional($.gnu_asm_expression),
      ),
      $.init_declarator,
    ))),

    // An attribute macro ends a prototype only right before its `;`:
    // `void f(void) MK_ATTR_NORETURN;`, `int f(const char *, ...) ATTR_FORMAT(1,2);`.
    _macro_attributed_function_declarator: $ => prec.right(seq(
      field('declarator', $._declarator),
      $._function_declarator_seq,
      repeat1(choice($.identifier, alias($._trailing_macro_call, $.call_expression))),
    )),

    _macro_attributed_function_field_declarator: $ => prec.right(seq(
      field('declarator', $._field_declarator),
      $._function_declarator_seq,
      repeat1(choice($.identifier, alias($._trailing_macro_call, $.call_expression))),
    )),

    virtual_specifier: _ => choice(
      'final', // the only legal value here for classes
      'override', // legal for functions in addition to final, plus permutations.
    ),

    _declaration_modifiers: ($, original) => choice(
      original,
      'virtual',
    ),

    // tree-sitter-c's macro guesses (`STATIC FUNC(...) f()`, `for Each(x)`, an
    // orphan `else`) would collide with constructors and other C++ syntax.
    for_statement: ($, original) => original.members[0],
    else_clause: $ => seq('else', $.statement),

    explicit_function_specifier: $ => choice(
      'explicit',
      prec(PREC.CALL, seq(
        'explicit',
        '(',
        $.expression,
        ')',
      )),
    ),

    base_class_clause: $ => seq(
      ':',
      commaSep1(seq(
        repeat($.attribute_declaration),
        optional(choice(
          $.access_specifier,
          seq($.access_specifier, optional('virtual')),
          seq('virtual', optional($.access_specifier)),
        )),
        $._class_name,
        optional('...'),
      )),
    ),

    enum_specifier: $ => prec.right(seq(
      'enum',
      optional(choice('class', 'struct')),
      // `enum [[deprecated]] E { A [[deprecated]] = 1 };`
      // (Muppetsg2, 0df81a0 via Muppetsg2/tree-sitter-cpp)
      repeat($.attribute_declaration),
      choice(
        seq(
          field('name', $._class_name),
          optional($._enum_base_clause),
          optional(field('body', $.enumerator_list)),
        ),
        field('body', $.enumerator_list),
      ),
      optional($.attribute_specifier),
    )),

    // (Muppetsg2, 0df81a0 via Muppetsg2/tree-sitter-cpp)
    enumerator: $ => seq(
      field('name', $.identifier),
      repeat($.attribute_declaration),
      optional(seq(
        '=',
        field('value', $.expression),
      )),
    ),

    _enum_base_clause: $ => prec.left(seq(
      ':',
      field('base', choice(
        alias($.qualified_type_identifier, $.qualified_identifier),
        $._type_identifier,
        $.primitive_type,
        $.sized_type_specifier,
      )),
    )),

    // The `auto` storage class is removed in C++0x in order to allow for the `auto` type.
    // `constexpr` stays a type_qualifier in C++ (tree-sitter-c lists it here for C23).
    storage_class_specifier: (_, original) => choice(
      ...original.members.filter((member) => member.value !== 'auto' && member.value !== 'constexpr'),
      'thread_local',
    ),

    dependent_type: $ => prec.dynamic(-1, prec.right(seq(
      'typename',
      $.type_specifier,
    ))),

    // Declarations

    module_name: $ => seq(
      $.identifier,
      repeat(seq('.', $.identifier),
      ),
    ),

    module_partition: $ => seq(
      ':',
      $.module_name,
    ),

    module_declaration: $ => seq(
      optional('export'),
      'module',
      field('name', $.module_name),
      field('partition', optional($.module_partition)),
      optional($.attribute_declaration),
      ';',
    ),

    export_declaration: $ => prec(1, seq(
      'export',
      choice($._block_item, $.declaration_list),
    )),

    import_declaration: $ => seq(
      'import',
      choice(
        field('name', $.module_name),
        field('partition', $.module_partition),
        field('header', choice(
          $.string_literal,
          $.system_lib_string,
        )),
      ),
      optional($.attribute_declaration),
      ';',
    ),

    global_module_fragment_declaration: _ => seq('module', ';'),
    private_module_fragment_declaration: _ => seq('module', ':', 'private', ';'),

    template_declaration: $ => seq(
      'template',
      field('parameters', $.template_parameter_list),
      optional($.requires_clause),
      choice(
        $._empty_declaration,
        $.alias_declaration,
        $.declaration,
        $.template_declaration,
        $.function_definition,
        $.concept_definition,
        $.friend_declaration,
        alias($.constructor_or_destructor_declaration, $.declaration),
        alias($.constructor_or_destructor_definition, $.function_definition),
        alias($.operator_cast_declaration, $.declaration),
        alias($.operator_cast_definition, $.function_definition),
      ),
    ),

    template_instantiation: $ => prec(1, seq(
      optional('extern'),
      'template',
      choice(
        seq(
          optional($._declaration_specifiers),
          field('declarator', $._declarator),
        ),
        // `template class Ring<int, 4>;` names a class and declares nothing
        // (David Michael, 11d27b9 via arraypress/tree-sitter-cpp)
        $._class_name_specifier_for_instantiation,
      ),
      ';',
    )),

    _class_name_specifier_for_instantiation: $ => seq(
      choice('class', 'struct', 'union'),
      field('name', $._class_name),
    ),

    template_parameter_list: $ => seq(
      '<',
      commaSep(choice(
        $.parameter_declaration,
        $.optional_parameter_declaration,
        $.type_parameter_declaration,
        $.variadic_parameter_declaration,
        $.variadic_type_parameter_declaration,
        $.optional_type_parameter_declaration,
        $.template_template_parameter_declaration,
      )),
      alias(token(prec(1, '>')), '>'),
    ),

    type_parameter_declaration: $ => prec(1, seq(
      choice('typename', 'class'),
      optional($._type_identifier),
    )),

    variadic_type_parameter_declaration: $ => prec(1, seq(
      choice('typename', 'class'),
      '...',
      optional($._type_identifier),
    )),

    optional_type_parameter_declaration: $ => seq(
      choice('typename', 'class'),
      optional(field('name', $._type_identifier)),
      '=',
      field('default_type', $.type_specifier),
    ),

    template_template_parameter_declaration: $ => seq(
      'template',
      field('parameters', $.template_parameter_list),
      choice(
        $.type_parameter_declaration,
        $.variadic_type_parameter_declaration,
        $.optional_type_parameter_declaration,
      ),
    ),

    parameter_list: $ => seq(
      '(',
      commaSep(choice(
        $.parameter_declaration,
        $.explicit_object_parameter_declaration,
        $.optional_parameter_declaration,
        $.variadic_parameter_declaration,
        '...',
      )),
      ')',
    ),

    explicit_object_parameter_declaration: $ => seq(
      $.this,
      $.parameter_declaration,
    ),

    optional_parameter_declaration: $ => seq(
      $._declaration_specifiers,
      field('declarator', optional(choice($._declarator, $.abstract_reference_declarator))),
      '=',
      field('default_value', $.expression),
    ),

    variadic_parameter_declaration: $ => seq(
      $._declaration_specifiers,
      field('declarator', choice(
        $.variadic_declarator,
        alias($.variadic_reference_declarator, $.reference_declarator),
      )),
    ),

    variadic_declarator: $ => seq(
      '...',
      optional($.identifier),
    ),

    variadic_reference_declarator: $ => seq(
      choice('&&', '&'),
      $.variadic_declarator,
    ),

    init_declarator: ($, original) => choice(
      original,
      seq(
        field('declarator', $._declarator),
        field('value', choice(
          $.argument_list,
          $.initializer_list,
        )),
      ),
    ),

    operator_cast: $ => prec.right(1, seq(
      'operator',
      $._declaration_specifiers,
      field('declarator', $._abstract_declarator),
    )),

    // Avoid ambiguity between compound statement and initializer list in a construct like:
    //   A b {};
    compound_statement: (_, original) => prec(-1, original),

    // Same items as tree-sitter-c (including `#embed` and standalone preprocessor
    // calls), but without its prec(1) on the repeated items: that precedence would
    // statically resolve `int f() { a(), b(); }` as an initializer list, while C++
    // relies on the [comma_expression, initializer_list] conflict here. A trailing comma
    // is covered by the repeat, so no extra `optional(',')` before the closing brace.
    initializer_list: $ => seq(
      '{',
      repeat(choice(
        seq(choice($.initializer_pair, $.expression, $.initializer_list, $.preproc_embed), ','),
        $.preproc_call,
      )),
      optional(choice($.initializer_pair, $.expression, $.initializer_list, $.preproc_embed)),
      '}',
    ),

    // An initializer under `#if` carries its own comma: after it when it
    // comes before the last unconditional initializer, before it when it
    // comes after the first one.
    // (John Anderson, e11cb53 via sontek/tree-sitter-cpp)
    // Written so the parser never has to guess which plain initializer is "the" one:
    // a trailing-comma block can only follow `:` or `,`, a leading-comma block only an
    // initializer or another such block. Same trees as the fork's `P* F S*` form,
    // without its parse-time conflict.
    field_initializer_list: $ => {
      const trailing = repeat(choice(
        alias($.preproc_if_in_field_initializer_list, $.preproc_if),
        alias($.preproc_ifdef_in_field_initializer_list, $.preproc_ifdef),
      ));
      return seq(
        ':',
        trailing,
        $.field_initializer,
        repeat(choice(
          seq(',', trailing, $.field_initializer),
          alias($.preproc_if_in_field_initializer_list_leading_comma, $.preproc_if),
          alias($.preproc_ifdef_in_field_initializer_list_leading_comma, $.preproc_ifdef),
        )),
      );
    },

    ...preprocIf('_in_field_initializer_list', $ => seq($.field_initializer, ',')),
    ...preprocIf('_in_field_initializer_list_leading_comma', $ => seq(',', $.field_initializer)),

    field_initializer: $ => prec(1, seq(
      choice(
        $._field_identifier,
        $.template_method,
        alias($.qualified_field_identifier, $.qualified_identifier),
      ),
      choice($.initializer_list, $.argument_list),
      optional('...'),
    )),

    _field_declaration_list_item: ($, original) => choice(
      ...original.members.filter((member) => !isCMacroItem(member)),
      $.template_declaration,
      alias($.inline_method_definition, $.function_definition),
      alias($.constructor_or_destructor_definition, $.function_definition),
      alias($.constructor_or_destructor_declaration, $.declaration),
      alias($.operator_cast_definition, $.function_definition),
      alias($.operator_cast_declaration, $.declaration),
      $.friend_declaration,
      seq($.access_specifier, ':'),
      $.alias_declaration,
      $.using_declaration,
      $.type_definition,
      $.static_assert_declaration,
      $.consteval_block_declaration,
      ';',
    ),

    field_declaration: $ => choice(
      seq(
        $._declaration_specifiers,
        commaSep(seq(
          field('declarator', $._field_declarator),
          optional(choice(
            $.bitfield_clause,
            field('default_value', $.initializer_list),
            seq('=', field('default_value', choice($.expression, $.initializer_list))),
          )),
        )),
        optional($.attribute_specifier),
        ';',
      ),
      seq(
        $._declaration_specifiers,
        field('declarator', alias($._macro_attributed_function_field_declarator, $.function_declarator)),
        ';',
      ),
    ),

    inline_method_definition: $ => seq(
      $._declaration_specifiers,
      field('declarator', $._field_declarator),
      choice(
        field('body', choice($.compound_statement, $.try_statement)),
        $.default_method_clause,
        $.delete_method_clause,
        $.pure_virtual_clause,
      ),
    ),

    _constructor_specifiers: $ => choice(
      $._declaration_modifiers,
      $.explicit_function_specifier,
    ),

    operator_cast_definition: $ => seq(
      repeat($._constructor_specifiers),
      field('declarator', choice(
        $.operator_cast,
        alias($.qualified_operator_cast_identifier, $.qualified_identifier),
      )),
      field('body', choice($.compound_statement, $.try_statement)),
    ),

    operator_cast_declaration: $ => prec(1, seq(
      repeat($._constructor_specifiers),
      field('declarator', choice(
        $.operator_cast,
        alias($.qualified_operator_cast_identifier, $.qualified_identifier),
      )),
      optional(seq('=', field('default_value', $.expression))),
      ';',
    )),

    constructor_try_statement: $ => seq(
      'try',
      optional($.field_initializer_list),
      field('body', $.compound_statement),
      repeat1($.catch_clause),
    ),

    constructor_or_destructor_definition: $ => seq(
      repeat($._constructor_specifiers),
      field('declarator', $.function_declarator),
      choice(
        seq(
          optional($.field_initializer_list),
          field('body', $.compound_statement),
        ),
        alias($.constructor_try_statement, $.try_statement),
        $.default_method_clause,
        $.delete_method_clause,
        $.pure_virtual_clause,
      ),
    ),

    constructor_or_destructor_declaration: $ => seq(
      repeat($._constructor_specifiers),
      field('declarator', $.function_declarator),
      ';',
    ),

    default_method_clause: _ => seq('=', 'default', ';'),
    // C++26: = delete("reason") (David Michael, 11d27b9 via arraypress/tree-sitter-cpp)
    // The reason outranks reading `delete ("…")` as a delete-expression of a string.
    delete_method_clause: $ => seq('=', 'delete', optional(prec(1, seq('(', $.string_literal, ')'))), ';'),
    pure_virtual_clause: _ => seq('=', /0/, ';'),

    friend_declaration: $ => seq(
      // (David Michael, 11d27b9 via arraypress/tree-sitter-cpp)
      repeat($.attribute_declaration),
      optional('constexpr'),
      'friend',
      choice(
        $.declaration,
        $.function_definition,
        seq(
          optional(choice(
            'class',
            'struct',
            'union',
          )),
          $._class_name, ';',
        ),
      ),
    ),

    access_specifier: _ => choice(
      'public',
      'private',
      'protected',
    ),

    _declarator: ($, original) => choice(
      original,
      $.reference_declarator,
      $.qualified_identifier,
      $.template_function,
      $.operator_name,
      $.destructor_name,
      $.structured_binding_declarator,
    ),

    _field_declarator: ($, original) => choice(
      original,
      alias($.reference_field_declarator, $.reference_declarator),
      $.template_method,
      $.operator_name,
    ),

    _type_declarator: ($, original) => choice(
      original,
      alias($.reference_type_declarator, $.reference_declarator),
    ),

    _abstract_declarator: ($, original) => choice(
      original,
      $.abstract_reference_declarator,
      // `void (C::*)(int)` in type-ids (Andrea Boido, c17b0ec via Odiob/tree-sitter-cpp)
      alias($.abstract_qualified_identifier, $.qualified_identifier),
    ),

    reference_declarator: $ => prec.dynamic(1, prec.right(seq(choice('&', '&&'), $._declarator))),
    // pointer to member: `int Widget::* p`, `int (Widget::*fn)() const`
    // (David Michael, 11d27b9 via arraypress/tree-sitter-cpp)
    pointer_type_declarator: ($, original) => choice(
      original,
      prec.dynamic(1, prec.right(seq(
        field('scope', choice($._namespace_identifier, $.template_type)),
        '::',
        '*',
        repeat($.type_qualifier),
        field('declarator', $._type_declarator),
      ))),
    ),
    pointer_field_declarator: ($, original) => choice(
      original,
      prec.dynamic(1, prec.right(seq(
        field('scope', choice($._namespace_identifier, $.template_type)),
        '::',
        '*',
        repeat($.type_qualifier),
        field('declarator', $._field_declarator),
      ))),
    ),

    reference_field_declarator: $ => prec.dynamic(1, prec.right(seq(choice('&', '&&'), $._field_declarator))),
    reference_type_declarator: $ => prec.dynamic(1, prec.right(seq(choice('&', '&&'), $._type_declarator))),
    abstract_reference_declarator: $ => prec.right(seq(choice('&', '&&'), optional($._abstract_declarator))),

    // Attributes on bindings (David Michael, 11d27b9 via arraypress/tree-sitter-cpp)
    structured_binding_declarator: $ => prec.dynamic(PREC.STRUCTURED_BINDING, seq(
      '[', commaSep1(seq($.identifier, repeat($.attribute_declaration))), ']',
    )),

    ref_qualifier: _ => choice('&', '&&'),

    _function_declarator_seq: $ => seq(
      field('parameters', $.parameter_list),
      optional($._function_attributes_start),
      optional($.ref_qualifier),
      optional($._function_exception_specification),
      optional($._function_attributes_end),
      optional($.trailing_return_type),
      optional($._function_postfix),
    ),

    _function_attributes_start: $ => prec(1, choice(
      seq(repeat1($.attribute_specifier), repeat($.type_qualifier)),
      seq(repeat($.attribute_specifier), repeat1($.type_qualifier)),
    )),

    _function_exception_specification: $ => choice(
      $.noexcept,
      $.throw_specifier,
    ),

    _function_attributes_end: $ => prec.right(seq(
      optional($.gnu_asm_expression),
      choice(
        seq(repeat1($.attribute_specifier), repeat($.attribute_declaration)),
        seq(repeat($.attribute_specifier), repeat1($.attribute_declaration)),
      ),
    )),

    _function_postfix: $ => prec.right(choice(
      repeat1($.virtual_specifier),
      $.requires_clause,
      repeat1($.contract_specifier),
    )),

    // C++26 contracts: pre(x > 0), post(r: r > 0)
    // (David Michael, 11d27b9 via arraypress/tree-sitter-cpp)
    contract_specifier: $ => seq(
      choice('pre', 'post'),
      repeat($.attribute_declaration),
      '(',
      optional(seq(field('result', $.identifier), ':')),
      field('condition', $.expression),
      ')',
    ),

    function_declarator: $ => prec.dynamic(1, seq(
      field('declarator', $._declarator),
      $._function_declarator_seq,
    )),

    function_field_declarator: $ => prec.dynamic(1, seq(
      field('declarator', $._field_declarator),
      $._function_declarator_seq,
    )),

    abstract_function_declarator: $ => seq(
      field('declarator', optional($._abstract_declarator)),
      $._function_declarator_seq,
    ),

    trailing_return_type: $ => seq('->', $.type_descriptor),

    noexcept: $ => prec.right(seq(
      'noexcept',
      optional(
        seq(
          '(',
          optional($.expression),
          ')',
        ),
      ),
    )),

    throw_specifier: $ => seq(
      'throw',
      seq(
        '(',
        commaSep($.type_descriptor),
        ')',
      ),
    ),

    template_type: $ => seq(
      field('name', $._type_identifier),
      field('arguments', $.template_argument_list),
    ),

    template_method: $ => seq(
      field('name', choice($._field_identifier, $.operator_name)),
      field('arguments', $.template_argument_list),
    ),

    template_function: $ => seq(
      field('name', $.identifier),
      field('arguments', $.template_argument_list),
    ),

    template_argument_list: $ => seq(
      '<',
      commaSep(choice(
        prec.dynamic(3, $.type_descriptor),
        prec.dynamic(2, alias($.type_parameter_pack_expansion, $.parameter_pack_expansion)),
        prec.dynamic(1, $.expression),
      )),
      alias(token(prec(1, '>')), '>'),
    ),

    namespace_definition: $ => seq(
      optional('inline'),
      'namespace',
      optional($.attribute_declaration),
      field('name', optional(
        choice(
          $._namespace_identifier,
          $.nested_namespace_specifier,
        ))),
      field('body', $.declaration_list),
    ),

    namespace_alias_definition: $ => seq(
      'namespace',
      field('name', $._namespace_identifier),
      '=',
      choice(
        $._namespace_identifier,
        $.nested_namespace_specifier,
        $.splice_specifier,
      ),
      ';',
    ),

    _namespace_specifier: $ => seq(
      optional('inline'),
      $._namespace_identifier,
    ),

    nested_namespace_specifier: $ => prec(1, seq(
      optional($._namespace_specifier),
      '::',
      choice(
        $.nested_namespace_specifier,
        $._namespace_specifier,
      ),
    )),

    using_declaration: $ => seq(
      repeat($.attribute_declaration),
      'using',
      choice(
        seq(
          choice('namespace', 'enum'),
          choice(
            $.identifier,
            $.qualified_identifier,
            $.splice_type_specifier,
          ),
        ),
        // `using std::a, std::b;` (Duncan Holm, 9c54ec5 via frou/tree-sitter-cpp);
        // splice_type_specifier kept so plain `using [:r:];` still parses as before.
        commaSep1(
          choice(
            $.identifier,
            $.qualified_identifier,
            $.splice_type_specifier,
          ),
        ),
      ),
      ';',
    ),

    alias_declaration: $ => seq(
      'using',
      field('name', $._type_identifier),
      repeat($.attribute_declaration),
      '=',
      field('type', $.type_descriptor),
      ';',
    ),

    // `_Static_assert` is the C11 spelling; GCC and Clang also accept it in C++,
    // and it shows up in headers shared between C and C++.
    static_assert_declaration: $ => seq(
      choice('static_assert', '_Static_assert'),
      '(',
      field('condition', $.expression),
      optional(seq(
        ',',
        field('message', $._string),
      )),
      ')',
      ';',
    ),

    consteval_block_declaration: $ => seq(
      'consteval',
      field('body', $.compound_statement),
    ),

    concept_definition: $ => seq(
      'concept',
      field('name', $.identifier),
      '=',
      $.expression,
      ';',
    ),

    // Statements

    _top_level_statement: ($, original) => choice(
      original,
      $.co_return_statement,
      $.co_yield_statement,
      $.for_range_loop,
      $.expansion_statement,
      $.try_statement,
      $.throw_statement,
    ),

    _non_case_statement: ($, original) => choice(
      original,
      $.co_return_statement,
      $.co_yield_statement,
      $.for_range_loop,
      $.expansion_statement,
      $.try_statement,
      $.throw_statement,
    ),

    switch_statement: $ => seq(
      'switch',
      field('condition', $.condition_clause),
      field('body', $.compound_statement),
    ),

    while_statement: $ => seq(
      'while',
      field('condition', $.condition_clause),
      field('body', $.statement),
    ),

    if_statement: $ => prec.right(seq(
      'if',
      choice(
        seq(
          optional('constexpr'),
          field('condition', $.condition_clause),
          field('consequence', $.statement),
        ),
        // A macro that expands to the parenthesized condition:
        // `if Is_front_wheel(n)` under `#define Is_front_wheel(n) ((n) == WhF)`.
        prec.dynamic(-1, seq(
          field('condition', alias($._macro_loop_header, $.call_expression)),
          field('consequence', $.statement),
        )),
        // C++23: if consteval { … } / if !consteval { … }
        // (David Michael, 11d27b9 via arraypress/tree-sitter-cpp)
        seq(
          optional('!'),
          'consteval',
          field('consequence', $.compound_statement),
        ),
      ),
      optional(field('alternative', $.else_clause)),
    )),

    // Using prec(1) instead of prec.dynamic(1) causes issues with the
    // range loop's declaration specifiers if `int` is passed in, it'll
    // always prefer the standard for loop and give us a parse error.
    _for_statement_body: ($, original) => prec.dynamic(1, original),
    for_range_loop: $ => seq(
      'for',
      '(',
      $._for_range_loop_body,
      ')',
      field('body', $.statement),
    ),
    _for_range_loop_body: $ => seq(
      field('initializer', optional($.init_statement)),
      $._declaration_specifiers,
      field('declarator', $._declarator),
      ':',
      field('right', choice(
        $.expression,
        $.initializer_list,
      )),
    ),

    init_statement: $ => choice(
      $.alias_declaration,
      $.type_definition,
      $.declaration,
      $.expression_statement,
    ),

    condition_clause: $ => seq(
      '(',
      field('initializer', optional($.init_statement)),
      field('value', choice(
        $.expression,
        $.comma_expression,
        alias($.condition_declaration, $.declaration),
      )),
      ')',
    ),

    condition_declaration: $ => seq(
      $._declaration_specifiers,
      field('declarator', $._declarator),
      choice(
        seq(
          '=',
          field('value', $.expression),
        ),
        field('value', $.initializer_list),
      ),
    ),

    return_statement: ($, original) => seq(
      choice(
        original,
        seq('return', $.initializer_list, ';'),
      ),
    ),

    co_return_statement: $ => seq(
      'co_return',
      optional($.expression),
      ';',
    ),

    co_yield_statement: $ => seq(
      'co_yield',
      $.expression,
      ';',
    ),

    throw_statement: $ => seq(
      'throw',
      optional($.expression),
      ';',
    ),

    try_statement: $ => seq(
      'try',
      field('body', $.compound_statement),
      repeat1($.catch_clause),
    ),

    catch_clause: $ => seq(
      'catch',
      field('parameters', $.parameter_list),
      field('body', $.compound_statement),
    ),

    // Expressions

    // tree-sitter-c parses `static_assert(...)` as a C2Y expression; C++ keeps it a
    // declaration (static_assert_declaration), so drop the C expression form.
    _expression_not_binary: ($, original) => choice(
      ...original.members.filter((member) => member.name !== 'static_assert_expression'),
      $.co_await_expression,
      $.requires_expression,
      $.requires_clause,
      $.template_function,
      $.qualified_identifier,
      $.new_expression,
      $.delete_expression,
      $.lambda_expression,
      $.parameter_pack_expansion,
      $.pack_index_expression,
      $.this,
      $.user_defined_literal,
      $.fold_expression,
      $.reflect_expression,
      $.splice_expression,
    ),

    // From fork sln-jack/tree-sitter-cpp@3d35009 (Jack Foltz): prec.left so a
    // concatenated_string that may end in a macro identifier does not conflict.
    _string: $ => prec.left(choice(
      $.string_literal,
      $.raw_string_literal,
      $.concatenated_string,
    )),

    raw_string_literal: $ => seq(
      choice('R"', 'LR"', 'uR"', 'UR"', 'u8R"'),
      choice(
        seq(
          field('delimiter', $.raw_string_delimiter),
          '(',
          $.raw_string_content,
          ')',
          $.raw_string_delimiter,
        ),
        seq('(', $.raw_string_content, ')'),
      ),
      '"',
    ),

    subscript_expression: $ => prec(PREC.SUBSCRIPT, seq(
      field('argument', $.expression),
      field('indices', $.subscript_argument_list),
    )),

    subscript_argument_list: $ => seq(
      '[',
      commaSep(choice($.expression, $.initializer_list)),
      ']',
    ),

    call_expression: ($, original) => prec.dynamic(1, choice(original, seq(
      field('function', choice($.primitive_type, seq(
        optional('typename'),
        $.splice_type_specifier,
      ))),
      field('arguments', $.argument_list),
    ))),

    co_await_expression: $ => prec.left(PREC.UNARY, seq(
      field('operator', 'co_await'),
      field('argument', $.expression),
    )),

    new_expression: $ => prec.right(PREC.NEW, seq(
      optional('::'),
      'new',
      field('placement', optional($.argument_list)),
      choice(
        seq(
          field('type', $.type_specifier),
          field('declarator', optional($.new_declarator)),
        ),
        // new (T)(args): the type-id in parentheses
        seq('(', field('type', $.type_descriptor), ')'),
      ),
      field('arguments', optional(choice(
        $.argument_list,
        $.initializer_list,
      ))),
    )),

    new_declarator: $ => prec.right(seq(
      '[',
      field('length', $.expression),
      ']',
      optional($.new_declarator),
    )),

    delete_expression: $ => seq(
      optional('::'),
      'delete',
      optional(seq('[', ']')),
      $.expression,
    ),

    field_expression: $ => seq(
      prec(PREC.FIELD, seq(
        field('argument', $.expression),
        field('operator', choice('.', '.*', '->')),
      )),
      field('field', choice(
        prec.dynamic(1, $._field_identifier),
        alias($.qualified_field_identifier, $.qualified_identifier),
        $.destructor_name,
        $.template_method,
        alias($.dependent_field_identifier, $.dependent_name),
        $.operator_name,
        $.splice_expression,
      )),
    ),

    type_requirement: $ => seq('typename', $._class_name),

    compound_requirement: $ => seq(
      '{', $.expression, '}',
      optional('noexcept'),
      optional($.trailing_return_type),
      ';',
    ),

    _requirement: $ => choice(
      alias($.expression_statement, $.simple_requirement),
      $.type_requirement,
      $.compound_requirement,
    ),

    requirement_seq: $ => seq('{', repeat($._requirement), '}'),

    constraint_conjunction: $ => prec.left(PREC.LOGICAL_AND, seq(
      field('left', $._requirement_clause_constraint),
      field('operator', choice('&&', 'and')),
      field('right', $._requirement_clause_constraint)),
    ),

    constraint_disjunction: $ => prec.left(PREC.LOGICAL_OR, seq(
      field('left', $._requirement_clause_constraint),
      field('operator', choice('||', 'or')),
      field('right', $._requirement_clause_constraint)),
    ),

    _requirement_clause_constraint: $ => choice(
      // Primary expressions"
      $.true,
      $.false,
      $._class_name,
      $.fold_expression,
      $.lambda_expression,
      $.requires_expression,

      // Parenthesized expressions
      seq('(', $.expression, ')'),

      // conjunction or disjunction of the above
      $.constraint_conjunction,
      $.constraint_disjunction,
    ),

    requires_clause: $ => seq(
      'requires',
      field('constraint', $._requirement_clause_constraint),
    ),

    requires_parameter_list: $ => seq(
      '(',
      commaSep(choice(
        $.parameter_declaration,
        $.optional_parameter_declaration,
        $.variadic_parameter_declaration,
      )),
      ')',
    ),

    requires_expression: $ => seq(
      'requires',
      field('parameters', optional(alias($.requires_parameter_list, $.parameter_list))),
      field('requirements', $.requirement_seq),
    ),

    lambda_specifier: $ => choice(
      'static',
      'constexpr',
      'consteval',
      'mutable',
    ),

    lambda_declarator: $ => choice(
      // main declarator form, includes parameter list
      seq(
        repeat($.attribute_declaration),
        field('parameters', $.parameter_list),
        repeat($.lambda_specifier),
        optional($._function_exception_specification),
        repeat($.attribute_declaration),
        optional($.trailing_return_type),
        optional($.requires_clause),
      ),

      // forms supporting omitted parameter list
      repeat1($.attribute_declaration),
      seq(
        repeat($.attribute_declaration),
        $.trailing_return_type,
      ),
      seq(
        repeat($.attribute_declaration),
        $._function_exception_specification,
        repeat($.attribute_declaration),
        optional($.trailing_return_type),
      ),
      seq(
        repeat($.attribute_declaration),
        repeat1($.lambda_specifier),
        optional($._function_exception_specification),
        repeat($.attribute_declaration),
        optional($.trailing_return_type),
      ),
    ),

    lambda_expression: $ => seq(
      field('captures', $.lambda_capture_specifier),
      optional(seq(
        field('template_parameters', $.template_parameter_list),
        optional(field('constraint', $.requires_clause)),
      )),
      optional(field('declarator', $.lambda_declarator)),
      field('body', $.compound_statement),
    ),

    lambda_capture_specifier: $ => prec(PREC.LAMBDA, seq(
      '[',
      choice(
        $.lambda_default_capture,
        commaSep($._lambda_capture),
        seq(
          $.lambda_default_capture,
          ',', commaSep1($._lambda_capture),
        ),
      ),
      ']',
    )),

    lambda_default_capture: _ => choice('=', '&'),

    _lambda_capture_identifier: $ => seq(
      optional('&'),
      choice(
        $.identifier,
        $.qualified_identifier,
        alias($.identifier_parameter_pack_expansion, $.parameter_pack_expansion),
      ),
    ),

    lambda_capture_initializer: $ => seq(
      optional('&'),
      optional('...'),
      field('left', $.identifier),
      '=',
      field('right', $.expression),
    ),

    _lambda_capture: $ => choice(
      seq(optional('*'), $.this),
      $._lambda_capture_identifier,
      $.lambda_capture_initializer,
    ),

    _fold_operator: _ => choice(...FOLD_OPERATORS),
    _binary_fold_operator: _ => choice(...FOLD_OPERATORS.map((operator) => seq(field('operator', operator), '...', operator))),

    _unary_left_fold: $ => seq(
      field('left', '...'),
      field('operator', $._fold_operator),
      field('right', $.expression),
    ),
    _unary_right_fold: $ => seq(
      field('left', $.expression),
      field('operator', $._fold_operator),
      field('right', '...'),
    ),
    _binary_fold: $ => seq(
      field('left', $.expression),
      $._binary_fold_operator,
      field('right', $.expression),
    ),

    fold_expression: $ => seq(
      '(',
      choice(
        $._unary_right_fold,
        $._unary_left_fold,
        $._binary_fold,
      ),
      ')',
    ),

    parameter_pack_expansion: $ => prec(-1, seq(
      field('pattern', $.expression),
      '...',
    )),

    // C++26 pack indexing: Ts...[0], args...[i]
    // (David Michael, 11d27b9 via arraypress/tree-sitter-cpp)
    // `...[` is one token: before C++26 it could not appear, so it cannot be mistaken for a pack
    // expansion followed by a subscript.
    pack_index_expression: $ => seq(
      field('pack', $.identifier),
      alias(token(seq('...', /\s*/, '[')), '...['),
      field('index', $.expression),
      ']',
    ),

    type_parameter_pack_expansion: $ => seq(
      field('pattern', $.type_descriptor),
      '...',
    ),

    identifier_parameter_pack_expansion: $ => seq(
      field('pattern', $.identifier),
      '...',
    ),

    sizeof_expression: ($, original) => prec.right(PREC.SIZEOF, choice(
      original,
      seq(
        'sizeof', '...',
        '(',
        field('value', $.identifier),
        ')',
      ),
    )),

    unary_expression: ($, original) => choice(
      original,
      prec.left(PREC.UNARY, seq(
        field('operator', choice('not', 'compl')),
        field('argument', $.expression),
      )),
    ),

    binary_expression: ($, original) => {
      const table = [
        ['<=>', PREC.THREE_WAY],
        ['or', PREC.LOGICAL_OR],
        ['and', PREC.LOGICAL_AND],
        ['bitor', PREC.INCLUSIVE_OR],
        ['xor', PREC.EXCLUSIVE_OR],
        ['bitand', PREC.BITWISE_AND],
        ['not_eq', PREC.EQUAL],
        // pointer-to-member through a pointer: binds tighter than *, looser than unary
        // (David Michael, 11d27b9 via arraypress/tree-sitter-cpp)
        ['->*', PREC.MULTIPLY + 1],
      ];

      return choice(
        original,
        ...table.map(([operator, precedence]) => {
          return prec.left(precedence, seq(
            field('left', $.expression),
            // @ts-ignore
            field('operator', operator),
            field('right', $.expression),
          ));
        }));
    },

    // `Ts...[0];` at file scope is an expression statement: as a pack-index type it would
    // be a declaration that declares nothing.
    _top_level_expression_statement: ($, original) => prec(1, original),

    // `->*` shares PREC.CAST, so left associativity decides `(T)p->*m`: the cast
    // reduces first, as in C++ (casts bind tighter than pointer-to-member).
    cast_expression: ($, original) => prec.left(PREC.CAST, original.content),

    // The compound_statement is added to parse macros taking statements as arguments, e.g. MYFORLOOP(1, 10, i, { foo(i); bar(i); })
    argument_list: $ => seq(
      '(',
      commaSep(choice($.expression, $.initializer_list, $.compound_statement)),
      ')',
    ),

    // `a->~Baz<int>()` (Niclas, 223c16b via edge90/tree-sitter-cpp)
    // Right-associative: after `~Foo` a `<` can only open template arguments.
    destructor_name: $ => prec.right(1, seq('~', $.identifier, optional($.template_argument_list))),

    compound_literal_expression: ($, original) => choice(
      original,
      seq(
        field('type', choice(
          $._class_name,
          $.primitive_type,
          seq(optional('typename'), $.splice_type_specifier))),
        field('value', $.initializer_list),
      ),
    ),

    dependent_identifier: $ => seq('template', $.template_function),
    dependent_field_identifier: $ => seq('template', $.template_method),
    dependent_type_identifier: $ => seq('template', $.template_type),

    _scope_resolution: $ => prec(1, seq(
      field('scope', optional(choice(
        $._namespace_identifier,
        $.template_type,
        $.decltype,
        $.splice_expression,
        $.splice_type_specifier,
        alias($.dependent_type_identifier, $.dependent_name),
      ))),
      '::',
    )),

    qualified_field_identifier: $ => seq(
      $._scope_resolution,
      field('name', choice(
        alias($.dependent_field_identifier, $.dependent_name),
        alias($.qualified_field_identifier, $.qualified_identifier),
        $.template_method,
        // `p->A<int>::~A<int>()` (Niclas, 65697b7 via edge90/tree-sitter-cpp)
        $.destructor_name,
        prec.dynamic(2, $._field_identifier),
      )),
    ),

    qualified_identifier: $ => seq(
      $._scope_resolution,
      field('name', choice(
        alias($.dependent_identifier, $.dependent_name),
        $.qualified_identifier,
        $.template_function,
        prec.dynamic(1, seq(optional('template'), $.identifier)),
        $.operator_name,
        $.destructor_name,
        $.pointer_type_declarator,
      )),
    ),

    // (Andrea Boido, c17b0ec via Odiob/tree-sitter-cpp)
    abstract_qualified_identifier: $ => seq(
      $._scope_resolution,
      field('name', choice(
        alias($.abstract_qualified_identifier, $.qualified_identifier),
        $.abstract_pointer_declarator,
      )),
    ),

    qualified_type_identifier: $ => seq(
      $._scope_resolution,
      field('name', choice(
        alias($.dependent_type_identifier, $.dependent_name),
        alias($.qualified_type_identifier, $.qualified_identifier),
        $.template_type,
        prec.dynamic(1, $._type_identifier),
      )),
    ),

    qualified_operator_cast_identifier: $ => seq(
      $._scope_resolution,
      field('name', choice(
        alias($.qualified_operator_cast_identifier, $.qualified_identifier),
        $.operator_cast,
      )),
    ),

    _assignment_left_expression: ($, original) => choice(
      original,
      $.qualified_identifier,
      $.user_defined_literal,
    ),

    assignment_expression: $ => prec.right(PREC.ASSIGNMENT, seq(
      field('left', $._assignment_left_expression),
      field('operator', choice(...ASSIGNMENT_OPERATORS)),
      field('right', choice($.expression, $.initializer_list)),
    )),

    _assignment_expression_lhs: $ => seq(
      field('left', $.expression),
      field('operator', choice(...ASSIGNMENT_OPERATORS)),
      field('right', choice($.expression, $.initializer_list)),
    ),

    // This prevents an ambiguity between fold expressions
    // and assignment expressions within parentheses.
    parenthesized_expression: ($, original) => choice(
      original,
      seq('(', alias($._assignment_expression_lhs, $.assignment_expression), ')'),
    ),

    reflect_expression: $ => prec.right(seq(
      '^^',
      choice(
        '::',
        $.expression,
        $.type_descriptor,
      ),
    )),

    splice_specifier: $ => seq( '[:', $.expression, ':]'),
    _splice_specialization_specifier: $ => seq($.splice_specifier, $.template_argument_list),

    splice_type_specifier: $ => prec.right(choice(
      $.splice_specifier,
      $._splice_specialization_specifier,
    )),

    splice_expression: $ => prec.right(choice(
      $.splice_specifier,
      seq('template', $._splice_specialization_specifier),
    )),

    expansion_statement: $ => seq(
      'template', 'for',
      '(',
      $._for_range_loop_body,
      ')',
      field('body', $.statement),
    ),

    operator_name: $ => prec(1, seq(
      'operator',
      choice(
        'co_await',
        '+', '-', '*', '/', '%',
        '^', '&', '|', '~',
        '!', '=', '<', '>',
        '+=', '-=', '*=', '/=', '%=', '^=', '&=', '|=',
        '<<', '>>', '>>=', '<<=',
        '==', '!=', '<=', '>=',
        '<=>',
        '&&', '||',
        '++', '--',
        ',',
        '->*',
        '->',
        '()', '[]',
        'xor', 'bitand', 'bitor', 'compl',
        'not', 'xor_eq', 'and_eq', 'or_eq', 'not_eq',
        'and', 'or',
        seq(choice('new', 'delete'), optional('[]')),
        seq('""', $.identifier),
      ),
    )),

    this: _ => 'this',

    // From fork sln-jack/tree-sitter-cpp@3d35009 (Jack Foltz): a macro identifier
    // may follow the first string (`"x=%" PRIu64`), mirroring tree-sitter-c.
    concatenated_string: $ => prec.right(seq(
      choice(
        seq($.identifier, choice($.string_literal, $.raw_string_literal)),
        seq(choice($.string_literal, $.raw_string_literal), choice($.string_literal, $.raw_string_literal, $.identifier)),
      ),
      repeat(choice($.identifier, $.string_literal, $.raw_string_literal)),
    )),

    number_literal: $ => {
      const sign = /[-\+]/;
      const separator = '\'';
      const binary = /[01]/;
      const binaryDigits = seq(repeat1(binary), repeat(seq(separator, repeat1(binary))));
      const decimal = /[0-9]/;
      const firstDecimal = /[1-9]/;
      const intDecimalDigits = seq(firstDecimal, repeat(decimal), repeat(seq(separator, repeat1(decimal))));
      const floatDecimalDigits = seq(repeat1(decimal), repeat(seq(separator, repeat1(decimal))));
      const hex = /[0-9a-fA-F]/;
      const hexDigits = seq(repeat1(hex), repeat(seq(separator, repeat1(hex))));
      const octal = /[0-7]/;
      const octalDigits = seq('0', repeat(octal), repeat(seq(separator, repeat1(octal))));
      const hexExponent = seq(/[pP]/, optional(sign), floatDecimalDigits);
      const decimalExponent = seq(/[eE]/, optional(sign), floatDecimalDigits);
      const intSuffix = /(ll|LL)[uU]?|[uU](ll|LL)?|[uU][lL]?|[uU][zZ]?|[lL][uU]?|[zZ][uU]?/;
      const floatSuffix = /([fF](16|32|64|128)?)|[lL]|(bf16|BF16)/;

      return token(seq(
        optional(sign),
        choice(
          seq(
            choice(
              seq(choice('0b', '0B'), binaryDigits),
              intDecimalDigits,
              seq(choice('0x', '0X'), hexDigits),
              octalDigits,
            ),
            optional(intSuffix),
          ),
          seq(
            choice(
              seq(floatDecimalDigits, decimalExponent),
              seq(floatDecimalDigits, '.', optional(floatDecimalDigits), optional(decimalExponent)),
              seq('.', floatDecimalDigits, optional(decimalExponent)),
              seq(
                choice('0x', '0X'),
                choice(
                  hexDigits,
                  seq(hexDigits, '.', optional(hexDigits)),
                  seq('.', hexDigits)),
                hexExponent,
              ),
            ),
            optional(floatSuffix),
          ),
        ),
      ));
    },

    literal_suffix: _ => token.immediate(/[a-zA-Z_]\w*/),

    user_defined_literal: $ => seq(
      choice(
        $.number_literal,
        $.char_literal,
        $._string,
      ),
      $.literal_suffix,
    ),

    _namespace_identifier: $ => alias($.identifier, $.namespace_identifier),
  },
});
