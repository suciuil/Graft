#include <napi.h>

typedef struct TSLanguage TSLanguage;

extern "C" TSLanguage *tree_sitter_css_in_js();

// "tree-sitter", "language" hashed with BLAKE2 — the tag tree-sitter 0.21+ uses
// to validate a language object.
const napi_type_tag LANGUAGE_TYPE_TAG = {
    0x8AF2E5212AD58ABF, 0xD5006CAD83ABBA16
};

Napi::Object Init(Napi::Env env, Napi::Object exports) {
    exports["name"] = Napi::String::New(env, "css_in_js");
    auto language = Napi::External<TSLanguage>::New(env, tree_sitter_css_in_js());
    language.TypeTag(&LANGUAGE_TYPE_TAG);
    exports["language"] = language;
    return exports;
}

NODE_API_MODULE(tree_sitter_css_in_js_binding, Init)
