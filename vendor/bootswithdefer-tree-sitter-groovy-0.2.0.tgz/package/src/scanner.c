// External scanner for the few places where Groovy's spacing matters and the
// grammar alone cannot see it, because whitespace is an extra.
//
// _line_start_lt: a `<` that starts a line, where a new statement may begin.
// Groovy ends a statement at a line break, so such a `<` cannot continue the
// previous statement as a comparison: it opens the type parameters of a
// generic method with no modifier before them (`<T> T f(Closure<T> c)`). A
// `<` on the same line (`{ a < 0 }`), and `<<`, `<=` or `<=>` at the start of
// a line, are left to the grammar's own tokens.
//
// _call_lparen: a `(` right after the previous token, with no space between,
// where a call's arguments (or a method's parameters) may open. Groovy reads
// `f(x)` only as a call, never as a command call `f (x)` whose first argument
// is parenthesised, so in that place the `(` is lexed as this token and the
// parenthesised reading, which needs the grammar's own `(`, is not kept open.
// A `(` after a space is left to the grammar's own token, as before.
//
// _spaced_plus, _spaced_minus, _spaced_star: a binary `+`, `-` or `*` with a
// space on both sides and no line break before it. `a - b` is a subtraction,
// not a command call `a(-b)` with a signed argument (or `a(*b)` with a spread
// one), which needs the grammar's own operator token. `a -b`, `a-b` and an
// operator at the start of a line are left to the grammar's own tokens.
//
// _line_end: an empty token after a line break, where a statement may end,
// when the next line starts with a name, a number, a string or `(`. Groovy ends
// a statement at a line break, so that line is a new statement and not the first
// argument of a command call (`x = y` and then `f(x)` is not `x = y(f(x))`), nor
// the arguments or parameters of the name before it (`def b` and then
// `(a, b) = f()` is not a method `def b(a, b)`).
// Words that continue a statement on the next line (`else`, `catch`, `in`,
// ...) are left to the grammar.
//
// _error_sentinel: never part of a parse. During error recovery tree-sitter
// marks every token valid, and then none of the above is lexed.

#include "tree_sitter/parser.h"

#include <string.h>
#include <wctype.h>

enum TokenType {
  LINE_START_LT,
  CALL_LPAREN,
  SPACED_PLUS,
  SPACED_MINUS,
  SPACED_STAR,
  LINE_END,
  ERROR_SENTINEL,
};

// Words that may continue a statement on the next line.
static const char *const CONTINUATION_WORDS[] = {
  "as", "catch", "else", "extends", "finally", "implements", "in",
  "instanceof", "throws", "while",
};

void *tree_sitter_groovy_external_scanner_create(void) { return NULL; }

void tree_sitter_groovy_external_scanner_destroy(void *payload) { (void)payload; }

unsigned tree_sitter_groovy_external_scanner_serialize(void *payload, char *buffer) {
  (void)payload;
  (void)buffer;
  return 0;
}

void tree_sitter_groovy_external_scanner_deserialize(void *payload, const char *buffer, unsigned length) {
  (void)payload;
  (void)buffer;
  (void)length;
}

static bool is_blank(int32_t c) { return c == ' ' || c == '\t'; }

static bool scan_spaced_operator(TSLexer *lexer, const bool *valid_symbols) {
  enum TokenType symbol;
  switch (lexer->lookahead) {
    case '+': symbol = SPACED_PLUS; break;
    case '-': symbol = SPACED_MINUS; break;
    case '*': symbol = SPACED_STAR; break;
    default: return false;
  }
  if (!valid_symbols[symbol]) return false;
  lexer->advance(lexer, false);
  if (!is_blank(lexer->lookahead)) return false;
  lexer->result_symbol = symbol;
  return true;
}

static bool is_word_start(int32_t c) {
  return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_' || c == '$' ||
         (c >= 0x80 && iswalpha(c));
}

static bool is_word_char(int32_t c) { return is_word_start(c) || (c >= '0' && c <= '9'); }

// An empty token before the first character of the next line.
static bool scan_line_end(TSLexer *lexer) {
  lexer->mark_end(lexer);
  lexer->result_symbol = LINE_END;
  int32_t c = lexer->lookahead;
  if ((c >= '0' && c <= '9') || c == '\'' || c == '"' || c == '(') return true;
  if (!is_word_start(c)) return false;

  char word[16];
  unsigned length = 0;
  while (is_word_char(lexer->lookahead)) {
    if (length >= sizeof(word) - 1) return true;  // longer than every continuation word
    word[length++] = (char)lexer->lookahead;
    lexer->advance(lexer, false);
  }
  word[length] = '\0';
  for (unsigned i = 0; i < sizeof(CONTINUATION_WORDS) / sizeof(CONTINUATION_WORDS[0]); i++) {
    if (strcmp(word, CONTINUATION_WORDS[i]) == 0) return false;
  }
  return true;
}

bool tree_sitter_groovy_external_scanner_scan(void *payload, TSLexer *lexer, const bool *valid_symbols) {
  (void)payload;
  if (valid_symbols[ERROR_SENTINEL]) return false;

  if (valid_symbols[CALL_LPAREN] && lexer->lookahead == '(') {
    lexer->advance(lexer, false);
    lexer->result_symbol = CALL_LPAREN;
    return true;
  }

  bool spaced = valid_symbols[SPACED_PLUS] || valid_symbols[SPACED_MINUS] || valid_symbols[SPACED_STAR];
  if (!valid_symbols[LINE_START_LT] && !valid_symbols[LINE_END] && !spaced) return false;

  bool blank = false;
  bool line_break = false;
  while (iswspace(lexer->lookahead)) {
    if (lexer->lookahead == '\n') line_break = true;
    else if (is_blank(lexer->lookahead)) blank = true;
    lexer->advance(lexer, true);
  }

  if (line_break) {
    if (lexer->lookahead != '<') return valid_symbols[LINE_END] && scan_line_end(lexer);
    if (!valid_symbols[LINE_START_LT]) return false;
    lexer->advance(lexer, false);
    if (lexer->lookahead == '<' || lexer->lookahead == '=') return false;
    lexer->result_symbol = LINE_START_LT;
    return true;
  }

  return blank && scan_spaced_operator(lexer, valid_symbols);
}
