const PREC = {
  DEFAULT: 1,
  PRIORITY: 2,
  ELVIS: 3, // ?:
  OR: 4, // ||
  AND: 5, // &&
  BIN_OR: 6, // |
  BIN_XOR: 7, // ^
  BIN_AND: 8, // &
  COMPARE_EQ: 9, // == != <=> === !== =~ ==~
  COMPARE: 10, // < <= > >= in !in instanceof !instanceof as
  SHIFT: 11, // << >> >>> .. ..< <..< <..
  PLUS: 12, // + -
  STAR: 13, // * / %
  UNARY: 14, // +x -x ++x --x
  POW: 15, // **
  TOP: 16, // new () [] {} . .& .@ ?. * *. *: ~ ! (type) x[y] ++ --
  STATEMENT: 17
}

const regexp_or = (regexes) => new RegExp(regexes.map(r =>'(?:('+r.source+'))').join('|'))

const VARIABLE_REGEX = /[$_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u00F8\u0100-\uFFFE][$_0-9a-zA-Z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u00F8\u0100-\uFFFE]*/
const CONSTANT_REGEX = /[_A-Z][$_0-9A-Z]*/
const IDENTIFIER_REGEX = regexp_or([VARIABLE_REGEX, CONSTANT_REGEX])
const TYPE_REGEX =  /[A-Z][$_0-9a-zA-Z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u00F8\u0100-\uFFFE]*/

const list_of = (e) => seq(
  repeat(prec.left(seq(e, ','))),
  seq(e, optional(',')),
)

// An argument of a call without parentheses (`foo a, b`).
const juxt_argument = ($) => choice(
  $.map_item,
  $.increment_op,
  $.binary_op,
  $.ternary_op,
  $.unary_op,
  $.access_op,
  $.closure,
  alias("null", $.null),
  $.number_literal,
  $.boolean_literal,
  $.string,
  $.list,
  $.map,
  "this",
  $.function_call,
  $.dotted_identifier,
  $.identifier,
  // A class: Spock's `thrown Exception`. Groovy ends a statement at a line
  // break, so with the next line `archive.isEmpty()` this is not the
  // statement `thrown` and a declaration `Exception archive`.
  $._type_identifier,
  $.index,
)

// A binary operator. `+`, `-` and `*` with a space on both sides, on one line,
// are lexed as the external tokens of src/scanner.c: `a - b` is a subtraction,
// not a command call `a(-b)` (or `a(*b)`) whose argument is a sign or a spread.
// `a -b` is left to the grammar's own tokens.
const SPACED_BINARY_OPERATORS = {
  '+': '_spaced_plus',
  '-': '_spaced_minus',
  '*': '_spaced_star',
};
const binary_operator = ($, operator) => SPACED_BINARY_OPERATORS[operator]
  ? choice(operator, alias($[SPACED_BINARY_OPERATORS[operator]], operator))
  : operator;

// A list of statements. A statement may end at `_line_end` (src/scanner.c), a
// line break before a name, a number, a string or `(` that starts the next line:
// Groovy ends a statement there, so `x = y` and a next line `f(x)` are two
// statements, not the command call `y f(x)`. On one line `y f(x)` stays a
// command call.
const statements = ($, ...others) => repeat(seq(
  others.length ? choice($._statement, ...others) : $._statement,
  optional($._line_end),
));

// What follows the first name of a declaration: its value and more names
// (`_more_declarators`). Before more names the value is a primary expression,
// so in `def r = f a: 1, b: 2` the commas continue the call `f`. Its
// precedence ties with a closure parameter's value (`{ String a = '', b ->`).
const first_declarator_rest = ($, valueRequired) => {
  const value = seq('=', field('value', $._expression));
  const primaryValue = seq('=', field('value', $._primary_expression));
  const more = prec(1, seq(valueRequired ? primaryValue : optional(primaryValue), $._more_declarators));
  return valueRequired ? choice(value, more) : optional(choice(value, more));
};

// The modifiers of a method. The access modifier may also come after the
// others: `static protected void f()`, `static private g() {}`.
const method_modifiers = ($) => choice(
  seq($.access_modifier, repeat($.modifier)),
  seq(repeat1($.modifier), optional(seq($.access_modifier, repeat($.modifier)))),
);

module.exports = grammar({
  name: 'groovy',

  extras: $ => [/\s/, /\\\r?\n/, $.comment, $.groovy_doc],

  word: $ => $.identifier,

  // See src/scanner.c.
  externals: $ => [
    $._line_start_lt,
    $._call_lparen,
    $._spaced_plus,
    $._spaced_minus,
    $._spaced_star,
    $._line_end,
    $._error_sentinel,
  ],

  inline: $ => [$._typed_method_head, $._untyped_method_head, $._call_open],

  conflicts: $ => [ //TODO: dynamic precedence, heuristics? eg capital letter
    [$._callable_expression, $.juxt_function_call],
    [$._callable_expression, $._juxt_argument_list],
    [$._juxtable_expression, $._juxt_argument_list],
    [$._juxtable_expression, $.qualified_type],
    [$.dotted_identifier, $.qualified_type],
    [$._juxt_argument_list, $.map_item],
    // `(x)`: also the type of a cast `(T) object`.
    [$.destructuring_declaration, $._juxtable_expression, $._parameter_body],
    // `URL url`: an all-capitals parameter type or a command call (see
    // _parameter_body).
    [$._juxtable_expression, $._parameter_body],
    // `E get(String m)`: an all-capitals return type or a command call (see
    // function_declaration).
    [$._juxtable_expression, $.function_declaration],
    [$._juxtable_expression, $._parameter_body, $.function_declaration],
    // `(T) object` or `(x)` ending a statement before the next one: see cast.
    [$.cast, $._callable_expression],
    [$._expression, $._map_value],
    // `x.c { .. }`: a closure-only call (from fork zgsolucoes/tree-sitter-groovy@265566d)
    // or a juxt call with a closure argument.
    // Both are kept so a map value (`[a: x.c { .. }, b: 1]`), where juxt calls
    // are not allowed, still parses; the dynamic precedence prefers juxt.
    [$.function_call, $._juxt_argument_list],
    [$._expression, $.function_call, $._juxt_argument_list],
    // `Foo(x) { }`: constructor or call with a trailing closure (see function_definition).
    [$.argument_list, $.parameter_list],
    [$._constructor_definition, $._type],
    // `Foo(1)`: a call of a capitalised name, a constructor or a declaration.
    [$._callable_expression, $.function_call, $._constructor_definition, $._type],
    [$._callable_expression, $.function_call, $._type],
    // `synchronized (x)`: a synchronized block or a declaration `synchronized (a, b) = ..`.
    [$.modifier, $.synchronized_statement],
    // `{ def a, b`: a declaration of two names or two closure parameters.
    // `{ final T x` with an all-capitals type: a field or a closure parameter.
    [$.declaration, $._parameter_body],
    // `{ String a = '', b`: the value of a declaration or of a parameter.
    [$._expression, $._parameter_body],
    // The value of a declaration's first name, before more names (`first_declarator_rest`).
    [$.declaration, $._expression],
  ],

  rules: {
    source_file: $ => seq(
      optional($.shebang),
      statements($, $.pipeline),
    ),

    shebang: $ => seq(
      '#!', /[^\n]*/
    ),

    _statement: $ => prec.left(PREC.STATEMENT, seq(
      // Several labels in a row: an empty Spock block (`given:` right before `expect:`).
      repeat($.label),
      choice(
        $.assertion,
        $.groovy_import,
        $.groovy_package,
        $.assignment,
        $.class_definition,
        $.declaration,
        $.do_while_loop,
        $.for_in_loop,
        $.for_loop,
        $.function_call,
        $.function_declaration,
        $.function_definition,
        alias($._constructor_definition, $.function_definition),
        $.if_statement,
        $.juxt_function_call,
        // $.pipeline_step_with_block,
        $.return,
        $.switch_statement,
        $.synchronized_statement,
        $.try_statement,
        $.while_loop,
        // A block is not a statement of its own after a call: see `_expression`.
        prec.dynamic(-1, $.closure),
        $.static_initializer,
        alias("break", $.break),
        alias("continue", $.continue),
        $._expression,
        // $.step,
      ),
      optional(';')
    )),

    // From fork zgsolucoes/tree-sitter-groovy@265566d (Henrique Mota): a class
    // `static { ... }` initializer block.
    static_initializer: $ => seq('static', field('body', $.closure)),

    label: $ => seq(field('name', $.identifier), ":"),

    access_op: ($) =>
      choice(
        ...[
          [".&", PREC.TOP],
          [".@", PREC.TOP],
          ["?.", PREC.TOP],
          ["*.", PREC.TOP],
        ].map(([operator, precedence]) =>
          prec.left(precedence, seq($._expression, operator, $._expression))
        ),
        ...[
          ["*", PREC.TOP],
        ].map(([operator, precedence]) =>
          prec.left(precedence, seq(operator, $._expression))
        ),
      ),

    dotted_identifier: $ => {
      const members = repeat1(seq(
        '.',
        optional($.generics),
        choice(
          $.identifier,
          $.quoted_identifier,
          $._type_identifier,
          $.parenthesized_expression,
          // A class literal: `synchronized (Foo.class) { }`, `Foo.class.name`.
          alias('class', $.identifier),
        )));
      return choice(
        prec.left(1, seq(choice($._primary_expression, $._type_identifier), members)),
        // A bare closure as the receiver (`{ it }.call()`). Below the closure-only
        // call of function_call (static and dynamic), so `xs.collect { it }.join()`
        // chains instead of splitting into `xs.collect` and `{ it }.join()`.
        prec.left(0, prec.dynamic(-2, seq($.closure, members))),
      );
    },

    _import_name: $ => choice(
      $.identifier,
      $._type_identifier,
      seq($._import_name, '.', choice($.identifier, $._type_identifier)),
    ),

    groovy_import: $ => seq(
      'import',
      optional($.modifier),
      field('import', alias($._import_name, $.qualified_name)),
      optional(
        choice(
          seq('.', alias(token.immediate('*'), $.wildcard_import)),
          seq('as', field('import_alias', choice($.identifier, $._type_identifier))),
        ),
      )
    ),

    groovy_package: $ => seq('package', alias($._import_name, $.qualified_name)),

    annotation: $ => prec.right(seq(
      '@',
      alias(token.immediate(regexp_or([IDENTIFIER_REGEX, TYPE_REGEX])), $.identifier),
      repeat(seq('.', alias(token.immediate(regexp_or([IDENTIFIER_REGEX, TYPE_REGEX])), $.identifier))),
      optional($.annotation_arguments),
    )),

    annotation_arguments: $ => seq(
      '(',
      optional(list_of(choice($.annotation_member, $._annotation_value))),
      ')',
    ),

    annotation_member: $ => seq(
      field('name', $.identifier),
      '=',
      field('value', $._annotation_value),
    ),

    // From fork zgsolucoes/tree-sitter-groovy@0b4481f (Henrique Mota): nested
    // annotations as values (`schema = @Schema(..)`, `content = [@Content(..)]`,
    // `@ApiResponses([@ApiResponse(..), ..])`).
    _annotation_value: $ => choice(
      $._expression,
      $.annotation,
      alias($._annotation_value_list, $.list),
    ),

    _annotation_value_list: $ => seq('[', list_of($.annotation), ']'),

    assertion: $ => prec.right(seq('assert', $._expression, optional(seq(choice(',', ':'), $._expression)))),

    assignment: $ => prec(-1, choice( //??? is -1 ok here? (fixes conflict with expression for ++)
      prec.right(seq(
        choice($._juxtable_expression, $._type_identifier, $.parenthesized_expression, $.destructuring_declaration, $.access_op),
        choice('=', '**=', '*=', '/=', '%=', '+=', '-=',
          '<<=', '>>=', '>>>=', '&=', '^=', '|=', '?='),
        // The value may be another assignment: `a = b = c` sets both to `c`.
        choice($._expression, alias($._chained_assignment, $.assignment)),
      )),
      $.increment_op,
    )),

    // An assignment as the value of another one (`a = b = c`). Its target is a
    // name, a property or an index only: after `=`, `(String a, String b) -> {}`
    // is a lambda, not a destructuring assignment.
    _chained_assignment: $ => prec.right(seq(
      choice($._juxtable_expression, $.access_op),
      choice('=', '**=', '*=', '/=', '%=', '+=', '-=',
        '<<=', '>>=', '>>>=', '&=', '^=', '|=', '?='),
      choice($._expression, alias($._chained_assignment, $.assignment)),
    )),

    increment_op: $ => prec(2, choice(
      prec.left(PREC.UNARY, seq($._primary_expression, "++")),
      prec.left(PREC.UNARY, seq($._primary_expression, "--")),
      prec.right(PREC.UNARY, seq("++", $._primary_expression)),
      prec.right(PREC.UNARY, seq("--", $._primary_expression)),
    )),

    binary_op: ($) =>
      choice(
        ...[
          ["%", PREC.STAR],
          ["*", PREC.STAR],
          ["/", PREC.STAR],
          ["+", PREC.PLUS],
          ["-", PREC.PLUS],
          ["<<", PREC.SHIFT],
          [">>", PREC.SHIFT],
          [">>>", PREC.SHIFT],
          ["..", PREC.SHIFT],
          ["..<", PREC.SHIFT],
          ["<..<", PREC.SHIFT],
          ["<..", PREC.SHIFT],
          ["<", PREC.COMPARE],
          ["<=", PREC.COMPARE],
          [">", PREC.COMPARE],
          [">=", PREC.COMPARE],
          ["in", PREC.COMPARE],
          ["!in", PREC.COMPARE],
          ["==", PREC.COMPARE_EQ],
          ["!=", PREC.COMPARE_EQ],
          ["<=>", PREC.COMPARE_EQ],
          ["===", PREC.COMPARE_EQ],
          ["!==", PREC.COMPARE_EQ],
          ["=~", PREC.COMPARE_EQ],
          ["==~", PREC.COMPARE_EQ],
          ["&", PREC.BIN_AND],
          ["^", PREC.BIN_XOR],
          ["|", PREC.BIN_OR],
          ["&&", PREC.AND],
          ["||", PREC.OR],
          ["?:", PREC.ELVIS],
        ].map(([operator, precedence]) =>
          prec.left(precedence, seq($._expression, binary_operator($, operator), $._expression))
        ),
        prec.right(PREC.POW, seq($._expression, "**", $._expression)),
        // The right side of `instanceof` is a type, so it may be generic
        // (`x instanceof Optional<String>`) or an all-capitals name.
        prec.left(PREC.COMPARE, seq($._expression, choice('instanceof', '!instanceof'), choice($._type, $.identifier))),
      ),

    boolean_literal: $ => choice('true', 'false'),

    class_definition: $ => seq(
      repeat($.annotation),
      optional($.access_modifier),
      repeat($.modifier),
      choice(
        seq(
          // From fork Vokturz/tree-sitter-groovy@81accd0 (Vokturz): `trait`
          // declarations (folded into class_definition instead of a new node).
          choice('@interface', 'interface', 'class', 'trait'),
          field('name', choice($.identifier, $._type_identifier)),
          optional(field('generics', $.generic_parameters)),
          optional(seq(
            'extends',
            // From fork zgsolucoes/tree-sitter-groovy@4e52150 (Henrique Mota): a
            // generic superclass (`extends Base<T>`) and an interface extending
            // several interfaces (`interface A extends B, C`).
            field('superclass', $._class_type),
            repeat(seq(',', field('superclass', $._class_type))),
          )),
          optional($._implements),
          field('body', $.closure),
        ),
        // From fork Alexandoooor/tree-sitter-groovy@a868b30, @d446ea1 (Alexander
        // Magnusson): enum definitions with constants, constructors and members.
        // Kept a `class_definition` (keyword `enum`, body an `enum_body`) so
        // consumers that index classes see enums too.
        seq(
          'enum',
          field('name', choice($.identifier, $._type_identifier)),
          optional($._implements),
          field('body', $.enum_body),
        ),
      ),
    ),

    _implements: $ => seq(
      'implements',
      list_of(field('interface', choice($._type, $.identifier))),
    ),

    // A type, not an expression: in `class B extends C {` the body is not a closure
    // argument of a call `C { }`.
    _class_type: $ => choice($._type, $.identifier),

    enum_body: $ => seq(
      '{',
      optional(seq(
        list_of($.enum_constant),
        optional(';'),
      )),
      statements($),
      '}',
    ),

    enum_constant: $ => prec.right(3, seq(
      repeat($.annotation),
      field('name', choice($.identifier, $._type_identifier)),
      optional($.argument_list),
    )),

    generic_parameters: $ => seq(
      '<',
      list_of($.generic_param),
      '>'
    ),

    generic_param: $ => seq(
      field('name', $.identifier),
      optional(seq(
        'extends',
        // An all-capitals bound lexes as an identifier: `class B<T extends B>`,
        // `class B<T extends B<T>>`.
        field('superclass', choice($._type, $.identifier, $._capitals_generic_type)),
      ))
    ),

    closure: $ => seq(
      '{',
      optional(choice(
        // Preferred to a declaration followed by a lambda: `{ String a, int b -> a }`
        // also reads as `String a, int` (a keyword is a name where only a name fits)
        // and `b -> a`.
        prec.dynamic(2, seq(alias($._param_list, $.parameter_list), "->")),
        '->',
      )),
      statements($),
      optional($._expression),
      '}',
    ),

    comment: $ => choice(
      /\/\/[^\n]*/,
      // From fork Tijs-B/tree-sitter-groovy@5934d1e (Tijs-B): a stars-only block
      // comment (`/*****/`) is a plain comment, not a groovydoc. The precedence
      // beats the equally long `groovy_doc` token.
      token(prec(1, /\/\*\*+\//)),
      seq('/*', /[^*]*\*+([^/*][^*]*\*+)*\//), // not sure why comments work better as seq
    ),

    // Groovydoc / block comment starting with /**. Matched as a single
    // token (robust for any content); the formatter treats it verbatim.
    groovy_doc: $ => token(seq('/**', /[^*]*\*+([^/*][^*]*\*+)*\//)),

    // Right associative: in a for loop's update part (`; i++, j--)`), a comma
    // after a declaration adds a name to it rather than starting a statement.
    // The precedence ties with a closure parameter, so `{ String a = '', b ->`
    // keeps both readings until the arrow.
    declaration: $ => prec.right(-1, choice(seq(
      repeat($.annotation),
      optional($.access_modifier),
      choice(
        seq(
          repeat($.modifier),
          choice(
            seq(
              choice(field('type', $._type), 'def'),
              choice(
                seq(
                  // A capitalised name after a type (`String RteTask`).
                  field('name', choice($.identifier, $._type_identifier)),
                  first_declarator_rest($, false),
                ),
                seq(
                  field('name', $.destructuring_declaration),
                  optional(seq('=', field('value', $._expression))),
                ),
              ),
            ),
          )
        ),
        seq(
          repeat1($.modifier),
          // The access modifier may also come after the others: `final private Map<K, V> m`.
          optional(seq($.access_modifier, repeat($.modifier))),
          choice(
            seq(
              choice(
                // Only after a type can a capitalised name not be a constructor.
                seq(choice(field('type', $._type), 'def'), field('name', $._type_identifier)),
                seq(
                  optional(choice(field('type', $._type), 'def')),
                  choice(
                    field('name', $.identifier),
                    field('name', $.destructuring_declaration),
                  ),
                ),
              ),
              first_declarator_rest($, false),
            ),
            // An untyped capitalised name with a value: `static final RootFolder = 'x'`.
            // (Without the value, `static Foo(..)` is a constructor and
            // `static Foo bar` a declaration of type `Foo`.)
            seq(
              field('name', $._type_identifier),
              first_declarator_rest($, true),
            ),
          )
        ),
      ),
    ),
    // `def` before the modifiers, in any order: `def static final NAME = 'x'`,
    // `def final static x`, `def static String url = 'none'`. (A method may
    // start the same way: see `_typed_method_head`.)
    seq(
      repeat($.annotation),
      'def',
      repeat1(choice($.access_modifier, $.modifier)),
      optional(field('type', $._type)),
      field('name', choice($.identifier, $._type_identifier)),
      first_declarator_rest($, false),
    ),
    // An all-capitals type, which lexes as an identifier, after a modifier or
    // an annotation: `private URI uri`, `private final T value`, `@Field URI x`.
    // (Without one, `URI uri` is a command call of `URI`.) The precedence makes
    // `private URI uri` one declaration rather than the untyped field
    // `private URI` followed by the statement `uri`.
    prec(1, prec.dynamic(1, seq(
      choice(
        seq(repeat($.annotation), $.access_modifier, repeat($.modifier)),
        seq(repeat($.annotation), repeat1($.modifier)),
        repeat1($.annotation),
      ),
      field('type', $.identifier),
      field('name', choice($.identifier, $._type_identifier)),
      optional(seq('=', field('value', $._expression))),
    ))),
    // No type after an access modifier alone: `private x = 1`. (After another
    // modifier, `private static x = 1`, see above.)
    seq(
      repeat($.annotation),
      $.access_modifier,
      field('name', $.identifier),
      optional(seq('=', field('value', $._expression))),
    ),
    // A name alone after annotations: the `_` of Jenkins' `@Library('lib') _`.
    // `_` was a keyword for this, which made it no name wherever a statement
    // may start, so `{ _ -> }`, `{ _, b -> }` and `_.foo()` failed to parse.
    // Annotations count as modifiers, so the type may be left out before a
    // value too: `@Field x = 1`.
    seq(
      repeat1($.annotation),
      field('name', $.identifier),
      optional(seq('=', field('value', $._expression))),
    ))),

    // More names after the first one of a declaration, each with an optional
    // value: `def a, b`, `String x, y = 'z'`, `int i = 0, j = n`.
    _more_declarators: $ => repeat1(prec.left(seq(
      ',',
      field('name', $.identifier),
      optional(seq('=', field('value', $._expression))),
    ))),

    // Groovy allows a type per name in a destructuring target, so both
    // `def (a, b) = list` and `def (List diffs, Boolean ok) = f()` are valid.
    // The type is optional per element rather than all-or-nothing; a `type`
    // child always immediately precedes the identifier it belongs to, so
    // ordered traversal pairs them exactly even when only some are typed.
    destructuring_declaration: $ => seq(
      '(',
      optional(field('type', $._type)),
      $.identifier,
      repeat(seq(',', optional(field('type', $._type)), $.identifier)),
      ')',
    ),

    parenthesized_expression: ($) =>
      prec(PREC.PRIORITY, choice(
        seq("(",
          // An assignment in parentheses: `while ((line = r.readLine()) != null)`.
          choice(
            $._expression,
            $._immediately_invoked_closure,
            $.assignment,
            alias($._call_then_property, $.juxt_function_call),
          ),
          ")"),
      )),

    // A command chain ending in a property, after a call: `(parent.get() isComposite)`
    // is `parent.get().isComposite`. Only inside parentheses, where a line break
    // cannot end a statement and so cannot be read as one. It reads as a command
    // call, like `(a.b c)`.
    _call_then_property: $ => seq(
      field('function', $.function_call),
      field('args', alias($._command_property, $.argument_list)),
    ),

    _command_property: $ => $.identifier,

    _expression: $ => prec(1, choice(
      $._primary_expression,
      $.increment_op,
      $.binary_op,
      $.ternary_op,
      $.unary_op,
      $.access_op,
      // Below a closure-only call or a juxt call: `stages { .. }` is not the
      // statement `stages` followed by a closure (see conflicts).
      prec.dynamic(-1, $.closure),
      $.juxt_function_call,
      $.cast,
      $.lambda_expression,
      $.method_reference,
      $.as_op,
      alias("null", $.null),
    )),

    // Java-style method reference: `String::toUpperCase`, `obj::method`, `Foo::new`.
    method_reference: $ => prec.left(PREC.TOP, seq(
      choice($._primary_expression, $._type_identifier),
      '::',
      choice($.identifier, 'new'),
    )),

    // `x as Map<String, Object>`. The right-hand side is a TYPE, not an expression,
    // which is exactly why modelling `as` as a binary operator could not parse a
    // generic target: `Map<String, Object>` never reduces to an expression.
    as_op: $ => prec.left(PREC.COMPARE, seq(
      field('value', $._expression),
      'as',
      // An all-capitals type (`x as AUTOSAR`) lexes as an identifier.
      field('type', choice($._type, $.identifier)),
    )),

    // Lambdas in either Groovy 3 spelling: bare `x -> expr` and parenthesized
    // `(a, b) -> expr` / `() -> { ... }`. Neither collides with a closure's own
    // parameter list, which is always inside braces (`{ a -> }`). The low
    // precedence keeps a closure the preferred reading wherever both could match.
    lambda_expression: $ => prec.right(-2, seq(
      field('parameters', choice($.identifier, seq('(', optional($._param_list), ')'))),
      '->',
      field('body', choice($._expression, $.closure)),
    )),

    // Type cast: (Type) expression
    cast: $ => choice(
      prec.right(PREC.UNARY, seq(
        '(',
        field('type', $._type),
        ')',
        field('value', $._expression),
      )),
      // A cast to an all-capitals type, such as a type parameter: `(T) object`.
      // The type lexes as an identifier, so it is read as a parenthesised
      // expression first and becomes a cast type only when a name follows the
      // `)`: a separate `(T)` rule would keep two readings of every `(x)` open.
      // `(a / b)` ending a statement before one that starts with a name is not
      // a cast: both readings are kept (see conflicts) and the cast loses ties.
      prec.dynamic(-1, seq(
        field('type', alias($.parenthesized_expression, $.parenthesized_type)),
        field('value', $.identifier),
      )),
    ),

    // Like _expression but without juxt_function_call to prevent
    // greedy cross-line consumption in map_item values
    _map_value: $ => prec(1, choice(
      $._primary_expression,
      $.increment_op,
      $.binary_op,
      $.ternary_op,
      $.unary_op,
      $.access_op,
      $.closure,
      $.cast,
      $.method_reference,
      $.as_op,
      alias("null", $.null),
    )),

    _primary_expression: $ => prec.left(1, choice(
      $.number_literal,
      $.boolean_literal,
      $.string,
      $.list,
      $.map,
      $.object_creation,
      $._callable_expression,
      // A built-in type is a value in Groovy (`int.class`); `{ void }` is a
      // stub closure in tests. Lowest precedence: before a name, `void` is a
      // return type (`void f() {}`).
      prec(-10, alias('void', $.builtintype)),
    )),

    _callable_expression: $ => choice(
      "this",
      $.function_call,
      $.parenthesized_expression,
      $._juxtable_expression,
      $._type_identifier,
    ),

    _juxtable_expression: $ => choice(
      $.dotted_identifier,
      $.identifier,
      $.index,
    ),

    do_while_loop: $ => seq(
      'do',
      field('body', choice(
        $._statement,
        $.closure
      )),
      'while',
      field('condition', $.parenthesized_expression),
    ),

    for_parameters: $ => seq (
      '(',
      // A declaration (`int i = 0, j = n`, see `_more_declarators`) or
      // assignments to existing variables (`i = n - 1, j = 0`).
      field('initializer', optional(choice(
        $.declaration,
        seq($.assignment, repeat(seq(',', $.assignment))),
      ))),
      ';',
      field('condition', optional($._expression)),
      ';',
      field('increment', optional(seq(
        $._statement,
        repeat(seq(',', $._statement))
      ))),
      ')',
    ),
    for_loop: $ => seq(
      'for',
      $.for_parameters,
      field('body', choice(
        $._statement,
        $.closure
      )),
    ),

    for_in_loop: $ => prec(1, seq(
      'for',
      '(',
      // From fork zgsolucoes/tree-sitter-groovy@265566d (Henrique Mota):
      // `for (final Result r in rs)`.
      repeat($.modifier),
      // An all-capitals type lexes as an identifier: `for (V v : vs)`, `for (URI u in us)`.
      optional(field('type', choice($._type, 'def', $.identifier))),
      field('variable', $.identifier),
      choice('in', ':'),
      field('collection', $._expression),
      ')',
      field('body', choice(
        $._statement,
        $.closure
      )),
    )),

    function_call: $ => choice(
      prec.left(2, seq( //higher precedence than juxt_function_call
        field('function', $._callable_expression),
        field('args', $.argument_list),
      )),
      // A capitalised name called as a statement (`Foo(1)`, Spock's
      // `GroovySpy(Parser, global: true)`). The precedence ties with
      // `_constructor_definition` and `_type` so the parser keeps the call
      // reading open next to theirs (see conflicts).
      prec(2, seq(
        field('function', $._type_identifier),
        field('args', $.argument_list),
      )),
      // A method reference called at once: `Integer::parseInt(s, 16)`.
      prec.left(2, seq(
        field('function', $.method_reference),
        field('args', $.argument_list),
      )),
      // From fork zgsolucoes/tree-sitter-groovy@265566d (Henrique Mota): a method
      // named by a string literal (Grails UrlMappings DSL), e.g.
      // `get '/api/x'(controller: 'c')` and `"/$controller/$action?" { }`.
      prec.left(2, seq(
        field('function', alias($._quoted_string, $.string)),
        field('args', choice($.argument_list, alias($.closure, $.argument_list))),
      )),
      // From fork zgsolucoes/tree-sitter-groovy@265566d (Henrique Mota): a
      // closure-only call that a member access follows, `xs.collect { .. }.join()`.
      // The negative dynamic precedence keeps the juxt reading everywhere else.
      // Left associativity reduces the call before a `.` instead of reading
      // `{ .. }.join()` as a closure receiver inside a juxt argument.
      prec.left(2, prec.dynamic(-1, seq(
        field('function', $._juxtable_expression),
        field('args', alias($.closure, $.argument_list)),
      ))),
    ),

    __immediately_invoked_closure: $ => prec.left(2,
      seq(field('function', $.closure), field('args', $.argument_list))
    ),
    _immediately_invoked_closure: $ => alias(
      $.__immediately_invoked_closure,
      $.function_call,
    ),

    argument_list: $ => prec.right(1, seq(
      prec.left(seq(
        $._call_open,
        optional(
          list_of(choice(
            $.named_argument,
            $.map_item,
            $._expression,
            alias($._compound_assignment, $.assignment),
            // A class with type arguments: `getValueByName(KEY, List<Path>)`.
            // It also reads as comparisons (`a < b, c > d`), so both readings
            // are kept (see conflicts) and the comparison wins where both parse.
            prec.dynamic(-1, $.type_with_generics),
          )),
        ),
        ')'
      )),
      optional($.closure),
    )),

    // The `(` of a call's arguments or of a method's parameters. Right after a
    // name, with no space between, it is lexed as `_call_lparen` (see
    // src/scanner.c): Groovy reads `f(x)` only as a call, so `(x)` is not also
    // tried as a parenthesised first argument of a command call `f (x)`.
    // Without that, every call in a chain inside the arguments of another call
    // (`f(b(x).p(y).q(z).r())`) doubled the readings kept open until the parser
    // dropped the right one.
    _call_open: $ => choice('(', alias($._call_lparen, '(')),

    // A compound assignment used as an argument, whose value is passed on:
    // `new E(reason += 'failed')`. With a plain `=` it is a named argument.
    _compound_assignment: $ => seq(
      choice($._juxtable_expression, $._type_identifier, $.access_op),
      choice('**=', '*=', '/=', '%=', '+=', '-=', '<<=', '>>=', '>>>=', '&=', '^=', '|=', '?='),
      $._expression,
    ),

    // Assignment-style named argument: `foo(key=value)`.
    named_argument: $ => prec.dynamic(1, seq(
      field('key', choice($.identifier, $._type_identifier)),
      '=',
      field('value', $._expression),
    )),

    // From fork zgsolucoes/tree-sitter-groovy@9673a70 (Henrique Mota): closure
    // and lambda parameters take modifiers (`{ final Result r -> }`) but no
    // annotations: a class body is a closure, so `@Ann Type name` there must keep
    // parsing as an annotated field.
    _param_list: $ => prec(1, list_of(alias($._closure_parameter, $.parameter))),

    parameter_list: $ => prec(1, seq(
      $._call_open,
      optional(list_of($.parameter)),
      ')'
    )),

    // From fork zgsolucoes/tree-sitter-groovy@9673a70 (Henrique Mota): method
    // parameters with annotations and modifiers (`@PathVariable Long id`,
    // `final String sort`).
    parameter: $ => prec(-1, seq(
      repeat($.annotation),
      repeat($.modifier),
      $._parameter_body,
    )),

    _closure_parameter: $ => prec(-1, seq(repeat($.modifier), $._parameter_body)),

    // The type may be an all-capitals name (`AUTOSAR data`, `URI uri`, `T item`),
    // which lexes as an identifier, and the name may be capitalised
    // (`boolean MultipleVDP`, an untyped `RTETask`, even `Object = null`).
    // An all-capitals type ties with a command call's name (`URL url` in
    // `Pusher(URL url, int n = 0) { }`), so both readings are kept (see
    // conflicts) and a constructor is not read as a call with a closure.
    _parameter_body: $ => {
      // The value's precedence ties with `$._expression`, so `{ String a = '', b`
      // keeps both a declaration and closure parameters open (see conflicts).
      const value = optional(prec(-1, seq('=', field('value', prec(1, $._primary_expression)))));
      const name = field('name', choice($.identifier, $._type_identifier));
      return choice(
        prec(-1, seq(
          optional(field('type', choice($._type, 'def'))),
          optional('...'),
          name,
          value,
        )),
        // No precedence, unlike the other parameters: see above.
        seq(field('type', $.identifier), optional('...'), name, value),
      );
    },

    // A method without a body. Like a method with one (`function_definition`),
    // it may have modifiers and no return type: `abstract setPlugin(Plugin p)`.
    function_declaration: $ => choice(
      prec(2, seq(
        choice($._typed_method_head, $._untyped_method_head),
        field('parameters', $.parameter_list),
        optional($.throws),
      )),
      // An all-capitals return type, which lexes as an identifier, with no
      // modifier: `E getException(String message)` in an interface. It reads
      // like the command call `println format(x)`, so both readings are kept
      // (see conflicts) and the call wins where both parse.
      prec.dynamic(-1, seq(
        field('type', $.identifier),
        field('function', $.identifier),
        field('parameters', $.parameter_list),
        optional($.throws),
      )),
    ),

    // The head of a method with a return type, up to and including its name:
    // annotations, modifiers, type parameters, the return type (a type or `def`) and the name.
    // A capitalised name (`String PIFName()`) is accepted here, as a return type
    // tells it from a constructor.
    _typed_method_head: $ => {
      const name = field('function', choice($.identifier, $.quoted_identifier, $._type_identifier));
      const modifiers = method_modifiers($);
      return choice(seq(
        repeat($.annotation),
        choice(
          // Explicit return type (def or a type), modifiers optional.
          seq(
            optional(modifiers),
            field('type', choice($._type, 'def')),
          ),
          // A generic method: `static <T> T f()`, `@Override <T extends A> T f()`.
          // The return type may be the type parameter, an all-capitals name that
          // lexes as an identifier. The type parameters must follow a modifier or
          // an annotation (below): a statement may not start
          // with `<`, or `{ a < 0 }` would end the statement `a` before the `<`.
          seq(
            modifiers,
            $.type_parameters,
            field('type', choice($._type, 'def', $.identifier)),
          ),
          // `def` before the modifiers (`def private f()`, `def static f()`) or
          // before the type parameters (`def <T> T f()`, `def <T> boolean f()`).
          // The modifiers in any order (`def static private f()`).
          seq('def', repeat1(choice($.access_modifier, $.modifier)), optional($.type_parameters)),
          seq('def', $.type_parameters, optional(field('type', choice($._type, $.identifier)))),
          // Type parameters alone at the start of a line: `<T> T f(Closure<T> c)`.
          seq(alias($._line_type_parameters, $.type_parameters), field('type', choice($._type, 'def', $.identifier))),
        ),
        name,
      ),
      // An all-capitals return type, which lexes as an identifier, after a
      // modifier: `public T jreHome(Path p)`, `public URI getPath()`. (Without
      // a modifier or an annotation, `T f(x) { }` is a command call of `T`.)
      // The precedence reads the name as the method's, not as the start of a
      // statement after a field `static x`.
      prec(2, prec.dynamic(1, seq(repeat($.annotation), modifiers, field('type', $.identifier), name))),
      seq(
        repeat1($.annotation),
        choice(
          seq($.type_parameters, field('type', choice($._type, 'def', $.identifier))),
          // `@Override URI getPath()`.
          field('type', $.identifier),
        ),
        name,
      ));
    },

    // The head of a method with no return type, up to and including its name.
    // No return type but at least one modifier is present
    // (Groovy allows `private foo() {}`); requiring a modifier avoids
    // ambiguity with a trailing-closure function call `foo() {}`.
    // From fork zgsolucoes/tree-sitter-groovy@265566d (Henrique Mota):
    // a non-access modifier alone also stands in for the return type
    // (`static sumAll(List items) {}`).
    _untyped_method_head: $ => seq(
      repeat($.annotation),
      method_modifiers($),
      optional($.type_parameters),
      field('function', choice($.identifier, $.quoted_identifier)),
    ),

    function_definition: $ => prec(3, seq(
      choice($._typed_method_head, $._untyped_method_head),
      field('parameters', $.parameter_list),
      // From fork zgsolucoes/tree-sitter-groovy@265566d (Henrique Mota) and
      // Alexandoooor/tree-sitter-groovy@c8d4202 (Alexander Magnusson): `throws`.
      optional($.throws),
      field('body', $.closure),
    )),

    // Constructors: the class name with no return type, optionally behind
    // modifiers. Aliased to function_definition (name in `function`) so a
    // constructor inside a class body reads as a method like any other.
    // From fork mcarlinhpe/tree-sitter-groovy@f24363c (Mike Carlin) and
    // Alexandoooor/tree-sitter-groovy@42f158a (Alexander Magnusson).
    // Static precedence 2 ties with `_type` (a declaration `Foo (a, b)`) so the
    // parser keeps both readings open (see conflicts) instead of always reducing
    // `Foo` to a type. `Foo(x) { }` without a modifier also fits a call with a
    // trailing closure; a capitalised call name is rare while an untyped
    // constructor parameter is not, so the dynamic precedence picks the
    // constructor there.
    _constructor_definition: $ => prec(2, prec.dynamic(1, seq(
      repeat($.annotation),
      optional($.access_modifier),
      repeat($.modifier),
      field('function', $._type_identifier),
      field('parameters', $.parameter_list),
      optional($.throws),
      field('body', $.closure),
    ))),

    throws: $ => prec.left(seq('throws', $._class_type, repeat(seq(',', $._class_type)))),

    // Generic method type parameters: <T>, <T, U>, <T extends Comparable<T>>
    type_parameters: $ => seq('<', $._type_parameter_list, '>'),

    // Type parameters that start a line, with no modifier before them:
    // `<T> T f(Closure<T> c)` in a class body. Groovy ends a statement at a
    // line break, so a `<` that starts a line cannot continue the previous
    // statement as a comparison. The external scanner sees the line break
    // (`_line_start_lt`): a `<` after a statement on the same line
    // (`{ a < 0 }`) stays a comparison.
    _line_type_parameters: $ => seq(
      alias($._line_start_lt, '<'),
      $._type_parameter_list,
      '>',
    ),

    _type_parameter_list: $ => list_of(seq(
      choice($._type, $.identifier),
      optional(seq('extends', choice($._type, $.identifier, $._capitals_generic_type))),
    )),

    identifier: $ => IDENTIFIER_REGEX,
    _type_identifier: $ => alias(TYPE_REGEX, $.identifier),
    quoted_identifier: $ => choice(
      $._plain_string,
      $._interpolate_string,
    ),

    // identifier: $ => seq(
    //   choice($._letter, '$', '_'),
    //   repeat(choice($._letter, '[0-9]', '$', '_'))
    // ),

    if_statement: $ => prec.left(seq(
      'if',
      field('condition', $.parenthesized_expression),
      field('body', choice(
        $._statement,
        $.closure,
      )),
      optional(
        seq('else', field('else_body', choice($._statement, $.closure)))
      )
    )),

    // The `[` of an index must follow the indexed expression directly: Groovy
    // ends a statement at a line break, so a list that starts the next line
    // (`x = 0` then `[a, b].each { }`) is a new statement, not an index.
    index: $ => prec(PREC.TOP, seq(
      $._primary_expression,
      token.immediate('['),
      $._expression,
      ']',
    )),

    juxt_function_call: $ => choice(
      seq(
        field('function', $._juxtable_expression),
        field('args', alias($._juxt_argument_list, $.argument_list)),
      ),
      // A capitalised name called with a value, as in a markup builder:
      // `SandboxPath "${path}"`, `Version 2`. Only a literal may come first:
      // `Foo bar` is a declaration. The precedence beats reading `Foo` as the
      // return type of a method named by a string (`Foo "${x}"()`).
      prec(3, seq(
        field('function', $._type_identifier),
        field('args', alias($._literal_juxt_argument_list, $.argument_list)),
      )),
    ),

    _literal_juxt_argument_list: $ => prec.right(2, seq(
      choice(
        $.string,
        $.number_literal,
        $.boolean_literal,
        alias("null", $.null),
        $.list,
        $.map,
      ),
      optional(seq(',', $._juxt_argument_list)),
    )),

    _juxt_argument_list: $ => prec.left(2,
      seq(juxt_argument($), repeat(seq(',', juxt_argument($))))
    ),

    list: $ => prec(1, seq(
      '[',
      repeat(prec.left(seq($._expression, ','))),
      optional(seq($._expression, optional(','))),
      ']'
    )),


    map_item: $ => seq(
      field('key', choice(
        $.identifier,
        $._type_identifier,
        $.number_literal,
        $.string,
        $.parenthesized_expression,
      )),
      ':',
      field('value', $._map_value),
    ),

    map: $ => choice(
      seq(
        '[',
        repeat(
          prec.left(seq(
            choice($.map_item, $.spread_map_entry),
            ',',
          ))
        ),
        choice($.map_item, $.spread_map_entry),
        optional(','),
        ']',
      ),
      seq('[', ':', ']'),
    ),

    spread_map_entry: $ => seq('*:', field('value', $._expression)),

    number_literal: $ => choice(
      /-?[0-9]+(_[0-9]+)*[DFGILdfgil]?/,
      /-?0x[0-9a-fA-F]+(_[0-9a-fA-F]+)*[DFGILdfgil]?/,
      /-?0b[0-1]+(_[0-1]+)*[DFGILdfgil]?/,
      /-?0[0-7]+(_[0-7]+)*[DFGILdfgil]?/,
      // A signed exponent (`1.79E+308`, `2.5e-3`), also without a fraction (`1e6`).
      /-?[0-9]+(_[0-9]+)*\.[0-9]+(_[0-9]+)*([eE][+-]?[0-9]+)?[DFGILdfgil]?/,
      /-?[0-9]+(_[0-9]+)*[eE][+-]?[0-9]+[DFGILdfgil]?/,
    ),

    pipeline: $ => seq(
      'pipeline',
      $.closure,
    ),

    // pipeline_step_with_block: $ => seq(
    //   $._primary_expression,
    //   $.closure,
    // ),

    return: $ => choice(
      prec.right(1, seq('return', optional($._expression))),
      // A line break ends a bare `return`, as in Groovy: in
      // `if (done) return` the next line is a statement of its own, not the
      // returned value. The longer token wins over the keyword.
      alias(token(prec(1, /return[ \t]*(\/\/[^\r\n]*)?\r?\n/)), 'return'),
    ),

    string: $ => choice(
      $._quoted_string,
      $._slashy_string,
    ),

    // Only a quoted string names a called method ("/api/x"(..)`): after `g (x)`,
    // a `/` is the division, not a slashy string that a call starts with.
    _quoted_string: $ => choice(
      $._plain_string,
      $._interpolate_string,
    ),

    _plain_string: $ => choice(
      seq(
        '\'',
        repeat(choice(
          alias(token.immediate(prec(1, /[^\\'\n]+/)), $.string_content),
          $.escape_sequence,
        )),
        '\'',
      ),
      seq(
        "'''",
        repeat(seq(
          optional(alias(token.immediate(prec(0, /[']{1,2}/)), $.string_internal_quote)),
          choice(
            alias(token.immediate(prec(1, /([^\\']|[']{1,2}[^'\\])+/)), $.string_content),
            seq(
              optional(/[']{1,2}/), // edge case: these wont be in string_content
              $.escape_sequence,
            ),
          ))),
        "'''",
      ),
    ),

    _interpolate_string: $ => choice(
      seq(
        '"',
        repeat(choice(
          alias(token.immediate(prec(1, /[^$\\"\n]+/)), $.string_content),
          $.escape_sequence,
          $.interpolation,
        )),
        '"',
      ),
      seq(
        '"""',
        repeat(seq(
          // optional(alias(token.immediate(prec(0, /["]{1,2}/)), $.string_internal_quote)),
          choice(
            alias(token.immediate(prec(1, /([^$\\"]|["]{1,2}[^"$\\])+/)), $.string_content),
            seq(
              optional(/["]{1,2}/), // edge case: these wont be in string_content
              $.escape_sequence,
            ),
            seq(
              optional(/["]{1,2}/),
              $.interpolation,
            ),
          ))),
        '"""',
      ),
    ),

    _slashy_string: $ => choice(
      seq( // slashy string, only slashes can be escaped
        // Where a division could follow (`{ a / b }`, after an expression that
        // may end a statement), the `/` is the division: the opening slash has
        // the lower lexical precedence.
        alias(token(prec(-1, '/')), '/'),
        repeat(choice(
          alias(token.immediate(prec(1, /[^$\\\/]+/)), $.string_content),
          // A backslash before another one is literal, as in Groovy: `/\*\\//`
          // ends with `\`, the escape `\/` and the closing slash. A run of
          // backslashes is therefore one token, ending in `/` or another character.
          alias(/\\+\//, $.escape_sequence),
          alias(/\\+[^\/\\]/, $.string_content),
          $.interpolation,
          // From fork Alexandoooor/tree-sitter-groovy@e8222fb, @5d619cd (Alexander
          // Magnusson): a `$` that cannot start an interpolation is literal, as in
          // the regex anchor of `/^\d+$/` or `/a$|b/`. The fork used an external
          // scanner; here the longer token simply wins over the lone `$` of an
          // interpolation, so no scanner (and no binding change) is needed.
          alias(token.immediate(/\$[^a-zA-Z0-9_{\/\\$]/), $.string_content),
        )),
        choice(
          '/',
          // `$` right before the closing slash (`/foo$/`): one token, because a
          // lone `$` would be read as the start of an interpolation.
          alias(token.immediate('$/'), $.string_content),
        ),
      ),
      seq( // dollar slashy string
        '$/',
        repeat(choice(
          alias(token.immediate(prec(1,
            /([^$\/]|\/[^$]|\$[^\/$a-zA-Z{])+/
          )), $.string_content),
          alias('$/', $.escape_sequence),
          alias('$$', $.escape_sequence),
          // alias(//, $.string_content),
          $.interpolation,
        )),
        '/$',
      ),
    ),

    escape_sequence: _ => token(prec(1, seq(
      '\\',
      choice(
        /[$bfnrst\\'"\n]/,
        // A line continuation in a file with CRLF line endings: `'''\` at the
        // end of the line.
        /\r\n/,
        /u[0-9a-fA-F]{4}/,
      ),
    ))),


    interpolation: $ => seq(
      '$',
      choice(
        // May be empty: `"${}"` is valid Groovy (the placeholder of a template).
        seq(
          '{',
          optional($._expression),
          '}',
        ),
        alias(token.immediate(/[a-zA-Z0-9_]+(\.[a-zA-Z0-9_]+)*/), $.identifier),
      )
    ),

    switch_statement: $ => seq(
      'switch',
      field('value', $.parenthesized_expression),
      field('body', $.switch_block),
    ),

    switch_block: $ => seq(
      '{',
      repeat($.case),
      '}'
    ),

    case: $ => seq(
      choice(
        seq('case', field('value', $._expression), ':'),
        seq('default', ':'),
      ),
      statements($)
    ),

    ternary_op: $ => prec.right(seq(
      field('condition', $._expression),
      '?',
      field('then', $._expression),
      ':',
      field('else', $._expression),
    )),

    try_statement: $ => prec.left(seq(
      'try',
      // Try-with-resources: `try (Reader r = open(); Writer w = make()) { }`.
      // As in Groovy, a line break also separates two resources.
      optional(seq(
        '(',
        field('resource', alias($._resource, $.declaration)),
        repeat(seq(choice(';', $._line_end), field('resource', alias($._resource, $.declaration)))),
        optional(';'),
        ')',
      )),
      field('body', choice(
        $._statement,
        $.closure,
      )),
      // From fork zgsolucoes/tree-sitter-groovy@265566d (Henrique Mota): any
      // number of catch clauses.
      repeat(
        seq(
          'catch',
          '(',
          field(
            'catch_exception',
            choice(
              $.declaration,
              alias($._multi_catch_declaration, $.declaration),
              $._expression
            ),
          ),
          ')',
          field('catch_body', $.closure),
        )
      ),
      optional(
        seq(
          'finally',
          field('finally_body', $.closure),
        )
      )
    )),

    // A try-with-resources resource always has an initialiser.
    _resource: $ => seq(
      repeat($.modifier),
      optional(choice(field('type', $._type), 'def')),
      field('name', $.identifier),
      '=',
      field('value', $._expression),
    ),

    // `catch (IOException | ParseException e)`: one type per alternative.
    _multi_catch_declaration: $ => seq(
      repeat($.modifier),
      field('type', $._type),
      repeat1(seq('|', field('type', $._type))),
      field('name', $.identifier),
    ),

    builtintype: $ => choice(
      'int',
      'boolean',
      'byte', // From fork zgsolucoes/tree-sitter-groovy@265566d (Henrique Mota)
      'char',
      'short',
      'int',
      'long',
      'float',
      'double',
      'void',
    ),

    _type: $ => prec(2, choice(
      $.builtintype,
      $.array_type, //TODO: int[5]?
      $.type_with_generics,
      $.qualified_type,
      $._type_identifier,
    )),

    qualified_type: $ => seq(
      choice($.identifier, $._type_identifier),
      repeat1(seq('.', choice($.identifier, $._type_identifier))),
    ),

    array_type: $ => seq($._type, '[]'),

    access_modifier: $ => choice(
      'public',
      'protected',
      'private'
    ),

    modifier: $ => choice(
      'static',
      'final',
      'synchronized',
      'volatile',
      'transient',
      'abstract',
      'native',
      'strictfp'
    ),

    // Higher precedence than a `<` comparison: after `x as Map`, seeing `<` the
    // parser must choose between closing the cast and shifting into a generic
    // argument list. Without this it closes early and `<String, Object>` is read
    // as a comparison, which is what broke `as Map<String, Object>`.
    type_with_generics: $ => prec(PREC.COMPARE + 1, seq($._type, $.generics)),

    // A generic type whose name lexes as an identifier (all capitals), where only
    // a type can follow: the bound of a type parameter.
    _capitals_generic_type: $ => alias(seq($.identifier, $.generics), $.type_with_generics),

    // Type arguments, with wildcards: `<?>`, `<? extends A>`, `<? super B>`.
    generics: $ => seq('<', optional(list_of(choice($._type, $.identifier, $._wildcard))), '>'),

    _wildcard: $ => seq('?', optional(seq(choice('extends', 'super'), choice($._type, $.identifier)))),

    unary_op: $ =>
      choice(
        ...[
          ["+", PREC.UNARY],
          ["-", PREC.UNARY],
          ["~", PREC.TOP],
          ["!", PREC.TOP],
        ].map(([operator, precedence]) =>
          prec.left(precedence, seq(operator, $._expression))
        ),
      ),

    // Object creation: new Type(args), new Type<G>(args), new Type<>(args),
    // new Type[size], new Type[]{...}
    object_creation: $ => prec.right(PREC.TOP, seq(
      'new',
      field('type', choice($._type, $.identifier)),
      optional($.generics),
      choice(
        $.argument_list,
        seq(repeat1(seq('[', optional($._expression), ']')), optional(field('value', $.array_initializer))),
        // `new byte[] { 1, 2 }`: the type already ends in `[]`.
        field('value', $.array_initializer),
      ),
    )),

    // The elements of a new array, Java style: `{ a, b, { c } }`.
    array_initializer: $ => prec(PREC.TOP, seq(
      '{',
      optional(seq(
        choice($._expression, $.array_initializer),
        repeat(seq(',', choice($._expression, $.array_initializer))),
        optional(','),
      )),
      '}',
    )),

    while_loop: $ => seq(
      'while',
      field('condition', $.parenthesized_expression),
      field('body', choice(
        $._statement,
        $.closure
      )),
    ),

    // `synchronized (Foo.class) { .. }`. Without it the block was the
    // declaration `synchronized (lock)` and a closure, and a lock other than a
    // plain name was an error.
    synchronized_statement: $ => prec.dynamic(1, seq(
      'synchronized',
      field('lock', $.parenthesized_expression),
      field('body', $.closure),
    )),
  }
});

// TODO
// closures cleanup
// highlight jenkins words
