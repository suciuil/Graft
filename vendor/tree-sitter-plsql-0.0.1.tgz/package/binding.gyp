{
  "targets": [
    {
      "target_name": "tree_sitter_plsql_binding",
      "dependencies": [
        "<!(node -p \"require('node-addon-api').targets\"):node_addon_api_except",
      ],
      "include_dirs": [
        "src"
      ],
      "sources": [
        "bindings/node/binding.cc",
        "src/parser.c",
        "src/scanner.c",
      ],
      "conditions": [
        ["OS!='win'", {
          "cflags_c": ["-std=c99"],
        }, {
          "cflags_c": ["/std:c11", "/utf-8"],
        }],
      ],
    }
  ]
}
